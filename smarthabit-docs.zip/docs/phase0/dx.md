# Developer Experience — Makefile, Git Hooks, Editor Config

## Makefile

```makefile
.PHONY: help up down build quality test

help:                 ## Zeigt diese Hilfe
	@grep -E '^[a-zA-Z_-]+:.*##' $(MAKEFILE_LIST) | sort | awk 'BEGIN {FS = ":.*## "}; {printf "\033[36m%-20s\033[0m %s\n", $$1, $$2}'

# ── Docker ──────────────────────────────────────────────
up:                   ## Docker Compose starten (dev)
	docker compose --profile dev up -d

down:                 ## Docker Compose stoppen
	docker compose --profile dev down

build:                ## Docker Images neu bauen
	docker compose build --pull --no-cache

logs:                 ## Logs aller Services folgen
	docker compose logs -f

shell:                ## Shell im PHP-Container
	docker compose exec php sh

# ── Backend Quality ─────────────────────────────────────
quality:              ## Alle Backend-Checks lokal
	@$(MAKE) ecs-check phpstan rector-check test infection

ecs:                  ## Coding Standard (fix)
	cd backend && vendor/bin/ecs check --fix

ecs-check:            ## Coding Standard (check)
	cd backend && vendor/bin/ecs check

phpstan:              ## Statische Analyse
	cd backend && vendor/bin/phpstan analyse

rector:               ## Rector Auto-Fix
	cd backend && vendor/bin/rector process

rector-check:         ## Rector Dry-Run
	cd backend && vendor/bin/rector process --dry-run

# ── Backend Tests ───────────────────────────────────────
test:                 ## PHPUnit (alle Suites)
	cd backend && vendor/bin/phpunit

test-unit:            ## Nur Unit Tests mit Coverage
	cd backend && vendor/bin/phpunit --testsuite=unit --coverage-html=var/coverage

test-integration:     ## Nur Integration Tests
	cd backend && vendor/bin/phpunit --testsuite=integration

infection:            ## Mutation Testing
	cd backend && vendor/bin/infection --threads=4 --show-mutations

infection-fast:       ## Infection nur geänderte Files
	cd backend && vendor/bin/infection --threads=4 --git-diff-filter=AM --git-diff-base=origin/main

# ── Frontend ────────────────────────────────────────────
frontend-install:     ## Bun install
	cd frontend && bun install

frontend-dev:         ## SvelteKit Dev-Server
	cd frontend && bun run dev

frontend-build:       ## SvelteKit Production Build
	cd frontend && bun run build

frontend-check:       ## TypeScript + Svelte Check
	cd frontend && bun run check

frontend-lint:        ## ESLint
	cd frontend && bun run lint

# ── Database ────────────────────────────────────────────
db-migrate:           ## Doctrine Migrations ausführen
	docker compose exec php php bin/console doctrine:migrations:migrate --no-interaction

db-diff:              ## Migration-Diff generieren
	docker compose exec php php bin/console doctrine:migrations:diff

db-reset:             ## DB droppen + neu erstellen + migrieren
	docker compose exec php php bin/console doctrine:database:drop --force --if-exists
	docker compose exec php php bin/console doctrine:database:create
	docker compose exec php php bin/console doctrine:migrations:migrate --no-interaction
```

## Git Hooks — CaptainHook

CaptainHook registriert Git Hooks automatisch bei `composer install` via Plugin. Keine manuelle Installation nötig, kein GrumPHP (das wäre redundant weil es eigene Task-Definitionen mitbringt statt unsere bestehenden Tools zu nutzen).

**Wichtig**: `captainhook.json` lebt in `backend/` (dort wo `composer.json` ist). Die `git-directory` Config zeigt auf das Repo-Root, damit die Hooks in `.git/hooks/` installiert werden (eine Ebene über `backend/`).

#### `backend/captainhook.json`

```json
{
    "config": {
        "verbosity": "normal",
        "run-mode": "local",
        "fail-on-first-error": true,
        "ansi-colors": true,
        "git-directory": "../.git"
    },
    "pre-commit": {
        "enabled": true,
        "actions": [
            {
                "action": "vendor/bin/ecs check {$STAGED_FILES|of-type:php}",
                "options": {
                    "label": "ECS (nur staged PHP-Files)"
                },
                "conditions": [
                    {
                        "exec": "git diff --cached --name-only --diff-filter=ACM | grep -q '\\.php$'"
                    }
                ]
            },
            {
                "action": "vendor/bin/phpstan analyse {$STAGED_FILES|of-type:php} --memory-limit=512M",
                "options": {
                    "label": "PHPStan (nur staged PHP-Files)"
                },
                "conditions": [
                    {
                        "exec": "git diff --cached --name-only --diff-filter=ACM | grep -q '\\.php$'"
                    }
                ]
            }
        ]
    },
    "commit-msg": {
        "enabled": true,
        "actions": [
            {
                "action": "\\CaptainHook\\App\\Hook\\Message\\Action\\Regex",
                "options": {
                    "regex": "#^(feat|fix|refactor|test|docs|chore|ci|style|perf|build|revert)(\\(.+\\))?: .{3,}#",
                    "error": "Commit Message muss Conventional Commits Format folgen: feat|fix|refactor|test|docs|chore: <beschreibung>"
                }
            }
        ]
    },
    "pre-push": {
        "enabled": true,
        "actions": [
            {
                "action": "vendor/bin/phpunit --testsuite=unit",
                "options": {
                    "label": "PHPUnit Unit Tests"
                }
            }
        ]
    }
}
```

**Wichtig**: Die pre-commit Hooks laufen nur auf **staged PHP-Files**, nicht auf dem ganzen Projekt. Das hält sie schnell (<5 Sekunden statt 30+). PHPUnit und Infection laufen als pre-push Hook bzw. in der CI — zu langsam für pre-commit.

Der `commit-msg` Hook erzwingt Conventional Commits Format (`feat:`, `fix:`, `refactor:` etc.) auf Git-Ebene. Das ist strikter als nur eine CI-Prüfung, weil der Commit gar nicht erst erstellt wird wenn das Format nicht stimmt.

**Installation**: Passiert automatisch bei `composer install` durch `captainhook/plugin-composer`. Keine manuelle `git hooks install` nötig.

**Bypass**: Im Notfall `git commit --no-verify` — aber das sollte die Ausnahme sein, nicht die Regel.

## .editorconfig

Garantiert konsistente Formatierung über IDEs hinweg — PHPStorm, VS Code, Vim, etc. lesen `.editorconfig` nativ.

```ini
# .editorconfig
root = true

[*]
charset = utf-8
end_of_line = lf
insert_final_newline = true
trim_trailing_whitespace = true
indent_style = space
indent_size = 4

[*.{js,ts,svelte,json,yaml,yml,css,html,md}]
indent_size = 2

[*.{neon,neon.dist}]
indent_style = tab
indent_size = 4

[Makefile]
indent_style = tab

[*.md]
trim_trailing_whitespace = false

[docker-compose*.{yml,yaml}]
indent_size = 2

[*.hcl]
indent_size = 2

[composer.json]
indent_size = 4
```

Wichtige Punkte: PHP nutzt 4 Spaces, Frontend-Code (JS/TS/Svelte/CSS) nutzt 2 Spaces, PHPStan Neon-Dateien nutzen Tabs (PHPStan-Konvention), Makefile muss Tabs nutzen (Make-Syntax-Requirement), Markdown behält Trailing Whitespace (semantische Line Breaks).

## .gitattributes

Sorgt für konsistente Zeilenenden, bessere Diffs und korrekte Sprachstatistiken auf GitHub.

```gitattributes
# Enforce LF line endings
* text=auto eol=lf

# PHP — bessere Diffs (zeigt Funktionsnamen in Hunk-Header)
*.php diff=php

# Frontend
*.ts text
*.svelte text
*.css text
*.html text

# Lockfiles — nicht manuell editieren
bun.lock text -diff linguist-generated
composer.lock text -diff linguist-generated

# Binaries
*.png binary
*.jpg binary
*.jpeg binary
*.gif binary
*.ico binary
*.woff binary
*.woff2 binary
*.ttf binary

# GitHub linguist — Templates/Generated nicht in Sprachstatistik
docs/** linguist-documentation
infrastructure/** linguist-vendored
*.lock linguist-generated
```

**`diff=php`** — Git zeigt bei PHP-Diffs den Klassen-/Methodennamen im Hunk-Header statt nur die Zeilennummer. Macht `git log -p` und PR-Diffs deutlich lesbarer.

**`eol=lf`** — erzwingt Unix-Zeilenenden auch auf Windows. Verhindert Mixed-Endings die Docker-Volumes auf Windows kaputtmachen.

**`-diff` auf Lockfiles** — zeigt keine Diffs für generierte Lockfiles, hält PRs sauber.

## .dockerignore

Ohne `.dockerignore` kopiert Docker den gesamten Repo-Inhalt in den Build-Context — inkl. `.git/`, `node_modules/`, `vendor/`. Das verlangsamt Builds und kann Secrets leaken.

```
.git
.github
.claude
infrastructure
frontend/node_modules
frontend/.svelte-kit
frontend/build
backend/var
backend/vendor
*.md
!backend/README.md
docker-compose*.yml
compose*.yaml
.env.local
.env.*.local
.idea
.vscode
.DS_Store
```

**Hinweis**: `.gitignore` Spezifikation ist in [`phase0/infrastructure.md`](infrastructure.md) dokumentiert (inkl. Backend, Frontend, Docker, OpenTofu, IDE-Dateien).

## cloud-init.yml (Infrastructure)

Referenziert in `modules/server/main.tf`, hier die Spezifikation:

```yaml
#cloud-config
package_update: true
package_upgrade: true

packages:
  - docker.io
  - docker-compose-plugin
  - unattended-upgrades
  - fail2ban
  - curl

runcmd:
  # Docker ohne sudo
  - usermod -aG docker ubuntu

  # Volume mounten (Hetzner Volume wird als /dev/disk/by-id/scsi-0HC_Volume_* verfügbar)
  - mkdir -p /mnt/data
  - echo '/dev/disk/by-id/scsi-0HC_Volume_* /mnt/data ext4 defaults,nofail 0 2' >> /etc/fstab
  - mount -a

  # Verzeichnisse für App-Daten
  - mkdir -p /mnt/data/postgres
  - mkdir -p /mnt/data/backups
  - chown -R 999:999 /mnt/data/postgres    # PostgreSQL User ID

  # Unattended Upgrades aktivieren (Security only)
  - dpkg-reconfigure --priority=low unattended-upgrades

  # Fail2ban starten
  - systemctl enable fail2ban
  - systemctl start fail2ban

  # Docker starten
  - systemctl enable docker
  - systemctl start docker
```

Installiert Docker + fail2ban, mountet das Hetzner Volume, erstellt Verzeichnisse für PostgreSQL-Daten und Backups. Security-Updates laufen automatisch via unattended-upgrades.

## .env.example

```env
# ── App ─────────────────────────────
APP_ENV=dev
APP_SECRET=ChangeThisToASecureSecret

# ── Database ────────────────────────
DATABASE_URL="postgresql://app:!ChangeMe!@pgbouncer:6432/app?serverVersion=17&sslmode=disable&charset=utf8"
# Messenger Worker verbindet DIREKT zur DB (LISTEN/NOTIFY):
MESSENGER_DATABASE_URL="postgresql://app:!ChangeMe!@database:5432/app?serverVersion=17&sslmode=disable&charset=utf8"

# ── Messenger ──────────────────────
MESSENGER_TRANSPORT_DSN=doctrine://default?auto_setup=0

# ── Mercure ─────────────────────────
MERCURE_URL=https://php/.well-known/mercure
MERCURE_PUBLIC_URL=https://localhost/.well-known/mercure
MERCURE_JWT_SECRET=ChangeThisMercureHubJWTSecretKey

# ── JWT ─────────────────────────────
JWT_SECRET_KEY=%kernel.project_dir%/config/jwt/private.pem
JWT_PUBLIC_KEY=%kernel.project_dir%/config/jwt/public.pem
JWT_PASSPHRASE=ChangeThisPassphrase
JWT_TOKEN_TTL=900         # 15 Minuten
JWT_REFRESH_TTL=2592000   # 30 Tage

# ── Mailer ──────────────────────────
MAILER_DSN=null://null
# Brevo Prod: MAILER_DSN=smtp://user:pass@smtp-relay.brevo.com:587

# ── Frontend ────────────────────────
# Kein PUBLIC_API_URL nötig — API-Calls sind relativ (/api/v1/...)
# Dev: Vite Proxy leitet /api an FrankenPHP weiter
# Prod: Caddy served Frontend + API unter einer Domain

# ── Monitoring ──────────────────────
SENTRY_DSN=
# GlitchTip Prod: SENTRY_DSN=https://key@errors.example.com/1

# ── Claude Code (GitHub Actions) ────
# Nicht in .env.local — als GitHub Repository Secret setzen:
# ANTHROPIC_API_KEY=sk-ant-...
```

