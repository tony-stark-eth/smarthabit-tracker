# CLAUDE.md & .claude/ Verzeichnis Spezifikation

Die CLAUDE.md ist bewusst schlank — nur Quick Start, Projekttyp und Verweise. Die eigentlichen Regeln leben in `.claude/` und werden von Claude Code automatisch gelesen.

#### `CLAUDE.md` — Entry Point (~30 Zeilen)

```markdown
# Claude Code Instructions

## Quick Start

```
docker compose --profile dev up -d
cd backend && composer install
cd frontend && bun install
make quality
```

## Projekt

Full-Stack Mono-Repo: `backend/` (Symfony 8 API) + `frontend/` (SvelteKit PWA).

## Guidelines

Coding- und Architektur-Regeln in `.claude/`:

- `.claude/coding-php.md` — PHP Coding Guidelines
- `.claude/coding-frontend.md` — Svelte / TypeScript Guidelines
- `.claude/testing.md` — Testing, PHPStan, CI Pipeline
- `.claude/architecture.md` — Docker, DB, Ordnerstruktur, Patterns

## Verbote

- Kein React — Svelte 5 oder plain JS
- Kein `DateTime` — nur `DateTimeImmutable`
- Kein `var_dump`/`dump`/`dd`
- Kein `ignoreErrors` in phpstan.neon
- Kein `empty()`
- Conventional Commits: `feat:`, `fix:`, `refactor:`, `test:`, `docs:`, `chore:`
```

#### `.claude/coding-php.md` — PHP Coding Guidelines

Generisch, kein Projektbezug. Inhalt:

```markdown
# PHP Coding Guidelines

## Grundlagen

- `declare(strict_types=1)` — erste Zeile, jede PHP-Datei, keine Ausnahme
- `final readonly class` als Default — nur aufbrechen wenn Extension nötig
- `DateTimeImmutable` immer, `DateTime` ist verboten (PHPStan enforced)
- Constructor Injection only — kein Service Locator, kein Property Injection

## Methoden

- Max 20 Zeilen pro Methode
- Max 3 Parameter — mehr → DTO oder Value Object
- Cognitive Complexity max 8 (enforced via PHPStan)
- Ein Abstraktionslevel pro Methode
- Methodennamen sind Verben: `findActiveHabits()`, nicht `habits()`

## Klassen

- Max ~150 Zeilen (ohne Imports/Docblocks)
- Cognitive Complexity max 50 pro Klasse (enforced via PHPStan)
- Max 5 Dependencies im Konstruktor
- `find*` darf null zurückgeben, `get*` wirft Exception

## Patterns

- Value Objects für Domain-Konzepte (kein Primitive Obsession)
- Early Returns — max Verschachtelungstiefe 2
- Composition over Inheritance
- Immutability by Default
- Enums statt Magic Values
- Spezifische Exceptions, nie verschlucken

## Ordnerstruktur

Domain-basiert, nicht Framework-basiert:

```
src/
├── Feature/           ← pro Domain-Konzept
│   ├── Controller/
│   ├── Entity/
│   ├── Repository/
│   ├── Service/
│   ├── Event/
│   ├── Exception/
│   └── ValueObject/
└── Shared/            ← Domain-übergreifend
```

Nicht: `src/Entity/`, `src/Service/`, `src/Controller/` als flache Ordner.

## Naming Conventions

- Controller: `{Feature}Controller`
- Service: `{Action}Service` oder `{Feature}Handler`
- Exception: `{What}Exception` — muss in `Exception/` Namespace leben (phpat enforced)
- Value Object: Name beschreibt den Wert, z.B. `Email`, `TimeWindow`, `InviteCode`
- Test: `{ClassUnderTest}Test`
- Enums: PascalCase Singular, z.B. `PushType`, `HabitFrequency`
```

#### `.claude/coding-frontend.md` — Frontend Guidelines

```markdown
# Frontend Coding Guidelines

## TypeScript

- strict mode, kein `any`
- `noUncheckedIndexedAccess: true`
- `noImplicitOverride: true`
- `exactOptionalPropertyTypes: true`

## Svelte 5

- Runes only: `$state()`, `$derived()`, `$effect()` — kein Legacy (`$:`, `let x = 0`)
- Max ~100 Zeilen pro Komponente (Template + Script + Style)
- Props mit Defaults und Typen, keine `$$props` oder `$$restProps`
- Kein Business-Logic in Komponenten → extrahiere in `$lib/` Modules
- Kein direkter `fetch` in Komponenten → API-Wrapper aus `$lib/api/`

## Styling

- Tailwind 4 Utility Classes
- CSS Custom Properties für Design Tokens (Farben, Fonts, Spacing)
- Dark Mode via CSS Custom Properties, nicht via Tailwind `dark:`
- Mobile-First

## i18n

- Alle sichtbaren Strings als Translation-Keys
- Keine hardcoded Strings in Komponenten
- Dateien: `$lib/i18n/de.ts`, `$lib/i18n/en.ts`

## Accessibility

- ARIA-Labels auf interaktiven Elementen
- Keyboard-Navigation
- Kontrast WCAG AA minimum
- Fokus-Management bei Modals/Dialogen
```

#### `.claude/testing.md` — Testing Guidelines

```markdown
# Testing & Code-Qualität

## Composer Dev-Dependencies

14 Pakete — siehe `backend/composer.json`

## PHPStan — Level max + 10 Extensions

Konfiguration in `backend/phpstan.neon`. Extensions:

| Extension | Was sie prüft |
|---|---|
| `phpstan-strict-rules` | `===`, kein `empty()`, strikte `in_array()` |
| `phpstan-deprecation-rules` | Deprecated Code (PHP, Symfony, Doctrine) |
| `shipmonk/phpstan-rules` | ~40 Rules: Enum-Safety, vergessene Exceptions, Custom-Verbote |
| `voku/phpstan-rules` | Operator-Typ-Kompatibilität, Assignment-in-Condition |
| `tomasvotruba/cognitive-complexity` | function: 8, class: 50 |
| `tomasvotruba/type-coverage` | return: 100, param: 100, property: 100, constant: 100, declare: 100 |
| `phpat/phpat` | Architecture Tests (Layer, Naming) |
| `phpstan-symfony` | Container-aware, Route-Parameter |
| `phpstan-doctrine` | Entity-Mapping, Repository-Returns |
| `phpstan-phpunit` | Mock-Type-Inference, Assert-Types |

Bleeding Edge Flags aktiv: `checkUninitializedProperties`, `checkImplicitMixed`,
`checkBenevolentUnionTypes`, `reportPossiblyNonexistentGeneralArrayOffset`

## PHPUnit 13

- Path Coverage via PCOV (nicht Xdebug)
- Zwei Suites: `unit` (tests/Unit), `integration` (tests/Integration)
- `#[CoversClass(...)]` auf jeder Testklasse
- `createStub()` statt `createMock()` wo keine Invocation-Verification nötig
- Data Providers für Edge-Cases

## Infection (Mutation Testing)

- Läuft nur gegen Unit-Suite
- MSI >= 80%, Covered MSI >= 90%
- `infection-fast` für nur geänderte Files (CI-Optimization)

## Rector

- PHP 8.4 + Symfony 8 + Doctrine + PHPUnit Sets
- CI: `--dry-run` (blockt bei Diff), lokal: Auto-Fix

## ECS

- PSR-12 + common + strict + cleanCode Sets

## CI Pipeline (Reihenfolge)

```
1. ECS Check          — Coding Standard (schnellster Check zuerst)
2. PHPStan            — Statische Analyse + alle 10 Extensions
3. Rector --dry-run   — Veraltete Patterns?
4. PHPUnit Unit       — mit Path Coverage
5. PHPUnit Integration — gegen PostgreSQL (Service Container in CI)
6. Infection           — Mutation Testing gegen Unit-Suite
```

Steps 1-3 laufen parallel (kein DB nötig). Steps 4-6 sequentiell.

## Architecture Tests (phpat)

Tests in `tests/Architecture/`, laufen via PHPStan (nicht PHPUnit):
- `LayerDependencyTest` — Services dürfen nicht von Controllern abhängen
- `NamingConventionTest` — Exceptions in Exception-Namespace

## Enforcement-Matrix

| Regel | Tool | Grenze | CI blockiert? |
|---|---|---|---|
| Cognitive Complexity / Methode | `tomasvotruba/cognitive-complexity` | max 8 | Ja |
| Cognitive Complexity / Klasse | `tomasvotruba/cognitive-complexity` | max 50 | Ja |
| Type Coverage | `tomasvotruba/type-coverage` | 100% | Ja |
| `declare(strict_types=1)` | `tomasvotruba/type-coverage` | 100% | Ja |
| Layer-Dependencies | `phpat/phpat` | Architektur-Test | Ja |
| Naming Conventions | `phpat/phpat` + `shipmonk` | Architektur-Test | Ja |
| Strikte Vergleiche | `phpstan-strict-rules` | strict | Ja |
| Deprecated Code | `phpstan-deprecation-rules` | 0 | Ja |
| Debug-Funktionen | `shipmonk` (`forbidCustomFunctions`) | 0 | Ja |
| `DateTime` verboten | `shipmonk` (`forbidCustomFunctions`) | 0 | Ja |
| PHPStan Level | `phpstan/phpstan` | max | Ja |
| Coding Standard | `symplify/easy-coding-standard` | PSR-12 + strict | Ja |
| Code-Modernität | `rector/rector` | PHP 8.4 + Symfony 8 | Ja (dry-run) |
| Path Coverage | PHPUnit 13 + PCOV | >= 80% | Ja |
| Mutation Score | `infection/infection` | MSI >= 80% | Ja |
| Covered Code MSI | `infection/infection` | >= 90% | Ja |
```

#### `.claude/architecture.md` — Architektur-Konventionen

```markdown
# Architektur

## Projekt-Typ

Full-Stack Mono-Repo: `backend/` (PHP API) + `frontend/` (SvelteKit PWA).
Kommunikation ausschließlich über REST API (`/api/v1/`).

## Docker

- **FrankenPHP** (Caddy + PHP 8.4) — ein Container für Web + Worker
- **PostgreSQL 17** — primary DB
- **PgBouncer** — Transaction Mode für Web-Requests
- **Messenger Worker** — verbindet DIREKT zur DB, NICHT über PgBouncer (LISTEN/NOTIFY)
- **Bun** — SvelteKit Dev-Server (nur dev Profile)

## Konventionen

- Alles UTC in der DB — außer explizite Lokalzeit-Felder (PostgreSQL `TIME`)
- Async: Mails und Push via Symfony Messenger, nie im HTTP-Request
- API: Plain Controller + Symfony Serializer, kein API Platform
- Auth: JWT (Access Token 15min + Refresh Token 30d)
- i18n: paraglide-sveltekit (Frontend) + Symfony Translator (Backend), de + en

## Makefile Targets

`make help` zeigt alle verfügbaren Targets. Wichtigste:

- `make up` / `make down` — Docker starten/stoppen
- `make quality` — Alle Backend-Checks (ECS, PHPStan, Rector, Test, Infection)
- `make test` / `make test-unit` / `make test-integration` — Tests
- `make db-migrate` / `make db-diff` / `make db-reset` — Datenbank

## ENV-Variablen

Dokumentiert in `.env.example`. Wichtig:
- `DATABASE_URL` → PgBouncer (Web-Requests)
- `MESSENGER_DATABASE_URL` → direkt PostgreSQL (Worker)
- Separate URLs weil PgBouncer kein LISTEN/NOTIFY unterstützt
```

### Template-Erweiterung für SmartHabit

Wenn das Template für SmartHabit geforkt wird, kommen projektspezifische Ergänzungen hinzu:

- `CLAUDE.md` bekommt einen `## Projekt-Kontext` Abschnitt mit SmartHabit-spezifischem Wissen
- `.claude/coding-php.md` bleibt unverändert (generisch)
- `.claude/architecture.md` bekommt SmartHabit-Entities, API-Endpoints, Push-Architektur
- `.claude/testing.md` bekommt SmartHabit-spezifische phpat-Regeln (DomainIsolationTest)
- Neue Datei `.claude/domain.md` mit Habits, Notifications, Households, DSGVO etc.

