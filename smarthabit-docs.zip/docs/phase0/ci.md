# GitHub Actions & CI/CD

#### `.github/workflows/ci.yml` — Backend CI

```yaml
name: Backend CI

on:
  push:
    branches: [main]
    paths: ['backend/**', '.github/workflows/ci.yml']
  pull_request:
    branches: [main]
    paths: ['backend/**', '.github/workflows/ci.yml']

jobs:
  # ── Steps 1-3: Parallel (kein DB nötig) ──────────────────
  ecs:
    runs-on: ${{ vars.RUNNER_LABEL || 'ubuntu-latest' }}
    defaults:
      run:
        working-directory: backend
    steps:
      - uses: actions/checkout@v4
      - uses: shivammathur/setup-php@v2
        with:
          php-version: '8.4'
          extensions: intl, pdo_pgsql
      - uses: actions/cache@v4
        with:
          path: backend/vendor
          key: composer-${{ hashFiles('backend/composer.lock') }}
      - run: composer install --no-interaction --prefer-dist
      - name: ECS Check
        run: vendor/bin/ecs check

  phpstan:
    runs-on: ${{ vars.RUNNER_LABEL || 'ubuntu-latest' }}
    defaults:
      run:
        working-directory: backend
    steps:
      - uses: actions/checkout@v4
      - uses: shivammathur/setup-php@v2
        with:
          php-version: '8.4'
          extensions: intl, pdo_pgsql
      - uses: actions/cache@v4
        with:
          path: backend/vendor
          key: composer-${{ hashFiles('backend/composer.lock') }}
      - run: composer install --no-interaction --prefer-dist
      - name: PHPStan
        run: vendor/bin/phpstan analyse --memory-limit=512M

  rector:
    runs-on: ${{ vars.RUNNER_LABEL || 'ubuntu-latest' }}
    defaults:
      run:
        working-directory: backend
    steps:
      - uses: actions/checkout@v4
      - uses: shivammathur/setup-php@v2
        with:
          php-version: '8.4'
          extensions: intl, pdo_pgsql
      - uses: actions/cache@v4
        with:
          path: backend/vendor
          key: composer-${{ hashFiles('backend/composer.lock') }}
      - run: composer install --no-interaction --prefer-dist
      - name: Rector Dry-Run
        run: vendor/bin/rector process --dry-run

  # ── Steps 4-6: Sequentiell (braucht DB + Coverage-Daten) ─
  tests:
    runs-on: ${{ vars.RUNNER_LABEL || 'ubuntu-latest' }}
    needs: [ecs, phpstan, rector]
    defaults:
      run:
        working-directory: backend
    services:
      postgres:
        image: postgres:17-alpine
        env:
          POSTGRES_USER: app
          POSTGRES_PASSWORD: test
          POSTGRES_DB: app_test
        ports:
          - 5432:5432
        options: >-
          --health-cmd="pg_isready -U app"
          --health-interval=5s
          --health-timeout=5s
          --health-retries=5
    env:
      DATABASE_URL: postgresql://app:test@localhost:5432/app_test?serverVersion=17&sslmode=disable
      APP_ENV: test
    steps:
      - uses: actions/checkout@v4
      - uses: shivammathur/setup-php@v2
        with:
          php-version: '8.4'
          extensions: intl, pdo_pgsql, pcov
          coverage: pcov
      - uses: actions/cache@v4
        with:
          path: backend/vendor
          key: composer-${{ hashFiles('backend/composer.lock') }}
      - run: composer install --no-interaction --prefer-dist
      - run: php bin/console doctrine:migrations:migrate --no-interaction
      
      - name: PHPUnit (Unit + Integration)
        run: vendor/bin/phpunit --coverage-clover=var/coverage/clover.xml --coverage-xml=var/coverage/coverage-xml --log-junit=var/coverage/junit.xml
      
      - name: Infection (Mutation Testing)
        run: vendor/bin/infection --threads=4 --coverage=var/coverage --skip-initial-tests --min-msi=80 --min-covered-msi=90
```

#### `.github/workflows/ci-frontend.yml` — Frontend CI

```yaml
name: Frontend CI

on:
  push:
    branches: [main]
    paths: ['frontend/**', '.github/workflows/ci-frontend.yml']
  pull_request:
    branches: [main]
    paths: ['frontend/**', '.github/workflows/ci-frontend.yml']

jobs:
  lint-and-build:
    runs-on: ubuntu-latest
    defaults:
      run:
        working-directory: frontend
    steps:
      - uses: actions/checkout@v4
      - uses: oven-sh/setup-bun@v2
        with:
          bun-version: latest
      - run: bun install --frozen-lockfile
      - name: ESLint
        run: bun run lint
      - name: Svelte Check (TypeScript)
        run: bun run check
      - name: Build
        run: bun run build
```

#### `.github/workflows/dependabot-automerge.yml`

Auto-Merge für Dependabot: Patches immer, Minor-Updates für Quality-Tools (PHPStan-Extensions etc.) ebenfalls — wenn CI grün:

```yaml
name: Dependabot Auto-Merge

on: pull_request

permissions:
  contents: write
  pull-requests: write

jobs:
  auto-merge:
    runs-on: ubuntu-latest
    if: github.actor == 'dependabot[bot]'
    steps:
      - uses: dependabot/fetch-metadata@v2
        id: metadata

      # Patches: immer auto-mergen
      - if: steps.metadata.outputs.update-type == 'version-update:semver-patch'
        run: gh pr merge --auto --squash "$PR_URL"
        env:
          PR_URL: ${{ github.event.pull_request.html_url }}
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}

      # Minor: nur für Quality-Tools (PHPStan, Rector, ECS, Infection etc.)
      - if: >
          steps.metadata.outputs.update-type == 'version-update:semver-minor' &&
          contains(steps.metadata.outputs.dependency-group, 'phpstan')
        run: gh pr merge --auto --squash "$PR_URL"
        env:
          PR_URL: ${{ github.event.pull_request.html_url }}
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

#### `.github/dependabot.yml`

```yaml
version: 2
updates:
  - package-ecosystem: composer
    directory: /backend
    schedule:
      interval: weekly
    open-pull-requests-limit: 10
    groups:
      phpstan:
        patterns: ["phpstan/*", "tomasvotruba/*", "shipmonk/*", "voku/*", "phpat/*"]
      symfony:
        patterns: ["symfony/*"]
  - package-ecosystem: npm
    directory: /frontend
    schedule:
      interval: weekly
    open-pull-requests-limit: 10
  - package-ecosystem: docker
    directory: /docker/frankenphp
    schedule:
      interval: monthly
  - package-ecosystem: github-actions
    directory: /
    schedule:
      interval: monthly
```

#### `.github/workflows/claude-update.yml` — Biweekly Dependency Update

Dependabot macht nur Version-Bumps in `composer.json`/`package.json`. Diese Pipeline nutzt Claude Code um den Rest zu erledigen: Rector-Regeln auf neue Versionen anpassen, PHPStan-Konfig-Änderungen, Breaking Changes fixen, Deprecation Warnings auflösen, SvelteKit-Migrationen. Läuft alle 2 Wochen als Cron.

```yaml
name: Claude Dependency Update

on:
  schedule:
    - cron: '0 6 1,15 * *'     # 1. und 15. jedes Monats, 06:00 UTC
  workflow_dispatch:             # Manuell auslösbar

permissions:
  contents: write
  pull-requests: write
  issues: write

jobs:
  update-dependencies:
    runs-on: ubuntu-latest
    # Alternativ: runs-on: ${{ vars.RUNNER_LABEL || 'ubuntu-latest' }}
    timeout-minutes: 30
    services:
      postgres:
        image: postgres:17-alpine
        env:
          POSTGRES_USER: app
          POSTGRES_PASSWORD: test
          POSTGRES_DB: app_test
        ports:
          - 5432:5432
        options: >-
          --health-cmd="pg_isready -U app"
          --health-interval=5s
          --health-timeout=5s
          --health-retries=5
    env:
      DATABASE_URL: postgresql://app:test@localhost:5432/app_test?serverVersion=17&sslmode=disable
      APP_ENV: test
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - uses: shivammathur/setup-php@v2
        with:
          php-version: '8.4'
          extensions: intl, pdo_pgsql, pcov
          coverage: pcov

      - uses: oven-sh/setup-bun@v2
        with:
          bun-version: latest

      - uses: anthropics/claude-code-action@v1
        with:
          anthropic_api_key: ${{ secrets.ANTHROPIC_API_KEY }}
          prompt: |
            Du bist ein Dependency-Update-Agent für ein PHP 8.4 + Symfony 8 + SvelteKit Projekt.
            Lies CLAUDE.md und .claude/ für die Projekt-Konventionen.

            Führe folgende Schritte aus:

            ## 1. Backend Updates (backend/)
            - `cd backend && composer update --no-interaction`
            - Prüfe ob `composer outdated --direct` noch veraltete Pakete zeigt
            - Führe `vendor/bin/rector process` aus um Code auf neue API-Versionen zu migrieren
            - Führe `vendor/bin/ecs check --fix` aus um Code-Style zu fixen
            - Führe `vendor/bin/phpstan analyse` aus — wenn Errors auftreten:
              - Analysiere ob es Breaking Changes in aktualisierten Paketen sind
              - Fixe die Errors (NICHT mit ignoreErrors, sondern im Code)
              - Wenn PHPStan-Extension-Config sich geändert hat, passe phpstan.neon an
            - Führe `vendor/bin/phpunit` aus — wenn Tests fehlschlagen:
              - Analysiere ob es API-Änderungen in aktualisierten Dependencies sind
              - Fixe die Tests

            ## 2. Frontend Updates (frontend/)
            - `cd frontend && bun update`
            - `bun run check` — TypeScript-Errors fixen wenn nötig
            - `bun run build` — Build-Errors fixen wenn nötig
            - Prüfe ob SvelteKit Breaking Changes vorliegen (Migration Guide lesen wenn Major-Bump)

            ## 3. Qualitätssicherung
            - Stelle sicher dass ALLE folgenden Checks grün sind:
              - `cd backend && vendor/bin/ecs check`
              - `cd backend && vendor/bin/phpstan analyse`
              - `cd backend && vendor/bin/rector process --dry-run`
              - `cd backend && vendor/bin/phpunit`
              - `cd frontend && bun run check`
              - `cd frontend && bun run build`

            ## 4. Ergebnis
            - Wenn Änderungen vorhanden: erstelle einen Branch `chore/dependency-update-YYYY-MM-DD`
            - Committe alle Änderungen mit Conventional Commit Messages:
              - `chore(deps): update backend dependencies`
              - `chore(deps): update frontend dependencies`
              - `fix: resolve breaking changes from X upgrade` (falls nötig)
            - Erstelle einen PR mit einer Zusammenfassung:
              - Welche Pakete wurden aktualisiert (Backend + Frontend)
              - Welche Breaking Changes gab es und wie wurden sie gelöst
              - Welche Rector-Transformationen wurden angewandt
              - Ob alle Quality-Checks grün sind

            ## Wichtig
            - KEINE neuen `@phpstan-ignore` ohne Begründung hinzufügen
            - KEINE Quality-Thresholds senken (MSI, Coverage, Cognitive Complexity)
            - Wenn ein Update nicht fixbar ist: Paket NICHT updaten, in der PR-Beschreibung dokumentieren warum
            - Bei Major-Version-Bumps von Symfony, SvelteKit oder Doctrine: besonders vorsichtig sein, Migration Guide konsultieren

          claude_args: "--max-turns 25 --model sonnet"
```

**⚠️ Wichtig: Der PR von dieser Pipeline wird NIEMALS auto-gemergt.** Immer manuell reviewen — Claude kann technisch korrekte aber semantisch falsche Fixes machen, besonders bei API-Änderungen. `--max-turns 25` statt höher verhindert dass Claude in Schleifen gerät.

**Empfehlung**: Diese Pipeline erst nach Phase 1b aktivieren, wenn genug Code und Tests existieren die Claude als Kontext nutzen kann. Auf einem fast leeren Template-Repo ist sie sinnlos.

#### `.github/workflows/claude.yml` — Interactive @claude Mentions

Ermöglicht `@claude` in Issues und PR-Kommentaren. Claude liest die CLAUDE.md + `.claude/` Konventionen und kann Fragen beantworten oder Code-Änderungen implementieren.

```yaml
name: Claude Code

on:
  issue_comment:
    types: [created]
  pull_request_review_comment:
    types: [created]
  issues:
    types: [opened, assigned]

permissions:
  contents: write
  pull-requests: write
  issues: write

jobs:
  claude:
    runs-on: ubuntu-latest
    # Alternativ: runs-on: ${{ vars.RUNNER_LABEL || 'ubuntu-latest' }}
    timeout-minutes: 15
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 1

      - uses: anthropics/claude-code-action@v1
        with:
          anthropic_api_key: ${{ secrets.ANTHROPIC_API_KEY }}
          claude_args: "--max-turns 20 --model sonnet"
```

#### `.github/workflows/claude-review.yml` — Automatisches Code Review

Läuft bei jedem PR automatisch. Claude reviewt den Diff, prüft gegen die Coding Guidelines und postet Findings als Review-Kommentare.

```yaml
name: Claude Code Review

on:
  pull_request:
    types: [opened, synchronize]

permissions:
  contents: read
  pull-requests: write

jobs:
  review:
    runs-on: ubuntu-latest
    # Nicht für Dependabot PRs (die werden auto-gemergt)
    if: github.actor != 'dependabot[bot]'
    timeout-minutes: 10
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - uses: anthropics/claude-code-action@v1
        with:
          anthropic_api_key: ${{ secrets.ANTHROPIC_API_KEY }}
          prompt: |
            Reviewe diesen Pull Request. Lies .claude/ für die Coding-Konventionen.

            Prüfe insbesondere:
            1. Coding Guidelines: declare(strict_types=1), final readonly class, Value Objects, Early Returns, max 20 Zeilen/Methode, max 3 Parameter
            2. Fehlt ein Test? Jeder neue Code-Pfad braucht einen Test.
            3. Naming: Verben für Methoden, Exception-Suffix, Enums für Status-Felder
            4. Domain-Isolation: Keine Framework-Imports in Domain-Services
            5. TypeScript: strict, kein any, Svelte 5 Runes (nicht Legacy $:)
            6. i18n: Keine hardcoded User-facing Strings
            7. Security: Keine Secrets im Code, kein unsicherer Input-Handling

            Poste deine Findings als Review-Kommentare auf den relevanten Zeilen.
            Sei konstruktiv — erkläre warum etwas problematisch ist und wie man es besser macht.
            Ignoriere rein kosmetische Issues die ECS/Rector automatisch fixen würden.

          claude_args: "--max-turns 10 --model sonnet"
```

#### `.github/PULL_REQUEST_TEMPLATE.md`

```markdown
## Was ändert sich?

<!-- Kurze Beschreibung -->

## Typ

- [ ] Feature
- [ ] Bugfix
- [ ] Refactoring
- [ ] Dependency-Update
- [ ] Docs

## Checkliste

- [ ] Tests geschrieben/aktualisiert
- [ ] PHPStan + ECS + Rector lokal grün (`make quality`)
- [ ] Keine neuen `@phpstan-ignore` ohne Begründung
- [ ] Strings externalisiert (i18n)
- [ ] Migrations beigefügt (falls DB-Änderungen)
```

