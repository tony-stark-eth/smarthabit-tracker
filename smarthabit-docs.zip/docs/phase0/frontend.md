# Frontend — SvelteKit Setup

#### `package.json`

```json
{
    "name": "frontend",
    "private": true,
    "type": "module",
    "scripts": {
        "dev": "vite dev",
        "build": "vite build",
        "preview": "vite preview",
        "check": "svelte-kit sync && svelte-check --tsconfig ./tsconfig.json",
        "check:watch": "svelte-kit sync && svelte-check --tsconfig ./tsconfig.json --watch",
        "lint": "eslint .",
        "format": "prettier --write ."
    },
    "devDependencies": {
        "@sveltejs/adapter-static": "latest",
        "@sveltejs/kit": "^2",
        "@sveltejs/vite-plugin-svelte": "latest",
        "svelte": "^5",
        "svelte-check": "latest",
        "typescript": "^5.7",
        "vite": "^6",
        "eslint": "latest",
        "eslint-plugin-svelte": "latest",
        "prettier": "latest",
        "prettier-plugin-svelte": "latest",
        "tailwindcss": "^4",
        "@tailwindcss/vite": "latest"
    }
}
```

**`adapter-static`** = SPA-Modus, kein SSR. Die richtige Wahl für Apps hinter Login (wie SmartHabit), aber mit Implikationen: kein SEO für öffentliche Seiten (Landing, Datenschutz), kein Server-Side Auth-Check (alles client-seitig), keine Progressive Enhancement bei deaktiviertem JS. Wer aus dem Template forkt und öffentliche Seiten mit SEO braucht, muss auf `adapter-node` oder `adapter-auto` umsteigen.

#### `tsconfig.json`

```json
{
    "compilerOptions": {
        "strict": true,
        "noUncheckedIndexedAccess": true,
        "noImplicitOverride": true,
        "exactOptionalPropertyTypes": true,
        "noFallthroughCasesInSwitch": true
    }
}
```

#### `vite.config.ts` — API Proxy (kein CORS nötig)

Frontend und Backend laufen über **denselben Origin** — kein CORS, kein `nelmio/cors-bundle`:

- **Prod**: Caddy served statisches Frontend + PHP API unter einer Domain
- **Dev**: Vite Proxy leitet `/api/*` an den FrankenPHP-Container weiter

```typescript
import { sveltekit } from '@sveltejs/kit/vite';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig } from 'vite';

export default defineConfig({
    plugins: [tailwindcss(), sveltekit()],
    server: {
        proxy: {
            '/api': {
                target: 'https://localhost',  // FrankenPHP container
                changeOrigin: true,
                secure: false,                // Self-signed cert in dev
            },
            '/.well-known/mercure': {
                target: 'https://localhost',  // Mercure Hub (in Caddy)
                changeOrigin: true,
                secure: false,
                ws: true,                     // WebSocket für SSE fallback
            },
        },
    },
});
```

Der Browser sieht nur `localhost:5173` (Vite), alle API-Calls gehen transparent an Symfony. In Prod served Caddy alles unter einer Domain — der Proxy existiert dort nicht.

#### `src/lib/api/client.ts`

Generischer Fetch-Wrapper:
- Base-URL: `/api/v1` (relativ — funktioniert in Dev via Proxy und in Prod unter gleicher Domain)
- Automatisch Access-Token aus Auth-Store als `Authorization: Bearer` Header
- 401 → Refresh-Token-Flow → Retry
- Structured Error Response Type
- Generische `get<T>()`, `post<T>()`, `put<T>()`, `delete<T>()` Methoden

#### `src/routes/+page.svelte`

Minimale Landing Page die zeigt dass SvelteKit + Tailwind + Dark Mode funktionieren. Enthält:
- Dark Mode Toggle (System + Manual via CSS Custom Properties)
- Link zum Health-Endpoint (`/api/v1/health` — geht durch den Vite Proxy)
- Template-Branding das beim Forken ersetzt wird

