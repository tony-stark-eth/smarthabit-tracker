# Security, DSGVO & E-Mail
## DSGVO & Datenschutz

Pflicht für den EU-Markt. App speichert personenbezogene Daten: E-Mail, Verhaltensmuster (wann wird was erledigt), Haushaltszusammensetzung, Geräte-Tokens. Muss von Anfang an berücksichtigt werden — nachträgliches Einbauen ist ein Albtraum.

### API-Endpoints

```
GET    /api/v1/user/export       — Datenexport (Art. 20 DSGVO): alle User-Daten als JSON-Download
DELETE /api/v1/user/me           — Account-Löschung (Art. 17 DSGVO): Cascade auf alle Logs, Notifications, Push-Subscriptions
GET    /api/v1/privacy           — Aktuelle Datenschutzerklärung als JSON (Version + Text)
```

### Lösch-Kaskade

Account-Löschung löscht: User-Entity, alle HabitLogs des Users, alle NotificationLogs des Users, alle Push-Subscriptions. Habits bleiben bestehen (gehören dem Household, nicht dem User). Wenn der letzte User eines Households gelöscht wird → Household + alle Habits + alle Logs cascade-löschen.

### Aufbewahrungsfristen

- **HabitLogs**: 1 Jahr, danach automatisch anonymisiert (user_id → null) oder gelöscht. Nightly Command `app:cleanup-old-logs`.
- **NotificationLogs**: 90 Tage, dann gelöscht (reiner Debug-Zweck).
- **Account-Daten**: bis zur Löschung durch den User.
- Konfigurierbar via Environment-Variablen: `LOG_RETENTION_DAYS=365`, `NOTIFICATION_LOG_RETENTION_DAYS=90`.

### Einwilligung

- Bei Registrierung: Checkbox "Datenschutzerklärung gelesen und akzeptiert" (Pflicht, mit Timestamp + Version der DSE gespeichert).
- Push Notifications: separate Einwilligung im Frontend (Browser Permission Dialog + expliziter Opt-in im App-Flow).
- Cookie-Banner: nicht nötig — PWA nutzt keine Third-Party-Cookies, nur First-Party JWT + localStorage.

### Datenschutzerklärung

Muss enthalten: Verantwortlicher, Zweck der Verarbeitung (Habit-Tracking, Notifications), Rechtsgrundlage (Einwilligung Art. 6 Abs. 1 lit. a), Empfänger (Brevo für E-Mail, ntfy self-hosted für Push), Drittlandtransfer (Apple APNs für iOS Push — USA, Standard Contractual Clauses; Browser Push-Endpoints für Web Push), Speicherdauer, Rechte (Auskunft, Löschung, Export, Widerruf), Kontaktdaten. Als Markdown im Repo versioniert, über API abrufbar. Vorteil des self-hosted Ansatzes: Push-Daten für Android verlassen nie den eigenen Server (ntfy auf Hetzner DE).

## Security-Hardening

### Rate Limiting

Symfony Rate Limiter auf Auth-Endpoints — ohne das ist der Login-Endpoint ein Brute-Force-Ziel.

```php
// config/packages/rate_limiter.php
'login' => [
    'policy' => 'sliding_window',
    'limit' => 5,
    'interval' => '1 minute',
],
'register' => [
    'policy' => 'fixed_window',
    'limit' => 3,
    'interval' => '15 minutes',
],
'api_general' => [
    'policy' => 'sliding_window',
    'limit' => 60,
    'interval' => '1 minute',
],
```

Zusätzlich: Caddy als **erste Rate-Limit-Schicht** vor PHP — schneller weil kein PHP-Bootstrapping nötig:

```
# Caddyfile — Rate Limiting auf Infrastruktur-Ebene
route /api/v1/login {
    rate_limit {remote.ip} 5r/m 429
}
route /api/v1/register {
    rate_limit {remote.ip} 3r/15m 429
}
route /api/v1/password/* {
    rate_limit {remote.ip} 3r/15m 429
}
```

Zwei Schichten: Caddy blockt offensichtlichen Brute-Force bevor PHP überhaupt berührt wird, Symfony Rate Limiter handled die feinere Logik (pro User, mit Sliding Window).

### Erweiterte Auth-Flows

- **E-Mail-Verification**: Nach Registrierung → Verification-Mail mit Token-Link. Account ist eingeschränkt bis verifiziert (kann loggen, aber nicht einladen). Symfony hat `SymfonyCasts\Bundle\VerifyEmail\VerifyEmailBundle`.
- **Passwort-Reset**: `POST /api/v1/password/forgot` → Token per Mail → `POST /api/v1/password/reset` mit Token + neuem Passwort. Token ist 1h gültig, einmalig verwendbar.
- **Passwort-Änderung**: `PUT /api/v1/user/password` mit altem + neuem Passwort (für eingeloggte User).

### Weitere Maßnahmen

- **Same-Origin Architektur**: Frontend und API laufen unter derselben Domain (Caddy in Prod, Vite Proxy in Dev) — kein CORS nötig, kein `nelmio/cors-bundle`.
- **CSP Headers**: Caddy-Config, `Content-Security-Policy` mit striktem `script-src`.
- **Input Validation**: Symfony Validator mit Attributes auf allen DTOs. Kein raw User-Input in Queries.
- **Household Isolation**: Middleware/Voter der prüft dass jeder API-Zugriff nur Daten des eigenen Households betrifft. Unit-getestet.
- **JWT Blacklist**: Bei Passwort-Änderung/Reset werden alle bestehenden Refresh-Tokens invalidiert.

## E-Mail (Symfony Mailer + Brevo)

### Warum Brevo

Kostenlos (300 Mails/Tag Free Tier), EU-basiert (DSGVO-konform), offizielle Symfony Mailer Bridge (`symfony/brevo-mailer`). Kein eigener Mailserver, kein SMTP-Setup, kein Deliverability-Problem. Für eine Household-App mit wenigen Usern reichen 300 Mails/Tag locker.

### Setup

```bash
composer require symfony/brevo-mailer
```

```
# .env
MAILER_DSN=brevo+api://API_KEY@default
```

### Mail-Typen

- **Verification-Mail**: Nach Registrierung, Token-Link zur Bestätigung
- **Passwort-Reset**: Token-Link, 1h gültig
- **Household-Einladung**: Optional — statt nur Invite-Code auch per Mail einladen
- **Welcome-Mail**: Nach erfolgreicher Verification

### Async via Messenger

Alle Mails gehen über Symfony Messenger (async). Der Mailer ist bereits Messenger-aware — `MAILER_DSN` + `messenger.yaml` Config reicht. Kein eigener Handler nötig. Mails blockieren nie den Request.

### Templates

Symfony Mailer + Twig für Mail-Templates (ja, Twig — nur für Mails, nicht für die App). Zweisprachig via Symfony Translator: Template nutzt `{{ 'email.verification.subject'|trans({}, 'messages', user.locale) }}`.
