# Testing & Code-Qualität
## Testing & Code-Qualität

Qualität ist kein Phase-4-Feature. Das Tooling steht ab Commit 1, CI blockt bei Verstößen.

### Composer Dev-Dependencies

```
phpunit/phpunit: ^13.0
infection/infection: ^0.32
phpstan/phpstan: ^2.1
phpstan/phpstan-symfony: *
phpstan/phpstan-doctrine: *
phpstan/phpstan-phpunit: *
phpstan/phpstan-strict-rules: *
phpstan/phpstan-deprecation-rules: *
phpstan/extension-installer: *
shipmonk/phpstan-rules: *
voku/phpstan-rules: ^3.6
tomasvotruba/cognitive-complexity: ^1.0
tomasvotruba/type-coverage: ^2.1
phpat/phpat: ^0.12
rector/rector: *
symplify/easy-coding-standard: *
symfony/browser-kit: ^8.0
symfony/css-selector: ^8.0
symfony/phpunit-bridge: ^8.0
doctrine/doctrine-fixtures-bundle: ^4.0
zenstruck/foundry: ^2.0
captainhook/captainhook: ^5.0
captainhook/plugin-composer: ^5.0
captainhook/plugin-composer: ^5.0
```

### PHPUnit 13 — Path Coverage + Sealed Test Doubles

PHPUnit 13 (Feb 2026, erfordert PHP 8.4+) mit PCOV für Path Coverage. Wichtige Neuerungen in v13:

- **Sealed Test Doubles**: `$mock->seal()` verhindert nachträgliche Konfiguration — erzwingt vollständige Setup-Phase vor dem Test-Act
- **`createStub()` vs `createMock()`**: v13 erzwingt die Unterscheidung. `createMock()` nur wenn Invocation-Verification nötig (mit `expects()`), sonst `createStub()`
- **`withParameterSetsInOrder()` / `withParameterSetsInAnyOrder()`**: Ersatz für das längst entfernte `withConsecutive()`

Konfiguration in `phpunit.xml.dist`:

```xml
<phpunit
    colors="true"
    failOnRisky="true"
    failOnWarning="true"
    executionOrder="random"
>
    <coverage pathCoverage="true">
        <include>
            <directory suffix=".php">src</directory>
        </include>
        <exclude>
            <directory>src/Entity</directory>    <!-- Entities sind DTOs -->
            <directory>src/Kernel.php</directory>
        </exclude>
        <report>
            <html outputDirectory="var/coverage"/>
            <clover outputFile="var/coverage/clover.xml"/>
        </report>
    </coverage>
    <testsuites>
        <testsuite name="unit">
            <directory>tests/Unit</directory>
        </testsuite>
        <testsuite name="integration">
            <directory>tests/Integration</directory>
        </testsuite>
    </testsuites>
</phpunit>
```

Im FrankenPHP Dockerfile wird `ext-pcov` in der Dev-Stage installiert via `install-php-extensions pcov`. PCOV ist ~5x schneller als Xdebug für Coverage.

### Unit Tests

Fokus auf Domain-Logik, kein IO. Alles was Entscheidungen trifft wird unit-getestet:

**TimeWindowChecker** — die Kernlogik ob ein Habit gerade im Zeitfenster liegt. Testfälle: innerhalb Fenster, außerhalb, exakte Grenze, Mitternachts-Überlappung (23:00-01:00), verschiedene Timezones, DST-Wechsel.

**TimeWindowLearner** — MAD-Algorithmus. Testfälle: normaler Datensatz, zu wenig Daten (<7 Logs), Ausreißer-Robustheit, Weekday/Weekend Split, Minimum-Fensterbreite 30min.

**PushSubscriptionManager** — Subscription hinzufügen (web_push, ntfy, apns), entfernen, Duplikat-Check, Cleanup für stale Subscriptions, verschiedene Subscription-Typen mischen.

**NotifyHandler** — Multi-Transport-Dispatch-Logik. Testfälle: User mit gemischten Subscription-Typen, Fehlerbehandlung pro Transport (410 Gone → entfernen, 429 → Retry), Fallback wenn ein Transport ausfällt während andere funktionieren. Stubs für WebPushService, NtfyClient, ApnsTransport.

**HabitCompletionChecker** — "Wurde heute schon erledigt?" mit Timezone-Awareness. Testfälle: Log von gestern 23:59 UTC das in User-Timezone "heute" ist, und umgekehrt.

**InviteCodeGenerator** — Eindeutigkeit, Format, Kollisionsbehandlung.

**HouseholdIsolationVoter** — Security Voter der prüft ob ein User auf Ressourcen seines Households zugreifen darf. Testfälle: eigenes Household → erlaubt, fremdes Household → denied, kein Household → denied, Admin-Override (falls später nötig).

**AccountDeletionService** — Lösch-Kaskade. Testfälle: User mit Logs → alles gelöscht, letzter User im Household → Household cascade, User mit Push-Subscriptions → alle entfernt, User mit NotificationLogs → alle entfernt.

**DataExportService** — DSGVO-Export. Testfälle: Export enthält alle User-Daten, Export enthält alle Logs, Export enthält keine Daten anderer User, Export-Format ist valides JSON.

**RateLimiterConfig** — Nicht direkt unit-testbar, aber die Konfiguration wird in Integration Tests verifiziert.

Jeder Unit-Test:
- Keine DB, kein Filesystem, kein HTTP
- `createStub()` statt `createMock()` wo keine Invocation-Verification nötig (PHPUnit 13 enforced das)
- Echte Mocks nur für externe Services (Web Push, ntfy, APNs) — mit `seal()` für strikte Konfiguration
- `#[CoversClass(...)]` Attribut auf jeder Testklasse
- Data Providers für Edge-Cases statt duplizierte Tests

### Integration Tests

Testen die Zusammenarbeit realer Komponenten mit einer echten PostgreSQL-Instanz (Docker in CI):

**Repository-Tests** — Doctrine Repositories mit echten Queries. Besonders wichtig für die Dashboard-Query (JOIN über Habits + Logs + Users), den Zeitfenster-Check (PostgreSQL TIME-Vergleiche), und die Lösch-Kaskade (DSGVO Account-Deletion).

**API-Tests** — Symfony `WebTestCase` mit echten HTTP-Requests gegen die App:
- Auth-Flow: Register → Verification-Mail → Login → JWT → geschützter Endpoint
- Passwort-Reset: Forgot → Token-Mail → Reset → alter JWT ungültig
- CRUD-Operationen + Validierung (invalide Timezone, fehlende Pflichtfelder, i18n Error-Messages)
- Household-Isolation: User A sieht nicht die Habits von Household B (Security Voter)
- Rate Limiting: 6. Login-Versuch → 429 Too Many Requests
- DSGVO: `GET /export` liefert vollständige Daten, `DELETE /user/me` cascade-löscht alles
- Push-Subscription CRUD: Registrieren, Updaten, Löschen für alle drei Typen

**Messenger-Tests** — CheckHabitsCommand erzeugt die richtigen Messages? NotifyHandler dispatcht an die richtigen User? Push-Fehler werden korrekt behandelt (Subscription entfernt bei 410, Retry bei 429)? Mock nur die Push-Clients selbst (WebPush, ntfy HTTP, APNs), alles andere real.

**Mercure-Tests** — Wird ein Mercure Update published wenn ein Log erstellt wird? Enthält das Update die richtigen Daten? Ist das Topic Household-scoped?

**E-Mail-Tests** — Symfony Mailer hat eingebautes Test-Tooling (`assertEmailCount()`, `assertEmailSent()`). Testen: Verification-Mail nach Register, Reset-Mail nach Forgot, korrekte Sprache basierend auf User-Locale, Links in Mails sind gültig.

**Cleanup-Command-Tests** — `app:cleanup-push-subscriptions` entfernt stale Subscriptions, behält aktive. `app:cleanup-old-logs` anonymisiert/löscht Logs nach Aufbewahrungsfrist.

Test-DB wird per `doctrine:schema:create` vor jeder Suite aufgebaut und nach jedem Test via Transaction-Rollback zurückgesetzt (Symfony `ResetDatabase`-Trait oder manuelles `beginTransaction`/`rollBack`).

### Mutation Testing — Infection

Infection läuft ausschließlich gegen die Unit-Test-Suite (nicht Integration). Gegen Integrationstests wäre es zu langsam und würde Timeouts erzeugen. Konfiguration in `infection.json5`:

```json5
{
    "$schema": "vendor/infection/infection/resources/schema.json",
    "source": {
        "directories": ["src"],
        "excludes": [
            "Entity",
            "Kernel.php",
            "Controller",     // Controller-Logik ist dünn, getestet via Integration
            "Command"         // Commands sind dünn, getestet via Integration
        ]
    },
    "logs": {
        "text": "var/infection/infection.log",
        "html": "var/infection/infection.html",
        "summary": "var/infection/summary.log"
    },
    "mutators": {
        "@default": true
    },
    "phpUnit": {
        "configDir": ".",
        "customPath": "vendor/bin/phpunit"
    },
    "testFramework": "phpunit",
    "testFrameworkOptions": "--testsuite=unit",
    "minMsi": 80,
    "minCoveredMsi": 90
}
```

Zielwerte: MSI >= 80%, Covered Code MSI >= 90%. Anfangs darf der Threshold niedriger sein, wird aber mit jeder Phase hochgezogen. Escaped Mutants werden in der CI geloggt und in PR-Reviews besprochen.

### PHPStan — Level max + Enforced Metrics

PHPStan auf Level max ab Tag 1, plus 10 Extensions die weit über das hinausgehen was PHPStan nativ prüft. Alle Extensions nutzen den `phpstan/extension-installer` und registrieren sich automatisch. Konfiguration in `phpstan.neon`:

```neon
parameters:
    level: max
    paths:
        - src
        - tests
    symfony:
        containerXmlPath: var/cache/dev/App_KernelDevDebugContainer.xml
    doctrine:
        objectManagerLoader: tests/object-manager.php
    ignoreErrors: []    # leer halten — Errors fixen, nicht ignorieren

    # ── Bleeding Edge ──────────────────────────────────────────────
    # Preview der nächsten Major-Version. Strengere Analyse, bessere
    # Type-Inference, weniger False Positives. Lohnt sich auf Greenfield.
    treatPhpDocTypesAsCertain: false
    checkUninitializedProperties: true
    checkBenevolentUnionTypes: true
    checkImplicitMixed: true
    checkTooWideReturnTypesInProtectedAndPublicMethods: true
    reportPossiblyNonexistentGeneralArrayOffset: true
    reportPossiblyNonexistentConstantArrayOffset: true
    reportAnyTypeWideningInVarTag: true

    # ── Cognitive Complexity (tomasvotruba/cognitive-complexity) ───
    # Misst die mentale Last beim Lesen — nicht Cyclomatic Complexity!
    # Jede Verschachtelung, jeder Break im linearen Flow erhöht den Score
    cognitive_complexity:
        function: 8       # Max 8 pro Methode — erzwingt Early Returns und kleine Methoden
        class: 50         # Max 50 pro Klasse — erzwingt SRP

    # ── Type Coverage (tomasvotruba/type-coverage) ────────────────
    # Misst wie viel Prozent der Properties, Parameter und Returns getypt sind
    type_coverage:
        return: 100       # 100% — jede Methode hat einen Return-Type
        param: 100        # 100% — jeder Parameter hat einen Type
        property: 100     # 100% — jede Property hat einen Type
        constant: 100     # 100% — jede Konstante hat einen Type (PHP 8.3+)
        declare: 100      # 100% — jede Datei hat declare(strict_types=1)

    # ── ShipMonk Rules (shipmonk/phpstan-rules) ───────────────────
    # ~40 extra-strikte Regeln. Alles aktiviert, gezielt deaktiviert was
    # für unser Stack nicht passt oder mit anderen Rules kollidiert.
    shipmonkRules:
        # Naming Conventions — wir enforceieren das über phpat stattdessen
        classSuffixNaming:
            superclassToSuffixMapping!:
                \Exception: Exception
                \PHPUnit\Framework\TestCase: Test
                \Symfony\Component\Console\Command\Command: Command

        # Readonly Properties — redundant, wir nutzen `final readonly class`
        enforceReadonlyPublicProperty:
            enabled: true

        # Enum Safety — kein default in match über Enums
        forbidMatchDefaultArmForEnums:
            enabled: true

        # Useless Nullable Returns — wenn null nie returned wird
        forbidUselessNullableReturn:
            enabled: true

        # Vergessene Exception-Throws — Exception erstellt aber nie geworfen
        forbidUnusedException:
            enabled: true

        # Custom Verbote — Debug-Funktionen und DateTime (mutable)
        forbidCustomFunctions:
            list:
                'var_dump': 'Debug-Code entfernen'
                'dump': 'Debug-Code entfernen'
                'dd': 'Debug-Code entfernen'
                'print_r': 'Debug-Code entfernen'
                'DateTime::__construct': 'DateTimeImmutable verwenden'

    # ── voku/phpstan-rules ────────────────────────────────────────
    # Automatisch aktiv via extension-installer. Prüft:
    # - Typ-Kompatibilität bei Operatoren (+, -, *, /, .)
    # - Assignments in Conditions (if ($x = foo()) statt if ($x === foo()))
    # - Null-Safety bei Method-Calls
    # Keine extra Konfiguration nötig — Defaults sind sinnvoll.

# ── Architecture Tests (phpat/phpat) ──────────────────────────
# Regeln die die Domain-Ordnerstruktur und Dependency-Richtung enforceieren
services:
    - class: Tests\Architecture\DomainIsolationTest
      tags: [phpat.test]
    - class: Tests\Architecture\LayerDependencyTest
      tags: [phpat.test]
    - class: Tests\Architecture\NamingConventionTest
      tags: [phpat.test]
```

#### Was die Extensions abdecken — Übersicht

| Extension | Version | Was sie prüft | Konfig nötig? |
|---|---|---|---|
| `phpstan-strict-rules` | * | Strikte Typ-Vergleiche (`===`), kein `empty()`, keine dynamischen Method Calls, strikte `in_array()` etc. | Nein (auto) |
| `phpstan-deprecation-rules` | * | Nutzung von deprecated Code (PHP, Symfony, Doctrine) — wichtig bei Major-Upgrades | Nein (auto) |
| `shipmonk/phpstan-rules` | * | ~40 Regeln: Enum-Safety, vergessene Exceptions, Nullable-Returns, Custom-Verbote, Comparison-Safety | Ja (siehe oben) |
| `voku/phpstan-rules` | ^3.6 | Operator-Typ-Kompatibilität, Assignment-in-Condition, Null-Safety | Nein (auto) |
| `tomasvotruba/cognitive-complexity` | ^1.0 | Cognitive Complexity pro Methode (max 8) und Klasse (max 50) | Ja (siehe oben) |
| `tomasvotruba/type-coverage` | ^2.1 | Type-Declaration-Coverage: return, param, property, constant, declare | Ja (siehe oben) |
| `phpat/phpat` | ^0.12 | Architektur-Regeln: Domain-Isolation, Layer-Dependencies, Naming | Ja (services) |
| `phpstan-symfony` | * | Container-aware: korrekte Service-Typen, Route-Parameter, Twig | Nein (auto) |
| `phpstan-doctrine` | * | Entity-Mapping, Repository-Returns, Query Builder | Nein (auto) |
| `phpstan-phpunit` | * | Mock-Type-Inference, TestCase-Methoden, Assert-Types | Nein (auto) |

**Warum so viele?** Jedes Paket deckt eine andere Lücke ab. PHPStan Level max + strict-rules prüft Typen und Logik. ShipMonk fängt Enum-Fehler, vergessene Exceptions und unsichere Casts. voku prüft Operator-Kompatibilität. Cognitive Complexity und Type Coverage enforceieren Metriken. phpat enforceiert Architektur. Deprecation-Rules warnen frühzeitig bei API-Änderungen in Symfony 8.x oder PHP 8.4. Die Kombination ist der Punkt — einzeln wäre jedes Paket optional, zusammen schließen sie fast alle Lücken die manuelles Code Review sonst fangen müsste.

**Cognitive Complexity 8 pro Methode** — das ist streng, aber machbar. Zum Vergleich: Sonar's Default ist 15. Unser Wert von 8 erzwingt Early Returns, kleine Methoden und keine verschachtelten Conditionals. Wenn eine Methode die Grenze reißt, ist das ein klares Signal zum Extrahieren.

**Type Coverage 100%** — wir starten auf einem neuen Projekt mit PHP 8.4, es gibt keinen Legacy-Code. 100% ab Tag 1 ist der richtige Moment, danach wird es nie einfacher.

**ShipMonk `forbidCustomFunctions`** — besonders wichtig: `DateTime::__construct` ist verboten, nur `DateTimeImmutable`. Und `var_dump`/`dump`/`dd` können nicht versehentlich committed werden.

### Architecture Tests (phpat)

PHPat erzwingt Dependency-Regeln als PHPStan-Extension — keine separaten Tests nötig, läuft im gleichen CI-Step.

```php
// tests/Architecture/DomainIsolationTest.php
use PHPat\Selector\Selector;
use PHPat\Test\Builder\Rule;
use PHPat\Test\PHPat;

final class DomainIsolationTest
{
    // Domain-Services dürfen nicht von Symfony abhängen (keine Framework-Kopplung)
    public function testDomainDoesNotDependOnFramework(): Rule
    {
        return PHPat::rule()
            ->classes(Selector::inNamespace('App\Habit\Service'))
            ->andClasses(Selector::inNamespace('App\Notification\Service'))
            ->shouldNotDependOn()
            ->classes(
                Selector::inNamespace('Symfony'),
                Selector::inNamespace('Doctrine'),
            );
    }

    // Entities haben keine Abhängigkeit auf Services
    public function testEntitiesAreIsolated(): Rule
    {
        return PHPat::rule()
            ->classes(Selector::inNamespace('App\*\Entity'))
            ->shouldNotDependOn()
            ->classes(
                Selector::inNamespace('App\*\Service'),
                Selector::inNamespace('App\*\Repository'),
            );
    }
}

// tests/Architecture/LayerDependencyTest.php
final class LayerDependencyTest
{
    // Household darf nicht von Notification abhängen (Dependency-Richtung)
    public function testHouseholdDoesNotDependOnNotification(): Rule
    {
        return PHPat::rule()
            ->classes(Selector::inNamespace('App\Household'))
            ->shouldNotDependOn()
            ->classes(Selector::inNamespace('App\Notification'));
    }

    // Controller hängen von Services ab, nicht umgekehrt
    public function testServicesDoNotDependOnControllers(): Rule
    {
        return PHPat::rule()
            ->classes(Selector::inNamespace('App\*\Service'))
            ->shouldNotDependOn()
            ->classes(Selector::inNamespace('App\*\Controller'));
    }
}

// tests/Architecture/NamingConventionTest.php
final class NamingConventionTest
{
    // Alle Exceptions müssen in einem Exception-Namespace leben
    public function testExceptionsInCorrectNamespace(): Rule
    {
        return PHPat::rule()
            ->classes(Selector::extends(\RuntimeException::class))
            ->shouldBeInNamespace('App\*\Exception');
    }
}
```

Kein `ignoreErrors` als Mülleimer. Wenn PHPStan etwas moniert, wird es gefixt oder es gibt ein `@phpstan-ignore` mit Begründung direkt im Code.

### Rector — Automatische Code-Modernisierung

Rector hält den Code auf PHP 8.4 / Symfony 8 Niveau. Läuft im CI als Check (`--dry-run`), lokal als Auto-Fix. Konfiguration in `rector.php`:

```php
use Rector\Config\RectorConfig;
use Rector\Set\ValueObject\SetList;
use Rector\Symfony\Set\SymfonySetList;
use Rector\Doctrine\Set\DoctrineSetList;
use Rector\PHPUnit\Set\PHPUnitSetList;

return RectorConfig::configure()
    ->withPaths(['src', 'tests'])
    ->withPhpSets(php84: true)
    ->withSets([
        SetList::CODE_QUALITY,
        SetList::DEAD_CODE,
        SetList::EARLY_RETURN,
        SetList::TYPE_DECLARATION,
        SymfonySetList::SYMFONY_80,
        SymfonySetList::SYMFONY_CODE_QUALITY,
        DoctrineSetList::DOCTRINE_ORM_214,
        DoctrineSetList::DOCTRINE_CODE_QUALITY,
        PHPUnitSetList::PHPUNIT_130,
    ]);
```

### Easy Coding Standard (ECS)

ECS statt PHP-CS-Fixer oder PHP_CodeSniffer — eine Config, beide Tools. Konfiguration in `ecs.php`:

```php
use Symplify\EasyCodingStandard\Config\ECSConfig;

return ECSConfig::configure()
    ->withPaths(['src', 'tests'])
    ->withPreparedSets(
        psr12: true,
        common: true,
        strict: true,
        cleanCode: true,
    );
```

### CI Pipeline (GitHub Actions oder GitLab CI)

Jeder Push / PR durchläuft:

```
1. ECS Check          — Coding Standard (schnellster Check zuerst)
2. PHPStan            — Statische Analyse
3. Rector --dry-run   — Veraltete Patterns?
4. PHPUnit Unit       — mit Path Coverage
5. PHPUnit Integration — gegen PostgreSQL (Service Container in CI)
6. Infection           — Mutation Testing gegen Unit-Suite
```

Steps 1-3 laufen parallel (kein DB nötig). Steps 4-6 sequentiell (Coverage → Mutation braucht Coverage-Daten). CI schlägt fehl bei: ECS-Verstößen, PHPStan-Errors, Rector-Diff, Test-Failures, Path Coverage < 80%, MSI < 80%.

### Makefile / Composer Scripts

Lokale Shortcuts damit niemand sich die langen Commands merken muss:

```makefile
quality:        ## Alle Checks lokal
	@make ecs phpstan rector-check test infection

ecs:            ## Coding Standard (fix)
	vendor/bin/ecs check --fix

ecs-check:      ## Coding Standard (check only)
	vendor/bin/ecs check

phpstan:        ## Statische Analyse
	vendor/bin/phpstan analyse

rector:         ## Rector Auto-Fix
	vendor/bin/rector process

rector-check:   ## Rector Dry-Run
	vendor/bin/rector process --dry-run

test:           ## PHPUnit (alle Suites)
	vendor/bin/phpunit

test-unit:      ## Nur Unit Tests mit Coverage
	vendor/bin/phpunit --testsuite=unit --coverage-html=var/coverage

test-integration: ## Nur Integration Tests
	vendor/bin/phpunit --testsuite=integration

infection:      ## Mutation Testing
	vendor/bin/infection --threads=4 --show-mutations

infection-fast: ## Infection nur für geänderte Files (CI-Optimization)
	vendor/bin/infection --threads=4 --git-diff-filter=AM --git-diff-base=origin/main
```

### Test-Verzeichnisstruktur

```
tests/
├── Unit/
│   ├── Service/
│   │   ├── TimeWindowCheckerTest.php
│   │   ├── TimeWindowLearnerTest.php
│   │   ├── PushSubscriptionManagerTest.php
│   │   ├── NotifyHandlerTest.php
│   │   ├── HabitCompletionCheckerTest.php
│   │   ├── AccountDeletionServiceTest.php
│   │   ├── DataExportServiceTest.php
│   │   └── HouseholdIsolationVoterTest.php
│   ├── Util/
│   │   └── InviteCodeGeneratorTest.php
│   └── ValueObject/
│       └── TimeWindowTest.php
├── Integration/
│   ├── Repository/
│   │   ├── HabitRepositoryTest.php
│   │   ├── HabitLogRepositoryTest.php
│   │   └── NotificationLogRepositoryTest.php
│   ├── Controller/
│   │   ├── AuthControllerTest.php
│   │   ├── PasswordResetControllerTest.php
│   │   ├── HabitControllerTest.php
│   │   ├── DashboardControllerTest.php
│   │   ├── LogControllerTest.php
│   │   ├── PushSubscriptionControllerTest.php
│   │   ├── UserExportControllerTest.php
│   │   ├── UserDeletionControllerTest.php
│   │   └── RateLimitingTest.php
│   ├── Messenger/
│   │   ├── CheckHabitsHandlerTest.php
│   │   └── NotifyHabitHandlerTest.php
│   ├── Mercure/
│   │   └── HabitLogMercurePublishTest.php
│   ├── Email/
│   │   ├── VerificationEmailTest.php
│   │   └── PasswordResetEmailTest.php
│   └── Command/
│       ├── CleanupPushSubscriptionsCommandTest.php
│       └── CleanupOldLogsCommandTest.php
├── Factory/              — Object Mothers / Factories für Test-Daten
│   ├── HabitFactory.php
│   ├── UserFactory.php
│   └── HouseholdFactory.php
├── Architecture/         — phpat Architecture Tests (laufen via PHPStan, nicht PHPUnit)
│   ├── DomainIsolationTest.php
│   ├── LayerDependencyTest.php
│   └── NamingConventionTest.php
└── bootstrap.php
```

