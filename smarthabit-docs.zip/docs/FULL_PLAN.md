# SmartHabit Tracker — Projektplan

## Tech Stack (aktuelle Versionen)

| Komponente | Version | Hinweise |
|---|---|---|
| **PHP** | 8.4 | Property hooks, asymmetric visibility |
| **Symfony** | 8.0.7 | Invokable commands, PHP array config, Attribute-based validation |
| **Runtime** | FrankenPHP (Caddy) | Worker Mode, auto-HTTPS, HTTP/2+3 — kein nginx, kein PHP-FPM |
| **Doctrine ORM** | 3.6.x | via `symfony/orm-pack` v2.7 |
| **Datenbank** | PostgreSQL 17 | Besser als MySQL für Zeitfenster-Queries (range types, window functions) |
| **Frontend** | Svelte 5 + SvelteKit 2.x | PWA via `@vite-pwa/sveltekit`, Svelte 5 Runes, Bun als Runtime |
| **Push (PWA)** | `minishlink/web-push` | W3C Web Push Standard (RFC 8030), kein Firebase, kein Google-Account |
| **Push (Native)** | APNs (iOS) + ntfy (Android, self-hosted) | Kein Firebase. ntfy auf Hetzner VPS, APNs direkt via Symfony Notifier |
| **Testing** | PHPUnit 13.x + Infection 0.32.x | Path Coverage, sealed test doubles, Mutation Testing |
| **Statische Analyse** | PHPStan (max level), Rector, ECS | Keine Kompromisse bei Code-Qualität |
| **Auth** | `lexik/jwt-authentication-bundle` | Access + Refresh Token Flow |
| **Queue** | Symfony Messenger | Doctrine transport (kein Redis nötig im MVP) |
| **Connection Pooling** | PgBouncer 1.23 | Transaction-Mode, zwischen FrankenPHP und PostgreSQL |
| **i18n** | paraglide-sveltekit + Symfony Translator | Compile-Time i18n im Frontend, YAML-basiert im Backend |
| **Native (später)** | Capacitor 6.x | SvelteKit → iOS/Android App Store, native Widgets |
| **E-Mail** | Symfony Mailer + Brevo | 300 Mails/Tag kostenlos, DSGVO-konform (EU), offizielle Symfony Bridge |
| **Monitoring** | GlitchTip 6.x (self-hosted) | Sentry-kompatible SDKs, 512MB RAM, MIT-Lizenz |
| **Real-Time** | Mercure (in Caddy/FrankenPHP) | SSE für Live-Updates im Household, bereits im Template enthalten |
| **Deployment** | Hetzner VPS + OpenTofu | Infrastructure as Code, CD via GitHub Actions (später) |
| **Docker** | Compose v2 | Multi-stage Builds für PHP + Bun |
| **API Format** | Plain JSON | Symfony Serializer, kein API Platform |

## Docker Setup

Basierend auf `dunglas/symfony-docker` — dem offiziellen Symfony Docker Template mit FrankenPHP. Vier Services (+ Messenger Worker), ein `compose.yaml`:

```
services:
  php:              # FrankenPHP (Caddy + PHP 8.4) — Web + Worker in einem
  database:         # PostgreSQL 17
  pgbouncer:        # Connection Pooling → database:5432
  bun:              # Bun 1.3.x — SvelteKit Dev-Server (nur dev Profile)
```

### Warum FrankenPHP statt PHP-FPM + nginx

FrankenPHP ersetzt PHP-FPM **und** nginx in einem einzigen Binary. Caddy ist eingebaut (auto-HTTPS via Let's Encrypt, HTTP/2, HTTP/3). Der entscheidende Vorteil ist der **Worker Mode**: Symfony bootet einmal, bleibt im Memory, und handelt Requests ohne erneutes Bootstrapping. Das eliminiert den größten Performance-Overhead bei PHP.

Konkret fällt weg: `php-fpm`-Container, `nginx`-Container, nginx-Config, FPM Pool-Tuning, FastCGI-Socket-Kommunikation. Stattdessen ein Container der alles macht.

### `dunglas/symfony-docker` als Basis

Das Projekt wird initial per Template erstellt:

```bash
docker compose build --pull --no-cache
docker compose up
```

Das Dockerfile folgt dem Multi-Stage-Pattern aus dem Template:

```
# Stage: frankenphp_base
FROM dunglas/frankenphp:latest-php8.4 AS frankenphp_base
  → ext-pdo_pgsql, ext-intl, ext-pcov (via install-php-extensions)
  → Composer install
  → Symfony Runtime: runtime/frankenphp-symfony

# Stage: frankenphp_dev
  → Xdebug optional, PCOV für Coverage
  → Hot-Reload via Caddy file_server + watch

# Stage: frankenphp_prod (rootless, Debian Slim — 290MB statt 704MB)
  → Nur Runtime-Artefakte, kein Composer, kein Dev-Tooling
  → Worker Mode: FRANKENPHP_CONFIG="worker ./public/index.php"
```

Seit März 2026 nutzt das Template rootless Debian Slim Images in Produktion — 60% kleiner als vorher.

### Service-Details

**php** — `dunglas/frankenphp:latest-php8.4`:
- Worker Mode in Produktion: PHP bleibt im Memory, Symfony bootet einmal
- Caddy handelt TLS-Termination, HTTP/2, HTTP/3, Static Files
- Routes: `/api/*` → Symfony, alles andere → SvelteKit Build Output (via `file_server`)
- Für den Messenger Worker: zweiter Container mit gleichem Image, anderer Command

**database** — `postgres:17-alpine`, Volume für Persistence, `POSTGRES_DB=smarthabit`

**pgbouncer** — `edoburu/pgbouncer:latest` (oder `bitnami/pgbouncer`):
- Transaction-Mode Pooling: jede Query bekommt eine Connection, gibt sie danach zurück
- Im Worker Mode besonders wichtig: FrankenPHP-Worker halten persistente Connections, PgBouncer verhindert Connection-Exhaustion
- `max_client_conn=200`, `default_pool_size=20` als Startwerte
- `DATABASE_URL=postgresql://user:pass@pgbouncer:6432/smarthabit?serverVersion=17`
- Wichtig: Doctrine's `server_version` muss trotzdem auf PG 17 stehen, nicht PgBouncer

**bun** — `oven/bun:1.3-alpine`, nur im `dev` Profile aktiv:
- Mounted den `frontend/` Ordner, `bun run dev` mit HMR
- Produktions-Build: `bun run build` → statische Files, von Caddy via `file_server` served
- Kein Symfony AssetMapper — Frontend ist komplett eigenständig, Build über Bun/Vite
- `bun install` statt `npm install` (~25x schneller)

### Frontend Build-Pipeline (kein Symfony AssetMapper)

Das Frontend ist ein **eigenständiges SvelteKit-Projekt** im `frontend/`-Ordner, komplett entkoppelt von Symfony. Kein AssetMapper, kein Webpack Encore, keine Symfony-seitige Asset-Verwaltung.

```
Frontend Build: Bun + Vite (via SvelteKit)
├── Dev:  bun run dev → Vite Dev Server mit HMR auf Port 5173
├── Build: bun run build → adapter-static → /frontend/build/
└── Deploy: Caddy file_server served /frontend/build/ für alle Nicht-API-Routes
```

Warum kein AssetMapper: AssetMapper ist für Server-Rendered Symfony Apps gedacht (Twig Templates). Unsere App ist eine SPA — Symfony liefert nur eine JSON-API, das Frontend ist ein eigenständiger Build. Bun + Vite (via SvelteKit) ist der direkte Weg ohne Symfony-Overhead.

Caddy-Config im FrankenPHP Container:
```
# Caddyfile Auszug
{$SERVER_NAME} {
    # API → Symfony/FrankenPHP
    handle /api/* {
        php_server
    }
    # Alles andere → SvelteKit Static Build
    handle {
        root * /app/frontend/build
        try_files {path} /index.html
        file_server
    }
}
```

### Messenger Worker

Gleicher FrankenPHP-Container, anderer Entrypoint — als separater Service in `compose.yaml`:

```yaml
  messenger-worker:
    build:
      context: .
      target: frankenphp_dev  # oder frankenphp_prod
    command: ["php", "bin/console", "messenger:consume", "async", "--time-limit=3600"]
    restart: unless-stopped
    depends_on:
      - database
    environment:
      # WICHTIG: Messenger Worker verbindet DIREKT zur DB, nicht über PgBouncer!
      # PgBouncer Transaction-Mode unterstützt kein LISTEN/NOTIFY (Doctrine Messenger braucht das)
      DATABASE_URL: postgresql://...@database:5432/smarthabit?serverVersion=17
```

Restart-Policy: `unless-stopped` — Symfony beendet sich nach 1h (`--time-limit`), Docker startet neu. Verhindert Memory Leaks.

### Cron

Im `php`-Container via separatem Cron-Service oder Supercronic (Go-basiert, Docker-friendly):
- Alle 15min: `php bin/console app:check-habits`
- Nachts 03:00 UTC: `php bin/console app:learn-timewindows`
- Nachts 03:30 UTC: `php bin/console app:compute-stats` (Phase 5)
- Nachts 04:00 UTC: `php bin/console app:cleanup-push-subscriptions`
- Nachts 04:30 UTC: `php bin/console app:cleanup-old-logs` (DSGVO-Aufbewahrungsfristen)

Environment via `.env` + `.env.local` (Symfony-Standard), Secrets in Docker Secrets oder `.env.local` auf Server.

## Timezone-Strategie

Alles in UTC — mit einer bewussten Ausnahme für Zeitfenster. Jeder User setzt seine Timezone im Profil (Pflichtfeld bei Registration).

**Timestamps** (logged_at, sent_at, created_at): Immer UTC. PostgreSQL-Spalten als `TIMESTAMPTZ`, Doctrine-Type `datetimetz_immutable`.

**Zeitfenster** (time_window_start/end): Gespeichert als **Lokalzeit** (PostgreSQL `TIME` ohne Timezone). "07:00 Hund raus" ist ein menschliches Konzept — es wäre falsch, das in UTC umzurechnen, weil sich bei DST-Wechseln die UTC-Repräsentation ändern würde. Stattdessen bleibt 07:00 als 07:00 in der DB.

**Notification-Check** (der Kern der Timezone-Logik):
1. Cron läuft alle 15min, kennt aktuelle UTC-Zeit
2. Pro Habit → pro User im Household:
   - Aktuelle UTC-Zeit → in `User.timezone` konvertieren → ergibt User-Lokalzeit
   - User-Lokalzeit gegen `Habit.time_window_start/end` prüfen (simpler Range-Check)
   - "Heute" ist relativ zur User-Lokalzeit (für den "schon erledigt?"-Check)
3. DST-Wechsel sind kein Problem: PHP's `DateTimeZone` handled das automatisch

**Anzeige im Frontend**: API liefert UTC-Timestamps. Das Frontend konvertiert mit `Intl.DateTimeFormat` und der User-Timezone (aus JWT-Payload oder `/api/v1/user/me`).

**Multi-Timezone Household**: Lisa in Berlin und Tom in New York teilen "Hund raus" mit Fenster 07:00-09:00. Lisa bekommt die Notification wenn es in Berlin 07:00 ist, Tom wenn es in New York 07:00 ist. Der Habit hat nur ein Zeitfenster — die Per-User-Konvertierung im Check erledigt den Rest.

## Datenmodell (Doctrine Entities)

### Household

Das Kernkonzept. Alle Habits gehören einem Household, mehrere User teilen sich ein Household.

```
Household
├── id: uuid (Symfony Uid Component)
├── name: string
├── invite_code: string (unique, 8 Zeichen)
├── created_at: DateTimeImmutable (UTC)
├── updated_at: DateTimeImmutable (UTC)
```

### User

```
User
├── id: uuid
├── household_id: uuid → Household (ManyToOne)
├── display_name: string
├── email: string (unique)
├── password: string (hashed, Symfony PasswordHasher)
├── email_verified_at: DateTimeImmutable (nullable — null = nicht verifiziert)
├── timezone: string (required, z.B. "Europe/Berlin" — IANA Timezone)
├── locale: string (default "de", erlaubt: "de", "en")
├── theme: string (default "auto", erlaubt: "auto", "light", "dark")
├── push_subscriptions: json (Array von {endpoint, keys, device_name, last_seen, type} Objekten)
├── consent_at: DateTimeImmutable (Zeitpunkt der DSGVO-Einwilligung)
├── consent_version: string (Version der DSE bei Einwilligung, z.B. "1.0")
├── created_at: DateTimeImmutable (UTC)
├── updated_at: DateTimeImmutable (UTC)
```

`timezone` ist Pflichtfeld bei Registration. Das Frontend schlägt die Browser-Timezone vor (`Intl.DateTimeFormat().resolvedOptions().timeZone`), User kann überschreiben. `locale` wird ebenfalls aus dem Browser übernommen (`navigator.language`) und bestimmt die Sprache der Notifications und API-Responses. `push_subscriptions` als strukturiertes JSON-Array: jede Subscription enthält den Web Push Endpoint + VAPID Keys (PWA) oder einen ntfy-Topic (native Android) oder ein APNs Device-Token (native iOS). Feld `type` unterscheidet: `web_push`, `ntfy`, `apns`.

### Habit

```
Habit
├── id: uuid
├── household_id: uuid → Household (ManyToOne)
├── name: string
├── emoji: string
├── sort_order: int
├── notification_message: string (Translation-Key oder Custom-Text, z.B. "habit.notification.dog_walk")
├── time_window_start: time (z.B. 07:00 — Lokalzeit, NICHT UTC)
├── time_window_end: time (z.B. 09:00 — Lokalzeit, NICHT UTC)
├── time_window_mode: enum(manual, auto)
├── frequency: enum(daily, weekdays, weekends, custom)
├── frequency_days: json (null oder [1,2,3,4,5] für custom)
├── is_active: bool
├── created_at: DateTimeImmutable (UTC)
├── updated_at: DateTimeImmutable (UTC)
├── deleted_at: DateTimeImmutable (nullable — Soft-Delete)
```

Zeitfenster bewusst als Lokalzeit gespeichert (reiner `TIME`-Typ ohne Timezone in PG). Grund: "07:00 Hund raus" ist ein menschliches Konzept, kein UTC-Wert. Der Notification-Check konvertiert die aktuelle UTC-Zeit jedes Users in dessen Lokalzeit und vergleicht gegen dieses Fenster. So funktioniert DST automatisch ohne Neuberechnung.

### HabitLog

```
HabitLog
├── id: uuid
├── habit_id: uuid → Habit (ManyToOne)
├── user_id: uuid → User (ManyToOne)
├── logged_at: DateTimeImmutable (UTC, Frontend konvertiert zur Anzeige)
├── source: enum(manual, notification) — woher kam der Log?
```

### NotificationLog

Für Debugging und um Doppel-Notifications zu verhindern:

```
NotificationLog
├── id: uuid
├── habit_id: uuid → Habit
├── user_id: uuid → User
├── sent_at: DateTimeImmutable (UTC)
├── status: enum(sent, failed, clicked)
├── push_message_id: string (nullable)
├── error_reason: string (nullable — für Push-Fehlerdetails)
├── push_type: string (web_push, ntfy, apns)
```

## API Endpoints (Symfony Controller)

Alle Routen unter `/api/v1`, JSON-Responses, JWT-Auth via `lexik/jwt-authentication-bundle`.

### Auth & User

```
POST   /api/v1/register          — Neuen User + Household anlegen (timezone, locale required)
POST   /api/v1/login             — JWT Access Token + Refresh Token
POST   /api/v1/token/refresh     — Refresh Token → neues Access Token
POST   /api/v1/household/join    — Mit invite_code einem Household beitreten
GET    /api/v1/user/me           — Profil inkl. timezone, locale, theme, household, push_subscriptions
PUT    /api/v1/user/me           — Profil bearbeiten (display_name, timezone, locale, theme)
POST   /api/v1/user/push-subscription    — Push-Subscription registrieren (Web Push, ntfy, APNs)
DELETE /api/v1/user/push-subscription    — Push-Subscription entfernen (Logout/Gerätewechsel)
POST   /api/v1/password/forgot           — Passwort-Reset anfordern (E-Mail mit Token)
POST   /api/v1/password/reset            — Passwort zurücksetzen (Token + neues Passwort)
PUT    /api/v1/user/password             — Passwort ändern (altes + neues Passwort, eingeloggt)
```

### Habits

```
GET    /api/v1/habits                — Alle Habits des Households + Tagesstatus
POST   /api/v1/habits                — Neuen Habit anlegen
PUT    /api/v1/habits/{id}           — Habit bearbeiten (Name, Zeitfenster, etc.)
DELETE /api/v1/habits/{id}           — Habit löschen (Soft-Delete)
PATCH  /api/v1/habits/reorder        — Sortierung ändern
```

### Logging

```
POST   /api/v1/habits/{id}/log       — Ein-Tap Log (Body: nur source)
DELETE /api/v1/habits/{id}/log/{logId} — Log rückgängig machen
GET    /api/v1/habits/{id}/history    — Paginated History (wer, was, wann)
```

### Dashboard

```
GET    /api/v1/dashboard             — Tagesübersicht: alle Habits mit letztem Log
```

Die Dashboard-Response ist das, was die App beim Öffnen lädt — eine einzelne Query die pro Habit den heutigen Status liefert.

### Statistiken (Phase 5)

```
GET    /api/v1/habits/{id}/stats     — Streak, Completion Rate, Trend, Durchschnittszeit, User-Verteilung
GET    /api/v1/stats/household       — Gesamte Completion, Ranking, Heatmaps, aktivster User
```

### DSGVO & Account

```
GET    /api/v1/user/export           — Datenexport (Art. 20 DSGVO): alle User-Daten als JSON
DELETE /api/v1/user/me               — Account-Löschung (Art. 17 DSGVO): Cascade
GET    /api/v1/privacy               — Aktuelle Datenschutzerklärung (Version + Text)
```

### Health (kein Auth nötig)

```
GET    /api/v1/health                — DB-Connection + Messenger-Queue Status
GET    /api/v1/health/ready          — Für Docker Healthcheck (nur "up?")
```

## Frontend (SvelteKit PWA)

### Architektur

SvelteKit im **SPA-Modus** (`adapter-static`), deployed als statische Files hinter FrankenPHP/Caddy. Kein SSR nötig — die App ist komplett client-seitig nach dem Initial Load. Build komplett über Bun, kein Symfony AssetMapper.

```
frontend/
├── src/
│   ├── lib/
│   │   ├── api/          — Fetch-Wrapper, JWT Handling, Offline Queue
│   │   ├── stores/       — Svelte 5 Runes ($state, $derived) für globalen State
│   │   └── components/   — UI-Komponenten
│   ├── routes/
│   │   ├── +layout.svelte     — Shell: Auth-Check, Nav
│   │   ├── (app)/
│   │   │   ├── +page.svelte         — Dashboard (Hauptansicht)
│   │   │   ├── habits/[id]/+page.svelte  — History + Stats
│   │   │   └── settings/+page.svelte     — Household, Zeitfenster, Account
│   │   └── (auth)/
│   │       ├── login/+page.svelte
│   │       └── register/+page.svelte
│   ├── service-worker.ts     — Web Push Handler + Offline Cache
│   └── app.html
├── static/
│   └── manifest.json         — PWA Manifest
├── bun.lock                  — Bun Lockfile (statt package-lock.json)
├── svelte.config.js
└── vite.config.ts
```

### PWA-Features

- **Service Worker**: `@vite-pwa/sveltekit` für automatisches Caching
- **Offline-Fähigkeit**: Logs werden lokal gespeichert und gesynct wenn online
- **Install Prompt**: manifest.json mit Icons, Theme-Color, Start-URL
- **Push**: W3C Web Push API im Service Worker (kein Firebase SDK, VAPID-Auth)

### UI-Prinzip

Dashboard = eine Liste großer Tap-Targets. Jedes Habit ist eine Karte:
- Emoji + Name
- Letzter Log: "Heute 07:32 von Lisa" oder "Noch nicht erledigt"
- Ein Tap → POST /log → optimistisches UI-Update → Scale-Pulse Checkmark Animation
- Long Press → History

Kein Hamburger-Menü, kein Overhead. Öffnen → tippen → fertig.

### Design-Richtung: Neo Utility + Dark Mode

**Grundästhetik**: Funktional, klar, datengetrieben. Die App soll sich wie ein gut gebautes Tool anfühlen — nicht wie eine Wellness-App. Informationsdichte ohne Chaos, klare Hierarchie, alles auf den ersten Blick erfassbar.

**Typografie**:
- Headlines: `Sora` (Sans-Serif, geometrisch, modern) — 700 weight
- Body: `Sora` — 400/600 weight
- Metadaten + Monospace-Details: `JetBrains Mono` — Timestamps, Fenster-Zeiten, Stats
- Keine Serifs, kein verspieltes Lettering — das ist ein Utility-Tool

**Farbpalette Light Mode**:
```
--bg-primary:    #F4F5F7     (Hintergrund)
--bg-card:       #FFFFFF     (Karten)
--bg-header:     #FFFFFF     (Header)
--border:        #E8EAEE     (Trennlinien, Karten-Borders)
--text-primary:  #1A1D24     (Headlines, Habit-Namen)
--text-secondary:#888D98     (Subtitles, Metadaten)
--text-tertiary: #B0B4BC     (Timestamps, Nav inaktiv)
--accent:        #3366FF     (Primäre Aktion, Progress, aktiver Nav)
--success:       #22C55E     (Erledigt, Checkmarks, Done-Border)
--warning:       #E65100     (Überfälliges Zeitfenster)
--tag-blue-bg:   #F0F4FF     (Zeitfenster-Tag Hintergrund)
--tag-orange-bg: #FFF3E0     (Überfällig-Tag Hintergrund)
```

**Farbpalette Dark Mode** (Toggle in Einstellungen, respektiert `prefers-color-scheme`):
```
--bg-primary:    #0A0A0A     (Hintergrund)
--bg-card:       #141416     (Karten)
--bg-header:     #0A0A0A     (Header)
--border:        #1E1E22     (Trennlinien)
--text-primary:  #E8E8E8     (Headlines)
--text-secondary:#666A74     (Subtitles)
--text-tertiary: #444650     (Timestamps)
--accent:        #4D88FF     (Primäre Aktion, etwas heller als Light)
--success:       #5ACA46     (Erledigt)
--warning:       #FF8A50     (Überfällig)
--tag-blue-bg:   #1A1E2E     (Zeitfenster-Tag)
--tag-orange-bg: #2A1A0E     (Überfällig-Tag)
```

**Kernelemente des Neo Utility-Designs**:
- **Progress-Bar im Header**: Zeigt Tagesfortschritt (2 von 4 = 50%). Visuelles Feedback ohne Zahlen lesen zu müssen
- **Farbige Tags/Badges**: Zeitfenster als Chip (`18:00–20:00` auf blauem Hintergrund), überfällige auf orangem
- **Left-Border Indikator**: Erledigte Habits haben einen 3px grünen Left-Border, offene einen grauen — scannbar ohne Text lesen
- **Vier Nav-Items**: Today, History, Stats, Config — Stats als eigener Tab statt versteckt in den Einstellungen
- **Monospace für Daten**: Alle Uhrzeiten, Dates, Stats-Zahlen in JetBrains Mono — technisch, präzise, gut lesbar

**Dark Mode Umsetzung**:
- CSS Custom Properties + `prefers-color-scheme` Media Query als Default
- User kann in den Einstellungen überschreiben: Auto / Light / Dark
- Preference wird in `User.theme: enum(auto, light, dark)` gespeichert
- Svelte: `$state` Store der die CSS-Klasse auf `<body>` setzt
- Kein separates Stylesheet — gleiche Komponenten, nur Variablen-Swap

**Micro-Interactions**:
- Tap auf Check-Button: kurzer Scale-Pulse (0.9 → 1.1 → 1.0) + Farb-Transition zu Grün
- Progress-Bar animiert sanft beim Update (CSS `transition: width 0.4s ease-out`)
- Karten staggered erscheinen beim ersten Load (`animation-delay` pro Karte)
- Kein Confetti, keine Bouncing-Elemente — das Tool bleibt sachlich

## Notification System

### Push-Architektur (kein Firebase)

Drei Push-Kanäle, alle ohne US-Dienste:

**1. Web Push (PWA)** — W3C Standard (RFC 8030), via `minishlink/web-push`:
- VAPID Key-Pair generieren: `openssl ecparam -genkey -name prime256v1 -out private.pem` (einmalig)
- Public Key im Frontend für `PushManager.subscribe()`, Private Key im Backend für `minishlink/web-push`
- Keys als Environment-Variablen: `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY` (nicht im Repo!)
- Browser fragt User um Permission → erzeugt PushSubscription (Endpoint + Keys)
- Frontend schickt Subscription an `POST /api/v1/user/push-subscription`
- Backend sendet verschlüsselte Payloads direkt an den Browser-Endpoint (VAPID-Auth)
- Funktioniert auf Chrome, Firefox, Edge, Safari 16.4+ — ohne Firebase SDK
- Die Browser routen intern über ihre eigenen Push-Dienste (Google/Mozilla/Apple), aber das ist Browser-Infrastruktur, kein Firebase

**2. ntfy (Native Android)** — self-hosted auf dem Hetzner VPS:
- Leichtgewichtiger Open-Source Push-Server (~10MB Binary, minimal RAM)
- App subscribed auf einen User-spezifischen ntfy-Topic (z.B. `smarthabit-user-{uuid}`)
- Backend published via einfachen HTTP POST: `POST https://ntfy.smarthabit.de/{topic}`
- Unterstützt UnifiedPush-Protokoll (offener Standard, kein Google)
- Docker-Container neben der App auf dem gleichen VPS

**3. APNs (Native iOS)** — Apple Push Notification service direkt:
- Einziger Weg für iOS Push, aber kein Firebase dazwischen nötig
- `symfony/notifier` hat einen nativen APNs-Transport
- Direkte HTTP/2-Verbindung zu api.push.apple.com mit JWT-Auth

### Cron-basierter Notification-Check

Ein Cron-Job dispatcht alle 15 Minuten ein `CheckHabitsMessage`:

```
Cron (alle 15min)
  → bin/console app:check-habits
    → Alle aktiven Habits mit Household + Users laden (JOIN)
    → Pro Habit, pro User im Household:
      → User-Lokalzeit berechnen: UTC now → User.timezone
      → Ist User-Lokalzeit innerhalb Habit.time_window_start/end?
      → Ist heute ein aktiver Tag? (frequency + frequency_days prüfen)
      → Wurde heute (in User-Lokalzeit!) schon erledigt? (HabitLog check)
      → Wurde heute schon eine Notification an diesen User geschickt?
      → Wenn nein: Dispatch NotifyHabitMessage an Messenger
        → Handler: Push an alle Subscriptions dieses Users
          → Web Push Subscriptions → minishlink/web-push
          → ntfy Subscriptions → HTTP POST an ntfy-Server
          → APNs Subscriptions → Symfony Notifier APNs Transport
```

Durch die Per-User-Prüfung funktioniert Multi-Timezone korrekt: Lisa in Berlin bekommt die Notification um 07:00 CET, Tom in New York um 07:00 EST — obwohl es der gleiche Habit ist.

### NotifyHandler (Multi-Transport)

```php
// Vereinfachte Logik
foreach ($user->getPushSubscriptions() as $subscription) {
    match ($subscription['type']) {
        'web_push' => $this->webPushService->send($subscription, $payload),
        'ntfy'     => $this->ntfyClient->publish($subscription['topic'], $payload),
        'apns'     => $this->apnsTransport->send($subscription['device_token'], $payload),
    };
}
```

Jeder Transport hat eigene Fehlerbehandlung. Fehlgeschlagene Subscriptions werden im NotificationLog mit `error_reason` und `push_type` geloggt.

### Auto-Zeitfenster (Lernend)

Ein Nightly-Command (`app:learn-timewindows`) analysiert die Logs der letzten 21 Tage:

```
1. Alle logged_at (UTC) Zeiten für einen Habit sammeln
2. Pro Log: UTC → User.timezone konvertieren, dann Minuten seit Mitternacht
3. Median berechnen = übliche Lokalzeit
4. MAD (Median Absolute Deviation) = robuster als Stddev gegen Ausreißer
5. Fenster = Median ± (1.5 × MAD), mindestens 30min breit
6. Weekday/Weekend Split wenn Pattern erkannt (>= 7 Datenpunkte pro Gruppe)
7. Habit.time_window_start/end updaten (als Lokalzeit), time_window_mode → auto
```

Warum MAD statt Standardabweichung: Ein einzelner Ausreißer (Hund um 23:00 rausgelassen weil Gäste da waren) verschiebt die Stddev massiv. MAD ist robust dagegen.

User kann jederzeit zurück auf manuell wechseln.

### ntfy Docker-Setup

Läuft als zusätzlicher Service auf dem Hetzner VPS, eigenes Compose oder im App-Stack:

```yaml
ntfy:
  image: binwiederhier/ntfy:latest
  command: serve
  restart: unless-stopped
  ports: ["127.0.0.1:2586:80"]  # nur intern, Caddy proxied
  volumes:
    - ntfy-cache:/var/cache/ntfy
    - ./ntfy/server.yml:/etc/ntfy/server.yml
  environment:
    TZ: UTC
```

Caddy-Route: `ntfy.smarthabit.de` → `ntfy:80` mit auto-HTTPS. Auth via Token-basiertem Access Control — nur der App-Server darf publishen, User subscriben über ihre Topics.

## Push Subscription Lifecycle

Push Subscriptions sind kurzlebig und unterschiedlich pro Plattform. Drei Mechanismen halten die Liste sauber:

**1. Registrierung** — Frontend/App schickt Subscription bei jedem Start via `POST /api/v1/user/push-subscription`. Idempotent: existierende Subscription wird aktualisiert (last_seen), neue wird hinzugefügt.

```
push_subscriptions: [
  {
    "type": "web_push",
    "endpoint": "https://updates.push.services.mozilla.com/wpush/v2/...",
    "keys": { "p256dh": "...", "auth": "..." },
    "device_name": "Chrome Desktop",
    "last_seen": "2026-03-21T10:00:00Z"
  },
  {
    "type": "ntfy",
    "topic": "smarthabit-user-abc123",
    "device_name": "Android Lisa",
    "last_seen": "2026-03-20T08:00:00Z"
  },
  {
    "type": "apns",
    "device_token": "a1b2c3...",
    "device_name": "iPhone Lisa",
    "last_seen": "2026-03-21T09:00:00Z"
  }
]
```

**2. Fehlerbehandlung im NotifyHandler**:
- Web Push: HTTP 410 (Gone) → Subscription entfernen. HTTP 429 → Retry mit Backoff.
- ntfy: HTTP 5xx → Retry. Topic existiert nicht → Subscription entfernen.
- APNs: Status 410 (Unregistered) → Subscription entfernen. Status 429 → Retry.

**3. Nightly Cleanup** — `app:cleanup-push-subscriptions` (Cron 04:00 UTC):
- Subscriptions mit `last_seen` älter als 30 Tage werden entfernt
- Schützt gegen vergessene Geräte (altes Handy, deinstallierte App)
- Loggt Cleanup-Aktionen für Debugging

**Logout** — `DELETE /api/v1/user/push-subscription` entfernt die Subscription des aktuellen Geräts explizit.

## Internationalisierung (i18n)

Von Tag 1 zweisprachig: Deutsch + Englisch. Nachträglich i18n einbauen ist einer der schmerzhaftesten Refactors — deshalb direkt.

### Frontend: paraglide-sveltekit

Paraglide (von Inlang) ist der i18n-Standard für SvelteKit. Kompiliert Übersetzungen zur Build-Zeit, zero Runtime-Overhead, vollständig typesichere Message-Keys.

```
frontend/
├── messages/
│   ├── de.json      — { "dashboard.greeting": "Guten Morgen 👋", ... }
│   └── en.json      — { "dashboard.greeting": "Good morning 👋", ... }
├── src/
│   ├── lib/i18n/    — paraglide Runtime (generiert)
│   └── ...
```

Verwendung im Svelte-Code:
```svelte
<script>
  import * as m from '$lib/i18n/messages';
</script>
<h1>{m.dashboard_greeting()}</h1>
```

Vorteile gegenüber Runtime-i18n-Libraries: Tree-Shaking (unbenutzte Messages fallen raus), TypeScript-Autocomplete für alle Keys, kein JSON-Parsing zur Laufzeit.

**Spracherkennung**: `Accept-Language` Header → Browser-Sprache als Default. User kann in den Einstellungen überschreiben. Sprach-Präferenz wird im `User`-Entity gespeichert (`locale: string`, Default `de`).

### Backend: Symfony Translator

Symfony's eingebauter Translator für alles was vom Server kommt:

```
translations/
├── messages.de.yaml   — notification_texts, validation_messages, error_messages
└── messages.en.yaml
```

Relevant für: Notification-Texte ("Warst du heute schon mit dem Hund draußen?" / "Have you walked the dog today?"), Validation-Errors (API-Responses), E-Mail-Templates (falls später benötigt).

Das `Habit.notification_message`-Feld wird zu einem Translation-Key statt hartem Text. Der NotifyHandler resolvet den Key gegen die Sprache des Ziel-Users.

### User-Entity Erweiterung

Die Felder `locale`, `theme`, `consent_at`, `consent_version` und `email_verified_at` sind bereits im Hauptdatenmodell definiert (siehe Datenmodell-Sektion). API-Responses enthalten `locale` und `theme` im JWT-Payload und im `/api/v1/user/me`-Response. Das Frontend setzt Sprache und Theme basierend darauf.

## Statistiken & Analytics

Statistiken kommen als eigenständige Phase 5, nachdem das lernende System (Phase 4) Daten liefert.

### API Endpoints

```
GET /api/v1/habits/{id}/stats          — Stats pro Habit
GET /api/v1/stats/household            — Household-weite Übersicht
GET /api/v1/stats/user/{id}            — Stats pro User (optional)
```

### Stats pro Habit

- **Streak**: Aktuelle und längste Serie aufeinanderfolgender Tage (Timezone-aware, basierend auf User-Lokalzeit)
- **Completion Rate**: Prozent der Tage im letzten Monat / Quartal / Jahr an denen der Habit erledigt wurde — relativ zu `frequency`/`frequency_days`
- **Durchschnittliche Uhrzeit**: Median der Log-Zeiten (gleiche Logik wie TimeWindowLearner)
- **Trend**: Wird der Habit früher/später erledigt als vor 30 Tagen? Steigt/sinkt die Completion Rate?
- **Verteilung nach User**: Wer erledigt den Habit wie oft? (Prozentual pro Household-Mitglied)

### Household-Dashboard

- **Gesamte Completion Rate**: Alle Habits aggregiert
- **Aktivster User**: Wer loggt am meisten?
- **Habit-Ranking**: Welche Habits werden am zuverlässigsten erledigt, welche werden oft vergessen?
- **Wochentags-Heatmap**: An welchen Tagen werden Habits am häufigsten vergessen?
- **Zeitliche Heatmap**: Zu welchen Uhrzeiten wird am meisten geloggt? (Aggregiert über alle Habits)

### Technische Umsetzung

Basis-Stats (Streak, Completion Rate) werden on-the-fly aus `HabitLog` berechnet — bei wenigen hundert Logs pro Habit ist das performant genug als PostgreSQL-Query mit Window Functions.

Für das Analytics-Dashboard (Heatmaps, Trends, Verteilungen) lohnt sich ein **Materialized View** oder eine separate `HabitStats`-Tabelle die nightly vom `app:compute-stats`-Command befüllt wird. Das vermeidet teure Aggregationen bei jedem Dashboard-Load.

Frontend: Charts via einer leichtgewichtigen Svelte-Chart-Library (z.B. `layerchart` oder `pancake`). Heatmaps als SVG-Grid, kein schweres Chart-Framework nötig.

## Native App & Widgets (stufenweise)

### Strategie: PWA-first, stufenweise native Features

Drei Stufen von einfach nach komplex. Jede Stufe liefert eigenständigen Mehrwert — man muss nicht bis Stufe 3 kommen damit sich der Aufwand lohnt.

### Stufe 1 — PWA Shortcuts (zero nativer Code, ab Phase 2)

Kein Capacitor nötig. Das PWA-Manifest bekommt `shortcuts`-Einträge:

```json
{
  "shortcuts": [
    {
      "name": "Hund raus loggen",
      "short_name": "Hund",
      "url": "/log/dog?source=shortcut",
      "icons": [{ "src": "/icons/dog-96.png", "sizes": "96x96" }]
    },
    {
      "name": "Spülmaschine loggen",
      "short_name": "Spüli",
      "url": "/log/dishwasher?source=shortcut",
      "icons": [{ "src": "/icons/dish-96.png", "sizes": "96x96" }]
    }
  ]
}
```

Ergebnis: Long-Press auf das SmartHabit-Icon zeigt Quick Actions. Tap öffnet die App direkt auf der Log-Route für den Habit. Funktioniert auf Android (Chrome) und iOS (Safari 16.4+). Kein App Store nötig, kein nativer Code — 30 Minuten Arbeit.

Dynamische Shortcuts (basierend auf den tatsächlichen Habits des Users) sind als PWA nicht möglich — die Manifest-Shortcuts sind statisch. Aber die Top-3-Habits als feste Shortcuts decken 80% des Bedarfs ab.

### Stufe 2 — Capacitor App + Store Deployment (kein Widget-Code)

Der gleiche SvelteKit-Build (`adapter-static`) in einer nativen WebView:

```bash
bun add @capacitor/core @capacitor/cli
bunx cap init SmartHabit com.smarthabit.app --web-dir frontend/build
bunx cap add ios
bunx cap add android
```

Build-Flow:
```
bun run build          → frontend/build/ (statische Files)
bunx cap sync          → kopiert Build in native Projekte
bunx cap open ios      → öffnet Xcode
bunx cap open android  → öffnet Android Studio
```

Der Code bleibt identisch — Capacitor fügt native Projekte (`ios/`, `android/`) hinzu. Was das bringt: App Store / Play Store Präsenz, native Push via APNs (iOS) und ntfy (Android), und die Basis für Stufe 3.

**App Store Deployment**:
- iOS: Xcode Build → TestFlight → App Store Connect
- Android: Android Studio Build → Play Console → Internal Testing → Production
- Push Notifications: APNs direkt für iOS, ntfy für Android — kein Firebase, kein `@capacitor/push-notifications` nötig

### Stufe 3 — Native Widgets via `capacitor-widget-bridge` (minimaler nativer Code)

Das Community-Plugin `capacitor-widget-bridge` übernimmt die komplette Daten-Brücke zwischen App und Widget. Kein Custom Capacitor Plugin nötig.

**So funktioniert's:**

```
┌─────────────────────────────────────────────┐
│  SvelteKit App (JS)                         │
│                                             │
│  // Habit-Daten in SharedStorage schreiben  │
│  WidgetBridge.setItem({                     │
│    group: 'group.com.smarthabit',           │
│    key: 'habits',                           │
│    value: JSON.stringify(todayHabits)       │
│  });                                        │
│  WidgetBridge.reloadAllTimelines();         │
│                                             │
└──────────────────┬──────────────────────────┘
                   │ SharedDefaults (iOS)
                   │ SharedPreferences (Android)
                   ▼
┌─────────────────────────────────────────────┐
│  Native Widget                              │
│                                             │
│  iOS:  ~50-80 Zeilen SwiftUI               │
│        → liest UserDefaults(suiteName:)    │
│        → zeigt Habit-Liste + Tap-Buttons   │
│                                             │
│  Android: ~80-100 Zeilen Kotlin + XML      │
│        → liest SharedPreferences            │
│        → RemoteViews Layout                │
│                                             │
└─────────────────────────────────────────────┘
```

**Was du selbst schreiben musst** (das Plugin nimmt dir den Rest ab):
- iOS: eine SwiftUI Widget Extension (~50-80 Zeilen) — liest JSON aus UserDefaults, rendert als Liste
- Android: ein AppWidgetProvider (~80-100 Zeilen Kotlin) + ein XML-Layout — liest JSON aus SharedPreferences

**Was das Plugin übernimmt**:
- `setItem()` / `getItem()` / `removeItem()` — Daten zwischen JS und nativem Widget teilen
- `reloadAllTimelines()` / `reloadTimelines()` — Widget-Refresh programmatisch triggern
- Funktioniert auf beiden Plattformen mit derselben JS-API

**Datenfluss**:
1. App öffnet → `GET /api/v1/dashboard` → Habit-Daten in SharedStorage schreiben via `WidgetBridge.setItem()`
2. Widget liest gecachte Daten direkt aus SharedStorage (kein API-Call vom Widget)
3. Tap auf "Erledigt" im Widget → öffnet App mit Deep Link → App loggt via API
4. Nach dem Log: `WidgetBridge.reloadAllTimelines()` → Widget refreshed

Tap-to-Log direkt aus dem Widget ohne App-Öffnung ist technisch möglich (via App Intents auf iOS, PendingIntent auf Android), aber eine Iteration komplexer. Für v1 reicht: Widget zeigt Status, Tap öffnet App am richtigen Habit.

**Widget-Größen**:
- iOS: Small (1-2 Habits, nur Status), Medium (4 Habits mit Tap-Targets), Large (alle Habits)
- Android: 2×1 (kompakt), 4×2 (voll)

### Optional: iOS Live Activities

Nicht priorisiert, aber für die Zukunft interessant: `capacitor-live-activity` Plugin für temporäre Lockscreen-Anzeigen. Beispiel: "Hund ist seit 45min draußen" als Timer auf dem Lockscreen + Dynamic Island. Cooles Feature, aber Nische — erst nach Stufe 3 wenn die Basis steht.

## DSGVO & Datenschutz

Pflicht für den EU-Markt. App speichert personenbezogene Daten: E-Mail, Verhaltensmuster (wann wird was erledigt), Haushaltszusammensetzung, Geräte-Tokens. Muss von Anfang an berücksichtigt werden — nachträgliches Einbauen ist ein Albtraum.

### API-Endpoints

```
GET    /api/v1/user/export       — Datenexport (Art. 20 DSGVO): alle User-Daten als JSON-Download
DELETE /api/v1/user/me           — Account-Löschung (Art. 17 DSGVO): Cascade auf alle Logs, Notifications, Push-Subscriptions
GET    /api/v1/privacy           — Aktuelle Datenschutzerklärung als JSON (Version + Text)
```

### Lösch-Kaskade

Account-Löschung löscht: User-Entity, alle HabitLogs des Users, alle NotificationLogs des Users, alle Push-Subscriptions. Habits bleiben bestehen (gehören dem Household, nicht dem User). Wenn der letzte User eines Households gelöscht wird → Household + alle Habits + alle Logs cascade-löschen.

### Aufbewahrungsfristen

- **HabitLogs**: 1 Jahr, danach automatisch anonymisiert (user_id → null) oder gelöscht. Nightly Command `app:cleanup-old-logs`.
- **NotificationLogs**: 90 Tage, dann gelöscht (reiner Debug-Zweck).
- **Account-Daten**: bis zur Löschung durch den User.
- Konfigurierbar via Environment-Variablen: `LOG_RETENTION_DAYS=365`, `NOTIFICATION_LOG_RETENTION_DAYS=90`.

### Einwilligung

- Bei Registrierung: Checkbox "Datenschutzerklärung gelesen und akzeptiert" (Pflicht, mit Timestamp + Version der DSE gespeichert).
- Push Notifications: separate Einwilligung im Frontend (Browser Permission Dialog + expliziter Opt-in im App-Flow).
- Cookie-Banner: nicht nötig — PWA nutzt keine Third-Party-Cookies, nur First-Party JWT + localStorage.

### Datenschutzerklärung

Muss enthalten: Verantwortlicher, Zweck der Verarbeitung (Habit-Tracking, Notifications), Rechtsgrundlage (Einwilligung Art. 6 Abs. 1 lit. a), Empfänger (Brevo für E-Mail, ntfy self-hosted für Push), Drittlandtransfer (Apple APNs für iOS Push — USA, Standard Contractual Clauses; Browser Push-Endpoints für Web Push), Speicherdauer, Rechte (Auskunft, Löschung, Export, Widerruf), Kontaktdaten. Als Markdown im Repo versioniert, über API abrufbar. Vorteil des self-hosted Ansatzes: Push-Daten für Android verlassen nie den eigenen Server (ntfy auf Hetzner DE).

## Security-Hardening

### Rate Limiting

Symfony Rate Limiter auf Auth-Endpoints — ohne das ist der Login-Endpoint ein Brute-Force-Ziel.

```php
// config/packages/rate_limiter.php
'login' => [
    'policy' => 'sliding_window',
    'limit' => 5,
    'interval' => '1 minute',
],
'register' => [
    'policy' => 'fixed_window',
    'limit' => 3,
    'interval' => '15 minutes',
],
'api_general' => [
    'policy' => 'sliding_window',
    'limit' => 60,
    'interval' => '1 minute',
],
```

Zusätzlich: Caddy hat eingebautes Rate Limiting (`rate_limit`-Directive) als zweite Schicht vor PHP.

### Erweiterte Auth-Flows

- **E-Mail-Verification**: Nach Registrierung → Verification-Mail mit Token-Link. Account ist eingeschränkt bis verifiziert (kann loggen, aber nicht einladen). Symfony hat `SymfonyCasts\Bundle\VerifyEmail\VerifyEmailBundle`.
- **Passwort-Reset**: `POST /api/v1/password/forgot` → Token per Mail → `POST /api/v1/password/reset` mit Token + neuem Passwort. Token ist 1h gültig, einmalig verwendbar.
- **Passwort-Änderung**: `PUT /api/v1/user/password` mit altem + neuem Passwort (für eingeloggte User).

### Weitere Maßnahmen

- **CORS**: Restriktiv — nur die eigene Domain, keine Wildcards.
- **CSP Headers**: Caddy-Config, `Content-Security-Policy` mit striktem `script-src`.
- **Input Validation**: Symfony Validator mit Attributes auf allen DTOs. Kein raw User-Input in Queries.
- **Household Isolation**: Middleware/Voter der prüft dass jeder API-Zugriff nur Daten des eigenen Households betrifft. Unit-getestet.
- **JWT Blacklist**: Bei Passwort-Änderung/Reset werden alle bestehenden Refresh-Tokens invalidiert.

## E-Mail (Symfony Mailer + Brevo)

### Warum Brevo

Kostenlos (300 Mails/Tag Free Tier), EU-basiert (DSGVO-konform), offizielle Symfony Mailer Bridge (`symfony/brevo-mailer`). Kein eigener Mailserver, kein SMTP-Setup, kein Deliverability-Problem. Für eine Household-App mit wenigen Usern reichen 300 Mails/Tag locker.

### Setup

```bash
composer require symfony/brevo-mailer
```

```
# .env
MAILER_DSN=brevo+api://API_KEY@default
```

### Mail-Typen

- **Verification-Mail**: Nach Registrierung, Token-Link zur Bestätigung
- **Passwort-Reset**: Token-Link, 1h gültig
- **Household-Einladung**: Optional — statt nur Invite-Code auch per Mail einladen
- **Welcome-Mail**: Nach erfolgreicher Verification

### Async via Messenger

Alle Mails gehen über Symfony Messenger (async). Der Mailer ist bereits Messenger-aware — `MAILER_DSN` + `messenger.yaml` Config reicht. Kein eigener Handler nötig. Mails blockieren nie den Request.

### Templates

Symfony Mailer + Twig für Mail-Templates (ja, Twig — nur für Mails, nicht für die App). Zweisprachig via Symfony Translator: Template nutzt `{{ 'email.verification.subject'|trans({}, 'messages', user.locale) }}`.

## Monitoring & Error Tracking (GlitchTip)

### Warum GlitchTip statt Sentry

Self-hosted, MIT-Lizenz, braucht nur 512MB RAM statt Sentrys 16GB+. Nutzt die gleichen Sentry SDKs — `sentry/sentry-symfony` für PHP, `@sentry/svelte` für das Frontend. Wenn du später zu Sentry Cloud migrieren willst, änderst du nur die DSN.

### Docker-Setup

GlitchTip läuft als separater Docker Compose Stack auf dem gleichen Hetzner VPS (oder einem zweiten kleinen VPS):

```yaml
services:
  glitchtip-web:
    image: glitchtip/glitchtip:v6
    depends_on: [glitchtip-db, glitchtip-redis]
    environment:
      DATABASE_URL: postgres://glitchtip:pass@glitchtip-db:5432/glitchtip
      VALKEY_URL: redis://glitchtip-redis:6379/0
      SECRET_KEY: ...
      GLITCHTIP_DOMAIN: https://errors.smarthabit.de
      DEFAULT_FROM_EMAIL: errors@smarthabit.de
      GLITCHTIP_MAX_EVENT_LIFE_DAYS: 90
    ports: ["8000:8000"]

  glitchtip-worker:
    image: glitchtip/glitchtip:v6
    command: bin/run-celery-with-beat.sh
    # gleiche env wie web

  glitchtip-db:
    image: postgres:16-alpine

  glitchtip-redis:
    image: redis:7-alpine
```

### Integration

```bash
# PHP
composer require sentry/sentry-symfony

# Frontend
bun add @sentry/svelte
```

```
# .env
SENTRY_DSN=https://key@errors.smarthabit.de/1
```

Symfony-Bundle auto-konfiguriert Exception-Handling. Im Frontend: `Sentry.init()` in `+layout.svelte`. Beide reporten an dieselbe GlitchTip-Instanz.

### Health Checks

```
GET /api/v1/health         — DB-Connection + Messenger-Queue Status
GET /api/v1/health/ready   — Für Docker Healthcheck (nur "up?")
```

Docker Healthcheck auf dem `php`-Container: `curl -f http://localhost/api/v1/health/ready`. Wenn der Cron-Container stirbt, fehlen Notifications — GlitchTip Alerts darauf konfigurieren.

### Strukturiertes Logging

Monolog mit JSON-Formatter statt plain text. Logs gehen nach `stdout` (Docker-Standard), Docker Logging-Driver sammelt sie ein. Kein ELK-Stack nötig im MVP — `docker compose logs -f php` reicht. Wichtig: Notification-Dispatch und Push-Fehler loggen mit strukturierten Feldern (`habit_id`, `user_id`, `push_type`, `status`).

## Real-Time Updates (Mercure)

### Problem

Tom loggt "Hund raus" → Lisa sieht es erst nach manuellem Refresh. Für eine Household-App in der mehrere Leute gleichzeitig tracken ist das schlecht.

### Lösung: Mercure (bereits im Stack)

Das `dunglas/symfony-docker`-Template hat Mercure als Caddy-Modul bereits eingebaut. Mercure ist ein Server-Sent-Events (SSE) Hub der in Caddy läuft — kein zusätzlicher Service, kein WebSocket-Server, kein Socket.io.

### Datenfluss

```
Lisa loggt "Hund raus"
  → POST /api/v1/habits/{id}/log
  → Controller speichert Log
  → Controller published Mercure Update:
      Topic: /households/{householdId}/habits
      Data: { habitId, userId, loggedAt, userName }
  → Tom's Browser hat SSE-Subscription auf diesem Topic
  → Dashboard aktualisiert sich automatisch
```

### Implementierung

Backend (Symfony):
```php
use Symfony\Component\Mercure\HubInterface;
use Symfony\Component\Mercure\Update;

$hub->publish(new Update(
    '/households/' . $habit->getHousehold()->getId() . '/habits',
    json_encode(['type' => 'habit_logged', 'data' => $logData])
));
```

Frontend (Svelte):
```svelte
<script>
  import { onMount } from 'svelte';
  onMount(() => {
    const es = new EventSource(`${MERCURE_URL}?topic=/households/${householdId}/habits`);
    es.onmessage = (event) => {
      const data = JSON.parse(event.data);
      // Update Dashboard Store
    };
  });
</script>
```

### Auth für Mercure

JWT-basiert (Mercure hat eigene JWT-Config). Der User bekommt ein Mercure-JWT das nur Topics seines Households subscriben darf. Caddy-Config im Template hat die `MERCURE_JWT_SECRET` bereits als Environment-Variable.

## Deployment (Hetzner VPS + OpenTofu)

### Infrastruktur

- **Hetzner Cloud VPS**: CX31 oder CX41 (4-8 vCPU, 8-16GB RAM) — reicht für App + GlitchTip + PostgreSQL
- **OpenTofu**: Infrastructure as Code für VPS-Provisioning, Firewall-Rules, DNS, Volumes
- **OS**: Ubuntu 24.04 LTS, Docker + Docker Compose vorinstalliert

### OpenTofu-Ressourcen

```
hcloud_server        — VPS mit SSH-Key
hcloud_volume        — Persistenter Storage für PostgreSQL + GlitchTip-DB
hcloud_firewall      — Nur 22 (SSH), 80 (HTTP), 443 (HTTPS) offen
hcloud_rdns          — Reverse DNS für Maildelivery
cloudflare_record    — DNS A-Record (oder Hetzner DNS)
```

### Verzeichnisstruktur auf dem Server

```
/opt/smarthabit/
├── compose.yaml              — App Stack (FrankenPHP, PgBouncer, PostgreSQL, Messenger)
├── compose.glitchtip.yaml    — Monitoring Stack (GlitchTip, Redis, eigene PG)
├── .env                      — Secrets (nicht im Repo!)
├── backups/                  — PostgreSQL Dumps
└── Caddyfile                 — Overrides falls nötig
```

### Backup-Strategie

- **PostgreSQL**: Nightly `pg_dump` via Cron → komprimiert nach `/opt/smarthabit/backups/`
- **Rotation**: Letzte 7 Daily + letzte 4 Weekly Backups behalten
- **Offsite**: Backups zu Hetzner Object Storage (S3-kompatibel) synced via `rclone`
- **Testen**: Monatlicher Restore-Test in einem separaten Container

### Deployment-Flow (erstmal manuell)

```bash
# Lokal
git push origin main

# Auf dem Server
ssh smarthabit
cd /opt/smarthabit
git pull
docker compose build --pull
docker compose up -d
docker compose exec php bin/console doctrine:migrations:migrate --no-interaction
```

### CD via GitHub Actions (später)

Für später geplant, nicht für den MVP. Wenn es soweit ist:
- GitHub Action: Build → Push Image zu GitHub Container Registry → SSH auf Hetzner → `docker compose pull && up -d`
- Migrations als separater Step nach dem Deployment
- Rollback: vorheriges Image-Tag pullen

## Accessibility (a11y)

Für App Store Release relevant, und generell das Richtige.

### Mindest-Anforderungen

- **ARIA Labels**: Alle interaktiven Elemente (Check-Buttons, Nav-Items, Karten) mit `aria-label` oder `aria-labelledby`
- **Keyboard Navigation**: Tab-Reihenfolge durch alle Habits, Enter/Space zum Loggen, Escape zum Schließen von Modals
- **Farbkontraste**: WCAG 2.1 AA (mindestens 4.5:1 für Text, 3:1 für große Text). Neo Utility's Blau (#3366FF) auf Weiß = 3.8:1 — knapp unter AA für normalen Text, muss auf #2952CC angepasst werden
- **Dark Mode Kontraste**: Separat prüfen — heller Text auf dunklem Hintergrund hat andere Kontrastprobleme
- **Reduced Motion**: `prefers-reduced-motion` Media Query respektieren, Animationen deaktivieren
- **Screen Reader**: Habit-Status als `aria-live="polite"` Region, damit Statusänderungen vorgelesen werden
- **Touch Targets**: Minimum 44×44px für alle tappbaren Elemente (Apple HIG + WCAG)

### Tooling

- **axe DevTools** (Browser Extension): automatisierte a11y-Checks während der Entwicklung
- **Lighthouse**: a11y-Score als Teil der CI (Ziel: >= 90)
- **Manuelle Tests**: VoiceOver (iOS/Mac) + TalkBack (Android) mindestens einmal pro Phase

## Testing & Code-Qualität

Qualität ist kein Phase-4-Feature. Das Tooling steht ab Commit 1, CI blockt bei Verstößen.

### Composer Dev-Dependencies

```
phpunit/phpunit: ^13.0
infection/infection: ^0.32
phpstan/phpstan: ^2.1
phpstan/phpstan-symfony: *
phpstan/phpstan-doctrine: *
phpstan/phpstan-strict-rules: *
rector/rector: *
symplify/easy-coding-standard: *
```

### PHPUnit 13 — Path Coverage + Sealed Test Doubles

PHPUnit 13 (Feb 2026, erfordert PHP 8.4+) mit PCOV für Path Coverage. Wichtige Neuerungen in v13:

- **Sealed Test Doubles**: `$mock->seal()` verhindert nachträgliche Konfiguration — erzwingt vollständige Setup-Phase vor dem Test-Act
- **`createStub()` vs `createMock()`**: v13 erzwingt die Unterscheidung. `createMock()` nur wenn Invocation-Verification nötig (mit `expects()`), sonst `createStub()`
- **`withParameterSetsInOrder()` / `withParameterSetsInAnyOrder()`**: Ersatz für das längst entfernte `withConsecutive()`

Konfiguration in `phpunit.xml.dist`:

```xml
<phpunit
    colors="true"
    failOnRisky="true"
    failOnWarning="true"
    executionOrder="random"
>
    <coverage pathCoverage="true">
        <include>
            <directory suffix=".php">src</directory>
        </include>
        <exclude>
            <directory>src/Entity</directory>    <!-- Entities sind DTOs -->
            <directory>src/Kernel.php</directory>
        </exclude>
        <report>
            <html outputDirectory="var/coverage"/>
            <clover outputFile="var/coverage/clover.xml"/>
        </report>
    </coverage>
    <testsuites>
        <testsuite name="unit">
            <directory>tests/Unit</directory>
        </testsuite>
        <testsuite name="integration">
            <directory>tests/Integration</directory>
        </testsuite>
    </testsuites>
</phpunit>
```

Im FrankenPHP Dockerfile wird `ext-pcov` in der Dev-Stage installiert via `install-php-extensions pcov`. PCOV ist ~5x schneller als Xdebug für Coverage.

### Unit Tests

Fokus auf Domain-Logik, kein IO. Alles was Entscheidungen trifft wird unit-getestet:

**TimeWindowChecker** — die Kernlogik ob ein Habit gerade im Zeitfenster liegt. Testfälle: innerhalb Fenster, außerhalb, exakte Grenze, Mitternachts-Überlappung (23:00-01:00), verschiedene Timezones, DST-Wechsel.

**TimeWindowLearner** — MAD-Algorithmus. Testfälle: normaler Datensatz, zu wenig Daten (<7 Logs), Ausreißer-Robustheit, Weekday/Weekend Split, Minimum-Fensterbreite 30min.

**PushSubscriptionManager** — Subscription hinzufügen (web_push, ntfy, apns), entfernen, Duplikat-Check, Cleanup für stale Subscriptions, verschiedene Subscription-Typen mischen.

**NotifyHandler** — Multi-Transport-Dispatch-Logik. Testfälle: User mit gemischten Subscription-Typen, Fehlerbehandlung pro Transport (410 Gone → entfernen, 429 → Retry), Fallback wenn ein Transport ausfällt während andere funktionieren. Stubs für WebPushService, NtfyClient, ApnsTransport.

**HabitCompletionChecker** — "Wurde heute schon erledigt?" mit Timezone-Awareness. Testfälle: Log von gestern 23:59 UTC das in User-Timezone "heute" ist, und umgekehrt.

**InviteCodeGenerator** — Eindeutigkeit, Format, Kollisionsbehandlung.

**HouseholdIsolationVoter** — Security Voter der prüft ob ein User auf Ressourcen seines Households zugreifen darf. Testfälle: eigenes Household → erlaubt, fremdes Household → denied, kein Household → denied, Admin-Override (falls später nötig).

**AccountDeletionService** — Lösch-Kaskade. Testfälle: User mit Logs → alles gelöscht, letzter User im Household → Household cascade, User mit Push-Subscriptions → alle entfernt, User mit NotificationLogs → alle entfernt.

**DataExportService** — DSGVO-Export. Testfälle: Export enthält alle User-Daten, Export enthält alle Logs, Export enthält keine Daten anderer User, Export-Format ist valides JSON.

**RateLimiterConfig** — Nicht direkt unit-testbar, aber die Konfiguration wird in Integration Tests verifiziert.

Jeder Unit-Test:
- Keine DB, kein Filesystem, kein HTTP
- `createStub()` statt `createMock()` wo keine Invocation-Verification nötig (PHPUnit 13 enforced das)
- Echte Mocks nur für externe Services (Web Push, ntfy, APNs) — mit `seal()` für strikte Konfiguration
- `#[CoversClass(...)]` Attribut auf jeder Testklasse
- Data Providers für Edge-Cases statt duplizierte Tests

### Integration Tests

Testen die Zusammenarbeit realer Komponenten mit einer echten PostgreSQL-Instanz (Docker in CI):

**Repository-Tests** — Doctrine Repositories mit echten Queries. Besonders wichtig für die Dashboard-Query (JOIN über Habits + Logs + Users), den Zeitfenster-Check (PostgreSQL TIME-Vergleiche), und die Lösch-Kaskade (DSGVO Account-Deletion).

**API-Tests** — Symfony `WebTestCase` mit echten HTTP-Requests gegen die App:
- Auth-Flow: Register → Verification-Mail → Login → JWT → geschützter Endpoint
- Passwort-Reset: Forgot → Token-Mail → Reset → alter JWT ungültig
- CRUD-Operationen + Validierung (invalide Timezone, fehlende Pflichtfelder, i18n Error-Messages)
- Household-Isolation: User A sieht nicht die Habits von Household B (Security Voter)
- Rate Limiting: 6. Login-Versuch → 429 Too Many Requests
- DSGVO: `GET /export` liefert vollständige Daten, `DELETE /user/me` cascade-löscht alles
- Push-Subscription CRUD: Registrieren, Updaten, Löschen für alle drei Typen

**Messenger-Tests** — CheckHabitsCommand erzeugt die richtigen Messages? NotifyHandler dispatcht an die richtigen User? Push-Fehler werden korrekt behandelt (Subscription entfernt bei 410, Retry bei 429)? Mock nur die Push-Clients selbst (WebPush, ntfy HTTP, APNs), alles andere real.

**Mercure-Tests** — Wird ein Mercure Update published wenn ein Log erstellt wird? Enthält das Update die richtigen Daten? Ist das Topic Household-scoped?

**E-Mail-Tests** — Symfony Mailer hat eingebautes Test-Tooling (`assertEmailCount()`, `assertEmailSent()`). Testen: Verification-Mail nach Register, Reset-Mail nach Forgot, korrekte Sprache basierend auf User-Locale, Links in Mails sind gültig.

**Cleanup-Command-Tests** — `app:cleanup-push-subscriptions` entfernt stale Subscriptions, behält aktive. `app:cleanup-old-logs` anonymisiert/löscht Logs nach Aufbewahrungsfrist.

Test-DB wird per `doctrine:schema:create` vor jeder Suite aufgebaut und nach jedem Test via Transaction-Rollback zurückgesetzt (Symfony `ResetDatabase`-Trait oder manuelles `beginTransaction`/`rollBack`).

### Mutation Testing — Infection

Infection läuft ausschließlich gegen die Unit-Test-Suite (nicht Integration). Gegen Integrationstests wäre es zu langsam und würde Timeouts erzeugen. Konfiguration in `infection.json5`:

```json5
{
    "$schema": "vendor/infection/infection/resources/schema.json",
    "source": {
        "directories": ["src"],
        "excludes": [
            "Entity",
            "Kernel.php",
            "Controller",     // Controller-Logik ist dünn, getestet via Integration
            "Command"         // Commands sind dünn, getestet via Integration
        ]
    },
    "logs": {
        "text": "var/infection/infection.log",
        "html": "var/infection/infection.html",
        "summary": "var/infection/summary.log"
    },
    "mutators": {
        "@default": true
    },
    "phpUnit": {
        "configDir": ".",
        "customPath": "vendor/bin/phpunit"
    },
    "testFramework": "phpunit",
    "testFrameworkOptions": "--testsuite=unit",
    "minMsi": 80,
    "minCoveredMsi": 90
}
```

Zielwerte: MSI >= 80%, Covered Code MSI >= 90%. Anfangs darf der Threshold niedriger sein, wird aber mit jeder Phase hochgezogen. Escaped Mutants werden in der CI geloggt und in PR-Reviews besprochen.

### PHPStan — Level max

PHPStan auf Level max (Level 10) ab Tag 1. Mit den Symfony- und Doctrine-Extensions sind die meisten False Positives eliminiert. Konfiguration in `phpstan.neon`:

```neon
parameters:
    level: max
    paths:
        - src
        - tests
    symfony:
        containerXmlPath: var/cache/dev/App_KernelDevDebugContainer.xml
    doctrine:
        objectManagerLoader: tests/object-manager.php
    ignoreErrors: []    # leer halten — Errors fixen, nicht ignorieren
```

Kein `ignoreErrors` als Mülleimer. Wenn PHPStan etwas moniert, wird es gefixt oder es gibt ein `@phpstan-ignore` mit Begründung direkt im Code.

### Rector — Automatische Code-Modernisierung

Rector hält den Code auf PHP 8.4 / Symfony 8 Niveau. Läuft im CI als Check (`--dry-run`), lokal als Auto-Fix. Konfiguration in `rector.php`:

```php
use Rector\Config\RectorConfig;
use Rector\Set\ValueObject\SetList;
use Rector\Symfony\Set\SymfonySetList;
use Rector\Doctrine\Set\DoctrineSetList;
use Rector\PHPUnit\Set\PHPUnitSetList;

return RectorConfig::configure()
    ->withPaths(['src', 'tests'])
    ->withSets([
        SetList::PHP_84,
        SetList::CODE_QUALITY,
        SetList::DEAD_CODE,
        SetList::TYPE_DECLARATION,
        SymfonySetList::SYMFONY_80,
        DoctrineSetList::DOCTRINE_ORM_214,
        PHPUnitSetList::PHPUNIT_130,
    ]);
```

### Easy Coding Standard (ECS)

ECS statt PHP-CS-Fixer oder PHP_CodeSniffer — eine Config, beide Tools. Konfiguration in `ecs.php`:

```php
use Symplify\EasyCodingStandard\Config\ECSConfig;

return ECSConfig::configure()
    ->withPaths(['src', 'tests'])
    ->withPreparedSets(
        psr12: true,
        common: true,
        strict: true,
        cleanCode: true,
    );
```

### CI Pipeline (GitHub Actions oder GitLab CI)

Jeder Push / PR durchläuft:

```
1. ECS Check          — Coding Standard (schnellster Check zuerst)
2. PHPStan            — Statische Analyse
3. Rector --dry-run   — Veraltete Patterns?
4. PHPUnit Unit       — mit Path Coverage
5. PHPUnit Integration — gegen PostgreSQL (Service Container in CI)
6. Infection           — Mutation Testing gegen Unit-Suite
```

Steps 1-3 laufen parallel (kein DB nötig). Steps 4-6 sequentiell (Coverage → Mutation braucht Coverage-Daten). CI schlägt fehl bei: ECS-Verstößen, PHPStan-Errors, Rector-Diff, Test-Failures, Path Coverage < 80%, MSI < 80%.

### Makefile / Composer Scripts

Lokale Shortcuts damit niemand sich die langen Commands merken muss:

```makefile
quality:        ## Alle Checks lokal
	@make ecs phpstan rector-check test infection

ecs:            ## Coding Standard (fix)
	vendor/bin/ecs check --fix

ecs-check:      ## Coding Standard (check only)
	vendor/bin/ecs check

phpstan:        ## Statische Analyse
	vendor/bin/phpstan analyse

rector:         ## Rector Auto-Fix
	vendor/bin/rector process

rector-check:   ## Rector Dry-Run
	vendor/bin/rector process --dry-run

test:           ## PHPUnit (alle Suites)
	vendor/bin/phpunit

test-unit:      ## Nur Unit Tests mit Coverage
	vendor/bin/phpunit --testsuite=unit --coverage-html=var/coverage

test-integration: ## Nur Integration Tests
	vendor/bin/phpunit --testsuite=integration

infection:      ## Mutation Testing
	vendor/bin/infection --threads=4 --show-mutations

infection-fast: ## Infection nur für geänderte Files (CI-Optimization)
	vendor/bin/infection --threads=4 --git-diff-filter=AM --git-diff-base=origin/main
```

### Test-Verzeichnisstruktur

```
tests/
├── Unit/
│   ├── Service/
│   │   ├── TimeWindowCheckerTest.php
│   │   ├── TimeWindowLearnerTest.php
│   │   ├── PushSubscriptionManagerTest.php
│   │   ├── NotifyHandlerTest.php
│   │   ├── HabitCompletionCheckerTest.php
│   │   ├── AccountDeletionServiceTest.php
│   │   ├── DataExportServiceTest.php
│   │   └── HouseholdIsolationVoterTest.php
│   ├── Util/
│   │   └── InviteCodeGeneratorTest.php
│   └── ValueObject/
│       └── TimeWindowTest.php
├── Integration/
│   ├── Repository/
│   │   ├── HabitRepositoryTest.php
│   │   ├── HabitLogRepositoryTest.php
│   │   └── NotificationLogRepositoryTest.php
│   ├── Controller/
│   │   ├── AuthControllerTest.php
│   │   ├── PasswordResetControllerTest.php
│   │   ├── HabitControllerTest.php
│   │   ├── DashboardControllerTest.php
│   │   ├── LogControllerTest.php
│   │   ├── PushSubscriptionControllerTest.php
│   │   ├── UserExportControllerTest.php
│   │   ├── UserDeletionControllerTest.php
│   │   └── RateLimitingTest.php
│   ├── Messenger/
│   │   ├── CheckHabitsHandlerTest.php
│   │   └── NotifyHabitHandlerTest.php
│   ├── Mercure/
│   │   └── HabitLogMercurePublishTest.php
│   ├── Email/
│   │   ├── VerificationEmailTest.php
│   │   └── PasswordResetEmailTest.php
│   └── Command/
│       ├── CleanupPushSubscriptionsCommandTest.php
│       └── CleanupOldLogsCommandTest.php
├── Factory/              — Object Mothers / Factories für Test-Daten
│   ├── HabitFactory.php
│   ├── UserFactory.php
│   └── HouseholdFactory.php
└── bootstrap.php
```

## Phasenplan

### Phase 1a — Projekt-Setup & Auth (2 Wochen)

- Docker-Setup via `dunglas/symfony-docker` Template: FrankenPHP, PostgreSQL, PgBouncer, Bun (dev)
- Quality Tooling ab Commit 1: PHPStan max, Rector, ECS, PHPUnit 13 Config, Infection-Config
- CI Pipeline aufsetzen (alle 6 Steps)
- **i18n ab Tag 1**: paraglide-sveltekit Setup (de/en), Symfony Translator (messages.de.yaml/en.yaml)
- Symfony Skeleton + Doctrine Entities + Migrations (inkl. alle Felder: locale, theme, email_verified_at, consent_at, consent_version, deleted_at, updated_at)
- Auth: Register, Login, JWT (Access + Refresh Token)
- **Rate Limiting** auf Auth-Endpoints (symfony/rate-limiter)
- **E-Mail-Verification** + **Passwort-Reset** Flow (Symfony Mailer + Brevo)
- **DSGVO**: Datenschutzerklärung, Consent bei Registration, Export + Lösch-Endpoints
- **Household Isolation Voter**: Unit-getestet, ab Tag 1 aktiv
- Integration Tests für Auth (inkl. Rate Limiting, Verification, Password Reset)

### Phase 1b — Core Features & Frontend (2 Wochen)

- CRUD für Habits (inkl. Soft-Delete) + Unit Tests für Domain-Services + erste Infection-Runde
- Ein-Tap Logging
- Dashboard Endpoint + Health-Check Endpoints (`/api/v1/health`, `/api/v1/health/ready`)
- SvelteKit Grundgerüst + Auth Flow + Timezone-Setting + Language Switcher
- **Accessibility**: ARIA-Labels, Keyboard-Nav, Kontrast-Check ab erstem UI-Element
- Integration Tests für Habit CRUD + Dashboard + DSGVO-Endpoints

### Phase 2 — Usable MVP (2 Wochen)

- PWA Setup (Manifest, Service Worker, Install)
- **PWA Shortcuts** im Manifest für Quick-Log der Top-Habits (Long-Press auf Icon)
- Dashboard UI mit Tap-Logging
- **Mercure Real-Time**: Live-Updates wenn Household-Mitglied loggt (SSE, bereits in Caddy)
- History View
- Household System (Invite Code, Join) + **Household-Einladung per E-Mail** (optional)
- Offline Queue für Logs
- **Dark Mode** Toggle (Auto/Light/Dark, CSS Custom Properties)

### Phase 3 — Notifications (2 Wochen)

- **Web Push Setup**: VAPID Key-Pair generieren, `minishlink/web-push` integrieren
- Push-Subscription Registration + Lifecycle im Frontend (Service Worker Push API)
- Service Worker Push Handler (Notification anzeigen, Tap → App öffnen)
- Cron + Messenger Worker (per-User Timezone-Check, Multi-Transport Dispatch)
- NotificationLog + Deduplizierung
- Notification-Tap → App öffnet und loggt
- Push Subscription Cleanup Command
- Unit Tests: TimeWindowChecker, PushSubscriptionManager, NotifyHandler (Multi-Transport), HabitCompletionChecker
- Integration Tests: CheckHabitsHandler, NotifyHabitHandler (Stubs für WebPush/ntfy/APNs), E-Mail-Tests, Mercure-Tests
- Infection MSI-Threshold hochziehen auf >= 80%

### Phase 4 — Intelligence (1-2 Wochen)

- Nightly Command für Zeitfenster-Analyse
- MAD-basierter Algorithmus (Timezone-aware)
- Weekday/Weekend Erkennung
- UI: Anzeige gelerntes vs. manuelles Fenster
- Unit Tests: TimeWindowLearner (umfangreichste Test-Suite — Ausreißer, Edge Cases, min. Datenpunkte)
- Covered Code MSI >= 90% für TimeWindowLearner

### Phase 5 — Statistiken & Analytics (2-3 Wochen)

- Basis-Stats: Streak, Completion Rate, durchschnittliche Uhrzeit (on-the-fly PostgreSQL Queries)
- Stats-Endpoint pro Habit: `GET /api/v1/habits/{id}/stats`
- Trend-Berechnung: Vergleich aktuelle vs. vorherige 30 Tage
- Verteilung nach User: wer erledigt welchen Habit wie oft?
- Household-Dashboard: `GET /api/v1/stats/household` (Gesamte Completion, Ranking, aktivster User)
- Nightly `app:compute-stats` Command für Materialized Views (Heatmaps, Aggregationen)
- Wochentags-Heatmap + Zeitliche Heatmap (SVG-Grid im Frontend)
- Charts via leichtgewichtiger Svelte-Library (layerchart oder pancake)
- Unit Tests: Streak-Berechnung Edge Cases (Timezone-Grenzen, Lücken, Frequenz-Berücksichtigung)

### Phase 6 — Deployment & Ops (1-2 Wochen)

- **OpenTofu**: Hetzner VPS provisionieren (CX31/CX41), Firewall, DNS, Volume
- App + **GlitchTip** Compose Stacks auf dem Server deployen
- **Sentry SDK** (→ GlitchTip) in PHP + Frontend integrieren (DSN zeigt auf errors.smarthabit.de)
- **ntfy-Server** auf dem VPS aufsetzen (ntfy.smarthabit.de) — Vorbereitung für Phase 7
- **PostgreSQL Backup**: Nightly pg_dump → Hetzner Object Storage via rclone
- Let's Encrypt via Caddy (automatisch)
- Erster manueller Deployment-Flow: `git pull → docker compose build → up -d → migrate`
- Smoke-Tests auf Produktion
- GlitchTip Alerts konfigurieren (Error-Spikes, Cron-Failures)
- **Lighthouse Audit**: Performance + a11y Score >= 90

### Phase 7 — Native App & Widgets (stufenweise, 3-4 Wochen)

**Stufe 1 — PWA Shortcuts** sind bereits in Phase 2 erledigt (Manifest-Einträge).

**Stufe 2 — Capacitor App + Store Deployment (1-2 Wochen)**:
- Capacitor-Integration: SvelteKit Build → native iOS/Android Shell
- Push: APNs direkt für iOS, ntfy (bereits in Phase 6 aufgesetzt) für Android — kein Firebase
- TestFlight / Play Console Internal Testing
- App Store + Play Store Submission
- Alle UI-Texte auf vollständige de/en Übersetzung prüfen vor Store-Release

**Stufe 3 — Native Widgets via `capacitor-widget-bridge` (1-2 Wochen)**:
- `capacitor-widget-bridge` integrieren für SharedStorage-Brücke
- iOS Widget Extension schreiben (~50-80 Zeilen SwiftUI): Habit-Liste aus UserDefaults
- Android AppWidgetProvider schreiben (~80-100 Zeilen Kotlin + XML): Habit-Liste aus SharedPreferences
- Datenfluss: App schreibt Dashboard-Daten in SharedStorage → Widget liest → Tap öffnet App am Habit
- Widget-Größen: Small/Medium/Large (iOS), 2×1 / 4×2 (Android)
- Iteration danach: direktes Tap-to-Log aus dem Widget ohne App-Öffnung (App Intents / PendingIntent)

### Phase 8 — CI/CD & Automation (1 Woche)

- **GitHub Actions CD**: Push to main → Build Image → Push zu GHCR → SSH Deploy auf Hetzner
- Migrations als separater CD-Step
- Rollback-Strategie: vorheriges Image-Tag
- Staging-Environment auf separatem Hetzner VPS (optional, CX21 reicht)
- Automated Lighthouse + a11y Checks in CI

## Getroffene Entscheidungen

| Frage | Entscheidung | Begründung |
|---|---|---|
| API Platform? | **Nein** | Overhead für MVP. Plain Controller + Serializer. |
| Auth-Strategie? | **JWT** via `lexik/jwt-authentication-bundle` | Standard für PWA/SPA, funktioniert offline. Access Token (15min) + Refresh Token (30d). |
| Datenbank? | **PostgreSQL 17 + PgBouncer** | Range types, Window Functions, robustes Connection Pooling. |
| PHP Runtime? | **FrankenPHP** via `dunglas/symfony-docker` | Worker Mode (Symfony bleibt im Memory), Caddy built-in (auto-HTTPS, HTTP/3), ein Container statt PHP-FPM + nginx. Rootless Prod-Image 290MB. |
| JS Runtime? | **Bun 1.3.x** statt Node.js | ~25x schnelleres `install`, ~10x schnellerer Startup. Drop-in-kompatibel mit npm-Paketen. |
| Asset-Pipeline? | **Bun + Vite (via SvelteKit)** — kein Symfony AssetMapper | Frontend ist eigenständige SPA, kein Twig. AssetMapper wäre Overhead ohne Nutzen. |
| Push (PWA)? | **`minishlink/web-push`** (W3C Standard) | Kein Firebase, kein Google-Account. VAPID-Auth direkt an Browser-Endpoints. |
| Push (Native)? | **APNs direkt + ntfy self-hosted** | APNs für iOS (einziger Weg), ntfy auf Hetzner für Android. Komplett US-frei. |
| Push Subscription Cleanup? | **Dreistufig** | Sofort bei Push-Fehler (410 Gone), Nightly für stale Subscriptions, explizit bei Logout. |
| Timezones? | **UTC-Storage + User-Timezone** | Alles in UTC gespeichert. Zeitfenster als Lokalzeit, Notification-Check konvertiert per User. DST-safe. |
| Zeitfenster-Speicherung? | **Lokalzeit (TIME ohne TZ)** | Menschliches Konzept, DST-Wechsel brauchen keine Neuberechnung. |
| PHPUnit? | **Version 13** (Feb 2026) | Sealed test doubles, `createStub`/`createMock` Trennung, `withParameterSetsInOrder`. Erfordert PHP 8.4. |
| Coverage-Tool? | **PCOV** statt Xdebug | ~5x schneller, reicht für Path Coverage, kein Debugging-Overhead. |
| Mutation Testing Scope? | **Nur Unit-Suite** | Integration Tests sind zu langsam für Infection, erzeugen Timeouts. Domain-Logik ist der kritische Teil. |
| MSI-Threshold? | **80% MSI, 90% Covered MSI** | Realistisch ab Phase 3, darunter blockt CI nicht aber warnt. |
| Mocking-Strategie? | **`createStub()` > `createMock()`** | PHPUnit 13 erzwingt die Trennung. Mocks mit `seal()` nur für externe Services (WebPush, ntfy, APNs, Brevo). |
| i18n Frontend? | **paraglide-sveltekit** | Compile-Time, zero Runtime-Overhead, typesichere Keys. Kein `$t()` zur Laufzeit. |
| Design-Richtung? | **Neo Utility** + Dark Mode | Funktional, datengetrieben, Sora + JetBrains Mono, Progress-Bar, Tags. Dark Mode via CSS Custom Properties + `prefers-color-scheme`. |
| Farb-System? | **CSS Custom Properties** mit Light/Dark Swap | User-Preference in DB (`theme: auto/light/dark`), kein separates Stylesheet. |
| i18n Backend? | **Symfony Translator** | Standard-Komponente, YAML-basiert, integriert sich mit Validator + Notifier. |
| Statistik-Berechnung? | **Hybrid: on-the-fly + Materialized Views** | Basis-Stats (Streak, Rate) live berechnet, Heatmaps/Aggregationen nightly vorberechnet. |
| Native App? | **Capacitor 6.x** (Phase 7, Stufe 2) | Gleicher SvelteKit-Code, native Shell für App Stores. |
| Widgets? | **Stufenweise**: PWA Shortcuts → Capacitor + `capacitor-widget-bridge` → native SwiftUI/Kotlin | Stufe 1 kostet 30min, Stufe 3 ~50-80 Zeilen nativer Code pro Plattform. Kein Custom Plugin nötig. |
| E-Mail Provider? | **Brevo** (Free Tier) via `symfony/brevo-mailer` | 300 Mails/Tag kostenlos, EU-basiert (DSGVO), offizielle Symfony Bridge. |
| Error Tracking? | **GlitchTip 6.x** self-hosted | 512MB RAM, MIT-Lizenz, Sentry-SDK-kompatibel. Migration zu Sentry Cloud jederzeit per DSN-Swap. |
| Real-Time? | **Mercure** (SSE, in Caddy eingebaut) | Bereits im `dunglas/symfony-docker` Template, kein extra Service. Live-Updates bei Household-Logs. |
| Hosting? | **Hetzner Cloud VPS** + OpenTofu | IaC, günstig, EU-Rechenzentrum (DSGVO), gute Peering. |
| CD? | **GitHub Actions** (Phase 8) | Erstmal manuelles Deploy, CD kommt nach Stabilisierung. |
| Backups? | **pg_dump nightly** → Hetzner Object Storage | 7 Daily + 4 Weekly Rotation, monatlicher Restore-Test. |
| DSGVO? | **Ab Tag 1**: Consent, Export, Löschung, Aufbewahrungsfristen | Nachträgliches Einbauen ist ein Albtraum. Blocker für App Store. |
| Rate Limiting? | **Symfony Rate Limiter + Caddy** | Doppelte Schicht: Application-Level (5/min Login) + Reverse-Proxy-Level. |
