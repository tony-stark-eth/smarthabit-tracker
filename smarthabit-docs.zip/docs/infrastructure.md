# Infrastructure, Monitoring & Deployment
## Monitoring & Error Tracking (GlitchTip)

### Warum GlitchTip statt Sentry

Self-hosted, MIT-Lizenz, braucht nur 512MB RAM statt Sentrys 16GB+. Nutzt die gleichen Sentry SDKs — `sentry/sentry-symfony` für PHP, `@sentry/svelte` für das Frontend. Wenn du später zu Sentry Cloud migrieren willst, änderst du nur die DSN.

### Docker-Setup

GlitchTip läuft als separater Docker Compose Stack auf dem gleichen Hetzner VPS (oder einem zweiten kleinen VPS):

```yaml
services:
  glitchtip-web:
    image: glitchtip/glitchtip:v6
    depends_on: [glitchtip-db, glitchtip-redis]
    environment:
      DATABASE_URL: postgres://glitchtip:pass@glitchtip-db:5432/glitchtip
      VALKEY_URL: redis://glitchtip-redis:6379/0
      SECRET_KEY: ...
      GLITCHTIP_DOMAIN: https://errors.smarthabit.de
      DEFAULT_FROM_EMAIL: errors@smarthabit.de
      GLITCHTIP_MAX_EVENT_LIFE_DAYS: 90
    ports: ["8000:8000"]

  glitchtip-worker:
    image: glitchtip/glitchtip:v6
    command: bin/run-celery-with-beat.sh
    # gleiche env wie web

  glitchtip-db:
    image: postgres:17-alpine

  glitchtip-redis:
    image: redis:7-alpine
```

### Integration

```bash
# PHP
composer require sentry/sentry-symfony

# Frontend
bun add @sentry/svelte
```

```
# .env
SENTRY_DSN=https://key@errors.smarthabit.de/1
```

Symfony-Bundle auto-konfiguriert Exception-Handling. Im Frontend: `Sentry.init()` in `+layout.svelte`. Beide reporten an dieselbe GlitchTip-Instanz.

### Health Checks

```
GET /api/v1/health         — DB-Connection + Messenger-Queue Status
GET /api/v1/health/ready   — Für Docker Healthcheck (nur "up?")
```

Docker Healthcheck auf dem `php`-Container: `curl -f http://localhost/api/v1/health/ready`. Wenn der Cron-Container stirbt, fehlen Notifications — GlitchTip Alerts darauf konfigurieren.

### Strukturiertes Logging

Monolog mit JSON-Formatter statt plain text. Logs gehen nach `stdout` (Docker-Standard), Docker Logging-Driver sammelt sie ein. Kein ELK-Stack nötig im MVP — `docker compose logs -f php` reicht. Wichtig: Notification-Dispatch und Push-Fehler loggen mit strukturierten Feldern (`habit_id`, `user_id`, `push_type`, `status`).

## Real-Time Updates (Mercure)

### Problem

Tom loggt "Hund raus" → Lisa sieht es erst nach manuellem Refresh. Für eine Household-App in der mehrere Leute gleichzeitig tracken ist das schlecht.

### Lösung: Mercure (bereits im Stack)

Das `dunglas/symfony-docker`-Template hat Mercure als Caddy-Modul bereits eingebaut. Mercure ist ein Server-Sent-Events (SSE) Hub der in Caddy läuft — kein zusätzlicher Service, kein WebSocket-Server, kein Socket.io.

### Datenfluss

```
Lisa loggt "Hund raus"
  → POST /api/v1/habits/{id}/log
  → Controller speichert Log
  → Controller published Mercure Update:
      Topic: /households/{householdId}/habits
      Data: { habitId, userId, loggedAt, userName }
  → Tom's Browser hat SSE-Subscription auf diesem Topic
  → Dashboard aktualisiert sich automatisch
```

### Implementierung

Backend (Symfony):
```php
use Symfony\Component\Mercure\HubInterface;
use Symfony\Component\Mercure\Update;

$hub->publish(new Update(
    '/households/' . $habit->getHousehold()->getId() . '/habits',
    json_encode(['type' => 'habit_logged', 'data' => $logData])
));
```

Frontend (Svelte):
```svelte
<script>
  import { onMount } from 'svelte';
  onMount(() => {
    const es = new EventSource(`${MERCURE_URL}?topic=/households/${householdId}/habits`);
    es.onmessage = (event) => {
      const data = JSON.parse(event.data);
      // Update Dashboard Store
    };
  });
</script>
```

### Auth für Mercure

JWT-basiert (Mercure hat eigene JWT-Config). Der User bekommt ein Mercure-JWT das nur Topics seines Households subscriben darf. Caddy-Config im Template hat die `MERCURE_JWT_SECRET` bereits als Environment-Variable.

## Deployment (Hetzner VPS + OpenTofu)

### Infrastruktur

- **Hetzner Cloud VPS**: CX31 oder CX41 (4-8 vCPU, 8-16GB RAM) — reicht für App + GlitchTip + PostgreSQL
- **OpenTofu**: Infrastructure as Code für VPS-Provisioning, Firewall-Rules, DNS, Volumes
- **OS**: Ubuntu 24.04 LTS, Docker + Docker Compose vorinstalliert

### OpenTofu-Ressourcen

```
hcloud_server        — VPS mit SSH-Key
hcloud_volume        — Persistenter Storage für PostgreSQL + GlitchTip-DB
hcloud_firewall      — Nur 22 (SSH), 80 (HTTP), 443 (HTTPS) offen
hcloud_rdns          — Reverse DNS für Maildelivery
cloudflare_record    — DNS A-Record (oder Hetzner DNS)
```

### Verzeichnisstruktur auf dem Server

```
/opt/smarthabit/
├── compose.yaml              — App Stack (FrankenPHP, PgBouncer, PostgreSQL, Messenger)
├── compose.glitchtip.yaml    — Monitoring Stack (GlitchTip, Redis, eigene PG)
├── .env                      — Secrets (nicht im Repo!)
├── backups/                  — PostgreSQL Dumps
└── Caddyfile                 — Overrides falls nötig
```

### Backup-Strategie

- **PostgreSQL**: Nightly `pg_dump` via Cron → komprimiert nach `/opt/smarthabit/backups/`
- **Rotation**: Letzte 7 Daily + letzte 4 Weekly Backups behalten
- **Offsite**: Backups zu Hetzner Object Storage (S3-kompatibel) synced via `rclone`
- **Testen**: Monatlicher Restore-Test in einem separaten Container

### Deployment-Flow (erstmal manuell)

```bash
# Lokal
git push origin main

# Auf dem Server
ssh smarthabit
cd /opt/smarthabit
git pull
docker compose build --pull
docker compose up -d
docker compose exec php bin/console doctrine:migrations:migrate --no-interaction
```

### CD via GitHub Actions (später)

Für später geplant, nicht für den MVP. Wenn es soweit ist:
- GitHub Action: Build → Push Image zu GitHub Container Registry → SSH auf Hetzner → `docker compose pull && up -d`
- Migrations als separater Step nach dem Deployment
- Rollback: vorheriges Image-Tag pullen

## Accessibility (a11y)

Für App Store Release relevant, und generell das Richtige.

### Mindest-Anforderungen

- **ARIA Labels**: Alle interaktiven Elemente (Check-Buttons, Nav-Items, Karten) mit `aria-label` oder `aria-labelledby`
- **Keyboard Navigation**: Tab-Reihenfolge durch alle Habits, Enter/Space zum Loggen, Escape zum Schließen von Modals
- **Farbkontraste**: WCAG 2.1 AA (mindestens 4.5:1 für Text, 3:1 für große Text). Neo Utility's Blau (#3366FF) auf Weiß = 3.8:1 — knapp unter AA für normalen Text, muss auf #2952CC angepasst werden
- **Dark Mode Kontraste**: Separat prüfen — heller Text auf dunklem Hintergrund hat andere Kontrastprobleme
- **Reduced Motion**: `prefers-reduced-motion` Media Query respektieren, Animationen deaktivieren
- **Screen Reader**: Habit-Status als `aria-live="polite"` Region, damit Statusänderungen vorgelesen werden
- **Touch Targets**: Minimum 44×44px für alle tappbaren Elemente (Apple HIG + WCAG)

### Tooling

- **axe DevTools** (Browser Extension): automatisierte a11y-Checks während der Entwicklung
- **Lighthouse**: a11y-Score als Teil der CI (Ziel: >= 90)
- **Manuelle Tests**: VoiceOver (iOS/Mac) + TalkBack (Android) mindestens einmal pro Phase

