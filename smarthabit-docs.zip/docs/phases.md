# Phasenplan & Entscheidungen
## Phasenplan

### Phase 0 — Repo Template (5-7 Tage)

Öffentliches GitHub Template Repository (MIT License) für PHP 8.4 + Symfony 8 + SvelteKit Full-Stack-Projekte. Enthält den kompletten Quality-Stack, Docker-Setup, CI/CD und Claude Code Integration — keine domainspezifische Logik. SmartHabit wird als privater Fork daraus erstellt.

Vollständige Spezifikation: [`phase0-template.md`](phase0-template.md)

**Kern-Deliverables:**

- `docker/` — FrankenPHP Multi-Stage Dockerfile, PostgreSQL 17, PgBouncer, Bun Dev-Server
- `compose.yaml` + `compose.override.yaml` + `compose.prod.yaml`
- `backend/` — Symfony 8 Skeleton mit HealthController + Smoke-Test
- `backend/phpstan.neon` — Level max + 10 Extensions (strict-rules, deprecation-rules, shipmonk, voku, cognitive-complexity, type-coverage, phpat, phpunit, symfony, doctrine)
- `backend/rector.php`, `ecs.php`, `infection.json5`, `phpunit.xml.dist`
- `backend/tests/Architecture/` — phpat Regeln (Layer + Naming)
- `frontend/` — SvelteKit 2 + Svelte 5 + Bun + TypeScript strict + Tailwind 4 + PWA Skeleton
- `infrastructure/` — OpenTofu Skeleton: Hetzner VPS, Network, Volume, Cloudflare DNS (Module, kein apply)
- `.github/workflows/ci.yml` — Backend CI (ECS → PHPStan → Rector → PHPUnit → Infection)
- `.github/workflows/ci-frontend.yml` — Frontend CI (lint → check → build)
- `.github/workflows/claude-update.yml` — Biweekly: Claude Code aktualisiert Dependencies + fixt Breaking Changes
- `.github/workflows/claude.yml` — Interactive: @claude Mentions in Issues/PRs
- `.github/workflows/claude-review.yml` — Automatisches Code Review auf jeden PR
- `.github/dependabot.yml` + Auto-Merge Workflow für Patch-Updates
- `.github/ISSUE_TEMPLATE/` — Bug Report + Feature Request als YAML-Formulare
- `.claude/` — 4 Guidelines (coding-php, coding-frontend, testing, architecture)
- `CLAUDE.md` — schlanker Entry Point (~30 Zeilen), verweist auf `.claude/`
- `Makefile` — Alle Shortcuts (quality, test, build, db-migrate etc.)
- Open Source: `LICENSE` (MIT), `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `SECURITY.md`, `CHANGELOG.md`
- `.env.example` — Alle ENV-Vars dokumentiert (keine echten Secrets)
- Runner: Default GitHub-hosted, self-hosted als Option via `vars.RUNNER_LABEL`

**Definition of Done:**
- `docker compose --profile dev up -d` startet fehlerfrei
- `make quality` durchläuft alle 6 Checks
- HealthController Integration-Test grün gegen echte PostgreSQL
- GitHub Actions Backend + Frontend CI grün (ECS/PHPStan/Rector als parallele Jobs)
- Git Hooks (CaptainHook) installieren sich bei `composer install`
- Repo ist **public**, MIT License, Template-Flag gesetzt
- GitHub Topics gesetzt, Description ausgefüllt, Social Preview Image hochgeladen
- Discussions aktiviert, Wiki + Projects deaktiviert
- README mit Badges, Quick Start, After-Forking Checklist
- Open-Source-Dateien vollständig (CONTRIBUTING, CODE_OF_CONDUCT, SECURITY, CHANGELOG)
- v1.0.0 Release erstellt

### Phase 1a — Projekt-Setup & Auth (2 Wochen)

Baut auf dem Repo Template aus Phase 0 auf (`Use this template` → `smarthabit-tracker`).

- ~~Docker-Setup~~ ~~Quality Tooling~~ ~~CI Pipeline~~ — **bereits im Template enthalten**
- **i18n ab Tag 1**: paraglide-sveltekit Setup (de/en), Symfony Translator (messages.de.yaml/en.yaml)
- Domain-Ordner anlegen: `src/Habit/`, `src/Notification/`, `src/Auth/`, `src/Household/`, `src/Stats/`, `src/Shared/`
- phpat `DomainIsolationTest` erweitern mit SmartHabit-spezifischen Regeln
- Doctrine Entities + Migrations (inkl. alle Felder: locale, theme, email_verified_at, consent_at, consent_version, deleted_at, updated_at)
- Auth: Register, Login, JWT (Access + Refresh Token)
- **Rate Limiting** auf Auth-Endpoints (symfony/rate-limiter)
- **E-Mail-Verification** + **Passwort-Reset** Flow (Symfony Mailer + Brevo)
- **DSGVO**: Datenschutzerklärung, Consent bei Registration, Export + Lösch-Endpoints
- **Household Isolation Voter**: Unit-getestet, ab Tag 1 aktiv
- Integration Tests für Auth (inkl. Rate Limiting, Verification, Password Reset)

### Phase 1b — Core Features & Frontend (2 Wochen)

- CRUD für Habits (inkl. Soft-Delete) + Unit Tests für Domain-Services + erste Infection-Runde
- Ein-Tap Logging
- Dashboard Endpoint + Health-Check Endpoints (`/api/v1/health`, `/api/v1/health/ready`)
- SvelteKit Grundgerüst + Auth Flow + Timezone-Setting + Language Switcher
- **Accessibility**: ARIA-Labels, Keyboard-Nav, Kontrast-Check ab erstem UI-Element
- Integration Tests für Habit CRUD + Dashboard + DSGVO-Endpoints

### Phase 2 — Usable MVP (2 Wochen)

- PWA Setup (Manifest, Service Worker, Install)
- **PWA Shortcuts** im Manifest für Quick-Log der Top-Habits (Long-Press auf Icon)
- Dashboard UI mit Tap-Logging
- **Mercure Real-Time**: Live-Updates wenn Household-Mitglied loggt (SSE, bereits in Caddy)
- History View
- Household System (Invite Code, Join) + **Household-Einladung per E-Mail** (optional)
- Offline Queue für Logs
- **Dark Mode** Toggle (Auto/Light/Dark, CSS Custom Properties)

### Phase 3 — Notifications (2 Wochen)

**Nur Web Push (PWA)** — ntfy (Android) und APNs (iOS) kommen erst in Phase 7 (Native). Ein Transport statt drei reduziert die Komplexität erheblich und deckt trotzdem den Hauptnutzfall ab (Browser-Benachrichtigungen auf Desktop + Android Chrome + iOS Safari 16.4+).

- **Web Push Setup**: VAPID Key-Pair generieren, `minishlink/web-push` integrieren
- Push-Subscription Registration + Lifecycle im Frontend (Service Worker Push API)
- Service Worker Push Handler (Notification anzeigen, Tap → App öffnen)
- Cron + Messenger Worker (per-User Timezone-Check, Web Push Dispatch)
- NotificationLog + Deduplizierung
- Notification-Tap → App öffnet und loggt
- Push Subscription Cleanup Command
- Unit Tests: TimeWindowChecker, PushSubscriptionManager, NotifyHandler, HabitCompletionChecker
- Integration Tests: CheckHabitsHandler, NotifyHabitHandler (Stubs für WebPush), E-Mail-Tests, Mercure-Tests
- Infection MSI-Threshold hochziehen auf >= 80%

**Bewusst rausgelassen**: Multi-Transport NotifyHandler (Strategy Pattern). In Phase 3 gibt es nur einen Transport (Web Push). Das Strategy Pattern wird erst in Phase 7 eingeführt wenn ntfy/APNs dazukommen — kein Over-Engineering für einen Single-Transport.

### Phase 4 — Intelligence (1-2 Wochen)

- Nightly Command für Zeitfenster-Analyse
- MAD-basierter Algorithmus (Timezone-aware)
- Weekday/Weekend Erkennung
- UI: Anzeige gelerntes vs. manuelles Fenster
- Unit Tests: TimeWindowLearner (umfangreichste Test-Suite — Ausreißer, Edge Cases, min. Datenpunkte)
- Covered Code MSI >= 90% für TimeWindowLearner

### Phase 5 — Statistiken & Analytics (2-3 Wochen)

- Basis-Stats: Streak, Completion Rate, durchschnittliche Uhrzeit (on-the-fly PostgreSQL Queries)
- Stats-Endpoint pro Habit: `GET /api/v1/habits/{id}/stats`
- Trend-Berechnung: Vergleich aktuelle vs. vorherige 30 Tage
- Verteilung nach User: wer erledigt welchen Habit wie oft?
- Household-Dashboard: `GET /api/v1/stats/household` (Gesamte Completion, Ranking, aktivster User)
- Nightly `app:compute-stats` Command für Materialized Views (Heatmaps, Aggregationen)
- Wochentags-Heatmap + Zeitliche Heatmap (SVG-Grid im Frontend)
- Charts via leichtgewichtiger Svelte-Library (layerchart oder pancake)
- Unit Tests: Streak-Berechnung Edge Cases (Timezone-Grenzen, Lücken, Frequenz-Berücksichtigung)

### Phase 6 — Deployment & Ops (1-2 Wochen)

- **OpenTofu**: Hetzner VPS provisionieren (CX31/CX41), Firewall, DNS, Volume
- App + **GlitchTip** Compose Stacks auf dem Server deployen
- **Sentry SDK** (→ GlitchTip) in PHP + Frontend integrieren (DSN zeigt auf errors.smarthabit.de)
- **PostgreSQL Backup**: Nightly pg_dump → Hetzner Object Storage via rclone
- **Backup-Restore-Test**: `make db-restore-test` — einmal beweisen dass Restore funktioniert. Ein Backup das nie getestet wurde ist kein Backup.
- Let's Encrypt via Caddy (automatisch)
- Erster manueller Deployment-Flow: `git pull → docker compose build → up -d → migrate`
- Smoke-Tests auf Produktion
- GlitchTip Alerts konfigurieren (Error-Spikes, Cron-Failures)
- **Lighthouse Audit**: Performance + a11y Score >= 90

### Phase 7 — Native App & Widgets (stufenweise, 3-4 Wochen)

**Stufe 1 — PWA Shortcuts** sind bereits in Phase 2 erledigt (Manifest-Einträge).

**Stufe 2 — Multi-Transport Push + Capacitor App (1-2 Wochen)**:
- **NotifyHandler refactoring**: Strategy Pattern einführen — Web Push (existiert aus Phase 3) + ntfy (Android) + APNs (iOS). `match($subscription['type'])` dispatcht an den richtigen Transport.
- ntfy-Server auf Hetzner aufsetzen (ntfy.smarthabit.de, `binwiederhier/ntfy:latest`)
- APNs Integration via `symfony/notifier` APNs Transport
- Capacitor-Integration: SvelteKit Build → native iOS/Android Shell
- TestFlight / Play Console Internal Testing
- App Store + Play Store Submission
- Alle UI-Texte auf vollständige de/en Übersetzung prüfen vor Store-Release

**Stufe 3 — Native Widgets via `capacitor-widget-bridge` (1-2 Wochen)**:
- `capacitor-widget-bridge` integrieren für SharedStorage-Brücke
- iOS Widget Extension schreiben (~50-80 Zeilen SwiftUI): Habit-Liste aus UserDefaults
- Android AppWidgetProvider schreiben (~80-100 Zeilen Kotlin + XML): Habit-Liste aus SharedPreferences
- Datenfluss: App schreibt Dashboard-Daten in SharedStorage → Widget liest → Tap öffnet App am Habit
- Widget-Größen: Small/Medium/Large (iOS), 2×1 / 4×2 (Android)
- Iteration danach: direktes Tap-to-Log aus dem Widget ohne App-Öffnung (App Intents / PendingIntent)

### Phase 8 — CI/CD & Automation (1 Woche)

- **GitHub Actions CD**: Push to main → Build Image → Push zu GHCR → SSH Deploy auf Hetzner
- Migrations als separater CD-Step
- Rollback-Strategie: vorheriges Image-Tag
- Staging-Environment auf separatem Hetzner VPS (optional, CX21 reicht)
- Automated Lighthouse + a11y Checks in CI

## Getroffene Entscheidungen

| Frage | Entscheidung | Begründung |
|---|---|---|
| API Platform? | **Nein** | Overhead für MVP. Plain Controller + Serializer. |
| Auth-Strategie? | **JWT** via `lexik/jwt-authentication-bundle` | Standard für PWA/SPA, funktioniert offline. Access Token (15min) + Refresh Token (30d). |
| Datenbank? | **PostgreSQL 17 + PgBouncer** | Range types, Window Functions, robustes Connection Pooling. |
| PHP Runtime? | **FrankenPHP** via `dunglas/symfony-docker` | Worker Mode (Symfony bleibt im Memory), Caddy built-in (auto-HTTPS, HTTP/3), ein Container statt PHP-FPM + nginx. Rootless Prod-Image 290MB. |
| JS Runtime? | **Bun 1.3.x** statt Node.js | ~25x schnelleres `install`, ~10x schnellerer Startup. Drop-in-kompatibel mit npm-Paketen. |
| Asset-Pipeline? | **Bun + Vite (via SvelteKit)** — kein Symfony AssetMapper | Frontend ist eigenständige SPA, kein Twig. AssetMapper wäre Overhead ohne Nutzen. |
| Push (PWA)? | **`minishlink/web-push`** (W3C Standard) | Kein Firebase, kein Google-Account. VAPID-Auth direkt an Browser-Endpoints. |
| Push (Native)? | **APNs direkt + ntfy self-hosted** | APNs für iOS (einziger Weg), ntfy auf Hetzner für Android. Komplett US-frei. |
| Push Subscription Cleanup? | **Dreistufig** | Sofort bei Push-Fehler (410 Gone), Nightly für stale Subscriptions, explizit bei Logout. |
| Timezones? | **UTC-Storage + User-Timezone** | Alles in UTC gespeichert. Zeitfenster als Lokalzeit, Notification-Check konvertiert per User. DST-safe. |
| Zeitfenster-Speicherung? | **Lokalzeit (TIME ohne TZ)** | Menschliches Konzept, DST-Wechsel brauchen keine Neuberechnung. |
| PHPUnit? | **Version 13** (Feb 2026) | Sealed test doubles, `createStub`/`createMock` Trennung, `withParameterSetsInOrder`. Erfordert PHP 8.4. |
| Coverage-Tool? | **PCOV** statt Xdebug | ~5x schneller, reicht für Path Coverage, kein Debugging-Overhead. |
| Mutation Testing Scope? | **Nur Unit-Suite** | Integration Tests sind zu langsam für Infection, erzeugen Timeouts. Domain-Logik ist der kritische Teil. |
| MSI-Threshold? | **80% MSI, 90% Covered MSI** | Realistisch ab Phase 3, darunter blockt CI nicht aber warnt. |
| Mocking-Strategie? | **`createStub()` > `createMock()`** | PHPUnit 13 erzwingt die Trennung. Mocks mit `seal()` nur für externe Services (WebPush, ntfy, APNs, Brevo). |
| i18n Frontend? | **paraglide-sveltekit** | Compile-Time, zero Runtime-Overhead, typesichere Keys. Kein `$t()` zur Laufzeit. |
| Design-Richtung? | **Neo Utility** + Dark Mode | Funktional, datengetrieben, Sora + JetBrains Mono, Progress-Bar, Tags. Dark Mode via CSS Custom Properties + `prefers-color-scheme`. |
| Farb-System? | **CSS Custom Properties** mit Light/Dark Swap | User-Preference in DB (`theme: auto/light/dark`), kein separates Stylesheet. |
| i18n Backend? | **Symfony Translator** | Standard-Komponente, YAML-basiert, integriert sich mit Validator + Notifier. |
| Statistik-Berechnung? | **Hybrid: on-the-fly + Materialized Views** | Basis-Stats (Streak, Rate) live berechnet, Heatmaps/Aggregationen nightly vorberechnet. |
| Native App? | **Capacitor 6.x** (Phase 7, Stufe 2) | Gleicher SvelteKit-Code, native Shell für App Stores. |
| Widgets? | **Stufenweise**: PWA Shortcuts → Capacitor + `capacitor-widget-bridge` → native SwiftUI/Kotlin | Stufe 1 kostet 30min, Stufe 3 ~50-80 Zeilen nativer Code pro Plattform. Kein Custom Plugin nötig. |
| E-Mail Provider? | **Brevo** (Free Tier) via `symfony/brevo-mailer` | 300 Mails/Tag kostenlos, EU-basiert (DSGVO), offizielle Symfony Bridge. |
| Error Tracking? | **GlitchTip 6.x** self-hosted | 512MB RAM, MIT-Lizenz, Sentry-SDK-kompatibel. Migration zu Sentry Cloud jederzeit per DSN-Swap. |
| Real-Time? | **Mercure** (SSE, in Caddy eingebaut) | Bereits im `dunglas/symfony-docker` Template, kein extra Service. Live-Updates bei Household-Logs. |
| Hosting? | **Hetzner Cloud VPS** + OpenTofu | IaC, günstig, EU-Rechenzentrum (DSGVO), gute Peering. |
| CD? | **GitHub Actions** (Phase 8) | Erstmal manuelles Deploy, CD kommt nach Stabilisierung. |
| Backups? | **pg_dump nightly** → Hetzner Object Storage | 7 Daily + 4 Weekly Rotation, monatlicher Restore-Test. |
| DSGVO? | **Ab Tag 1**: Consent, Export, Löschung, Aufbewahrungsfristen | Nachträgliches Einbauen ist ein Albtraum. Blocker für App Store. |
| Rate Limiting? | **Symfony Rate Limiter + Caddy** | Doppelte Schicht: Application-Level (5/min Login) + Reverse-Proxy-Level. |
