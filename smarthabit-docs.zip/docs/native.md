# Native App & Widgets
## Native App & Widgets (stufenweise)

### Strategie: PWA-first, stufenweise native Features

Drei Stufen von einfach nach komplex. Jede Stufe liefert eigenständigen Mehrwert — man muss nicht bis Stufe 3 kommen damit sich der Aufwand lohnt.

### Stufe 1 — PWA Shortcuts (zero nativer Code, ab Phase 2)

Kein Capacitor nötig. Das PWA-Manifest bekommt `shortcuts`-Einträge:

```json
{
  "shortcuts": [
    {
      "name": "Hund raus loggen",
      "short_name": "Hund",
      "url": "/log/dog?source=shortcut",
      "icons": [{ "src": "/icons/dog-96.png", "sizes": "96x96" }]
    },
    {
      "name": "Spülmaschine loggen",
      "short_name": "Spüli",
      "url": "/log/dishwasher?source=shortcut",
      "icons": [{ "src": "/icons/dish-96.png", "sizes": "96x96" }]
    }
  ]
}
```

Ergebnis: Long-Press auf das SmartHabit-Icon zeigt Quick Actions. Tap öffnet die App direkt auf der Log-Route für den Habit. Funktioniert auf Android (Chrome) und iOS (Safari 16.4+). Kein App Store nötig, kein nativer Code — 30 Minuten Arbeit.

Dynamische Shortcuts (basierend auf den tatsächlichen Habits des Users) sind als PWA nicht möglich — die Manifest-Shortcuts sind statisch. Aber die Top-3-Habits als feste Shortcuts decken 80% des Bedarfs ab.

### Stufe 2 — Capacitor App + Store Deployment (kein Widget-Code)

Der gleiche SvelteKit-Build (`adapter-static`) in einer nativen WebView:

```bash
bun add @capacitor/core @capacitor/cli
bunx cap init SmartHabit com.smarthabit.app --web-dir frontend/build
bunx cap add ios
bunx cap add android
```

Build-Flow:
```
bun run build          → frontend/build/ (statische Files)
bunx cap sync          → kopiert Build in native Projekte
bunx cap open ios      → öffnet Xcode
bunx cap open android  → öffnet Android Studio
```

Der Code bleibt identisch — Capacitor fügt native Projekte (`ios/`, `android/`) hinzu. Was das bringt: App Store / Play Store Präsenz, native Push via APNs (iOS) und ntfy (Android), und die Basis für Stufe 3.

**App Store Deployment**:
- iOS: Xcode Build → TestFlight → App Store Connect
- Android: Android Studio Build → Play Console → Internal Testing → Production
- Push Notifications: APNs direkt für iOS, ntfy für Android — kein Firebase, kein `@capacitor/push-notifications` nötig

### Stufe 3 — Native Widgets via `capacitor-widget-bridge` (minimaler nativer Code)

Das Community-Plugin `capacitor-widget-bridge` übernimmt die komplette Daten-Brücke zwischen App und Widget. Kein Custom Capacitor Plugin nötig.

**So funktioniert's:**

```
┌─────────────────────────────────────────────┐
│  SvelteKit App (JS)                         │
│                                             │
│  // Habit-Daten in SharedStorage schreiben  │
│  WidgetBridge.setItem({                     │
│    group: 'group.com.smarthabit',           │
│    key: 'habits',                           │
│    value: JSON.stringify(todayHabits)       │
│  });                                        │
│  WidgetBridge.reloadAllTimelines();         │
│                                             │
└──────────────────┬──────────────────────────┘
                   │ SharedDefaults (iOS)
                   │ SharedPreferences (Android)
                   ▼
┌─────────────────────────────────────────────┐
│  Native Widget                              │
│                                             │
│  iOS:  ~50-80 Zeilen SwiftUI               │
│        → liest UserDefaults(suiteName:)    │
│        → zeigt Habit-Liste + Tap-Buttons   │
│                                             │
│  Android: ~80-100 Zeilen Kotlin + XML      │
│        → liest SharedPreferences            │
│        → RemoteViews Layout                │
│                                             │
└─────────────────────────────────────────────┘
```

**Was du selbst schreiben musst** (das Plugin nimmt dir den Rest ab):
- iOS: eine SwiftUI Widget Extension (~50-80 Zeilen) — liest JSON aus UserDefaults, rendert als Liste
- Android: ein AppWidgetProvider (~80-100 Zeilen Kotlin) + ein XML-Layout — liest JSON aus SharedPreferences

**Was das Plugin übernimmt**:
- `setItem()` / `getItem()` / `removeItem()` — Daten zwischen JS und nativem Widget teilen
- `reloadAllTimelines()` / `reloadTimelines()` — Widget-Refresh programmatisch triggern
- Funktioniert auf beiden Plattformen mit derselben JS-API

**Datenfluss**:
1. App öffnet → `GET /api/v1/dashboard` → Habit-Daten in SharedStorage schreiben via `WidgetBridge.setItem()`
2. Widget liest gecachte Daten direkt aus SharedStorage (kein API-Call vom Widget)
3. Tap auf "Erledigt" im Widget → öffnet App mit Deep Link → App loggt via API
4. Nach dem Log: `WidgetBridge.reloadAllTimelines()` → Widget refreshed

Tap-to-Log direkt aus dem Widget ohne App-Öffnung ist technisch möglich (via App Intents auf iOS, PendingIntent auf Android), aber eine Iteration komplexer. Für v1 reicht: Widget zeigt Status, Tap öffnet App am richtigen Habit.

**Widget-Größen**:
- iOS: Small (1-2 Habits, nur Status), Medium (4 Habits mit Tap-Targets), Large (alle Habits)
- Android: 2×1 (kompakt), 4×2 (voll)

### Optional: iOS Live Activities

Nicht priorisiert, aber für die Zukunft interessant: `capacitor-live-activity` Plugin für temporäre Lockscreen-Anzeigen. Beispiel: "Hund ist seit 45min draußen" als Timer auf dem Lockscreen + Dynamic Island. Cooles Feature, aber Nische — erst nach Stufe 3 wenn die Basis steht.
