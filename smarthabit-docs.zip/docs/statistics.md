# Statistiken & Analytics
## Statistiken & Analytics

Statistiken kommen als eigenständige Phase 5, nachdem das lernende System (Phase 4) Daten liefert.

### API Endpoints

```
GET /api/v1/habits/{id}/stats          — Stats pro Habit
GET /api/v1/stats/household            — Household-weite Übersicht
GET /api/v1/stats/user/{id}            — Stats pro User (optional)
```

### Stats pro Habit

- **Streak**: Aktuelle und längste Serie aufeinanderfolgender Tage (Timezone-aware, basierend auf User-Lokalzeit)
- **Completion Rate**: Prozent der Tage im letzten Monat / Quartal / Jahr an denen der Habit erledigt wurde — relativ zu `frequency`/`frequency_days`
- **Durchschnittliche Uhrzeit**: Median der Log-Zeiten (gleiche Logik wie TimeWindowLearner)
- **Trend**: Wird der Habit früher/später erledigt als vor 30 Tagen? Steigt/sinkt die Completion Rate?
- **Verteilung nach User**: Wer erledigt den Habit wie oft? (Prozentual pro Household-Mitglied)

### Household-Dashboard

- **Gesamte Completion Rate**: Alle Habits aggregiert
- **Aktivster User**: Wer loggt am meisten?
- **Habit-Ranking**: Welche Habits werden am zuverlässigsten erledigt, welche werden oft vergessen?
- **Wochentags-Heatmap**: An welchen Tagen werden Habits am häufigsten vergessen?
- **Zeitliche Heatmap**: Zu welchen Uhrzeiten wird am meisten geloggt? (Aggregiert über alle Habits)

### Technische Umsetzung

Basis-Stats (Streak, Completion Rate) werden on-the-fly aus `HabitLog` berechnet — bei wenigen hundert Logs pro Habit ist das performant genug als PostgreSQL-Query mit Window Functions.

Für das Analytics-Dashboard (Heatmaps, Trends, Verteilungen) lohnt sich ein **Materialized View** oder eine separate `HabitStats`-Tabelle die nightly vom `app:compute-stats`-Command befüllt wird. Das vermeidet teure Aggregationen bei jedem Dashboard-Load.

Frontend: Charts via einer leichtgewichtigen Svelte-Chart-Library (z.B. `layerchart` oder `pancake`). Heatmaps als SVG-Grid, kein schweres Chart-Framework nötig.
