# Coding Guidelines

Diese Guidelines gelten für alle PHP-Projekte. Sie ergänzen die automatisierten Tools (PHPStan, Rector, ECS, Infection) um Dinge die kein Tool prüfen kann: Architektur-Entscheidungen, Naming, Struktur, Defensive Patterns.

## Kernprinzipien

**KISS** — Die einfachste Lösung die das Problem löst. Keine Abstraktion ohne konkreten zweiten Use-Case.

**YAGNI** — Kein Code für Features die vielleicht irgendwann kommen. Wenn du ein Interface mit nur einer Implementierung schreibst "weil wir vielleicht später..." → lösch das Interface.

**DRY** — Aber: Duplication ist billiger als die falsche Abstraktion. Zwei ähnliche Methoden sind besser als eine die mit Flags für beide Fälle zurechtgebogen wird.

**SOLID** — Nicht als akademisches Ideal, sondern als Refactoring-Kompass. Wenn eine Klasse schwer zu testen ist, verletzt sie wahrscheinlich SRP oder DIP.

**Minimal & Defensive** — Jede Methode validiert ihre Eingaben. Jede Rückgabe hat einen expliziten Typ. Kein implizites Verhalten, kein "das funktioniert halt so".

---

## PHP-Konventionen

### Strict Types — immer, überall

```php
<?php

declare(strict_types=1);
```

Erste Zeile, jede Datei, keine Ausnahme. PHP ohne strict_types ist eine andere Sprache.

### Value Objects für Domain-Konzepte

Primitive Obsession ist der häufigste Fehler. Ein Zeitfenster ist kein Array mit zwei Strings.

```php
// ❌ Primitive Obsession
function isInWindow(string $start, string $end, string $timezone): bool

// ✅ Value Object
final readonly class TimeWindow
{
    public function __construct(
        public \DateTimeImmutable $start,
        public \DateTimeImmutable $end,
    ) {
        if ($start >= $end) {
            throw new \InvalidArgumentException('Start must be before end.');
        }
    }

    public function contains(\DateTimeImmutable $time): bool
    {
        return $time >= $this->start && $time <= $this->end;
    }
}
```

Gute Kandidaten für Value Objects: E-Mail-Adressen, Invite Codes, Timezones, Zeitfenster, UUIDs, Geldbeträge, Koordinaten. Regel: wenn du einen primitiven Wert validieren musst bevor du ihn nutzt, braucht er ein Value Object.

### Immutability by Default

`readonly` auf jeder Klasse und Property die nicht mutiert werden muss. PHP 8.4 macht das mit Property Hooks noch mächtiger.

```php
// ✅ Immutable by default
final readonly class HabitCreatedEvent
{
    public function __construct(
        public Uuid $habitId,
        public Uuid $householdId,
        public \DateTimeImmutable $createdAt,
    ) {}
}
```

- `DateTimeImmutable` statt `DateTime` — immer, überall.
- `readonly class` als Default. Nur `class` wenn Mutation explizit nötig ist.
- Arrays die nicht wachsen sollen → Rückgabetyp dokumentieren, nicht `array` sondern spezifische Collection-Types.

### Early Returns — keine Else-Ketten

```php
// ❌ Verschachtelt, schwer zu lesen
function canNotify(User $user, Habit $habit): bool
{
    if ($user->isVerified()) {
        if ($habit->isActive()) {
            if (!$this->wasNotifiedToday($user, $habit)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    } else {
        return false;
    }
}

// ✅ Early Returns — flach, lesbar
function canNotify(User $user, Habit $habit): bool
{
    if (!$user->isVerified()) {
        return false;
    }

    if (!$habit->isActive()) {
        return false;
    }

    if ($this->wasNotifiedToday($user, $habit)) {
        return false;
    }

    return true;
}
```

Regel: maximale Verschachtelungstiefe 2. Wenn du ein drittes `if` in einem `if` in einem `if` schreibst, refactore.

### Composition over Inheritance

```php
// ❌ Vererbungskette
abstract class AbstractNotifier
{
    abstract protected function send(): void;
    // 200 Zeilen gemeinsame Logik
}

class WebPushNotifier extends AbstractNotifier { ... }
class NtfyNotifier extends AbstractNotifier { ... }
class ApnsNotifier extends AbstractNotifier { ... }

// ✅ Interface + Composition
interface PushTransport
{
    public function send(PushSubscription $subscription, Notification $notification): PushResult;
    public function supports(PushSubscription $subscription): bool;
}

final readonly class WebPushTransport implements PushTransport { ... }
final readonly class NtfyTransport implements PushTransport { ... }
final readonly class ApnsTransport implements PushTransport { ... }

// Strategy Pattern — zur Laufzeit den richtigen Transport wählen
final readonly class NotificationDispatcher
{
    /** @param iterable<PushTransport> $transports */
    public function __construct(
        private iterable $transports,
    ) {}

    public function dispatch(PushSubscription $sub, Notification $notification): PushResult
    {
        foreach ($this->transports as $transport) {
            if ($transport->supports($sub)) {
                return $transport->send($sub, $notification);
            }
        }

        throw new UnsupportedTransportException($sub->type);
    }
}
```

Symfony's tagged services machen das trivial — `#[AutoconfigureTag('app.push_transport')]` und Dependency Injection erledigt den Rest.

### Design Patterns — wann welches

| Pattern | Wann einsetzen | Beispiel in diesem Projekt |
|---|---|---|
| **Strategy** | Mehrere Algorithmen die dasselbe Interface erfüllen | Push-Transports (WebPush, ntfy, APNs) |
| **Factory** | Objekt-Erzeugung mit Logik/Validierung | `PushSubscriptionFactory::fromRequest()` |
| **Repository** | Datenbankzugriff abstrahieren | Doctrine Repositories, custom Query Methods |
| **Value Object** | Primitive mit Bedeutung und Validierung | `TimeWindow`, `InviteCode`, `Email` |
| **DTO** | Daten zwischen Schichten transportieren | Request/Response DTOs für API |
| **Observer/Event** | Entkoppelte Reaktion auf Aktionen | Symfony Events (HabitLogged → Mercure Update) |
| **Decorator** | Verhalten erweitern ohne Klasse zu ändern | Logging um einen Service wrappen |

Nicht einsetzen bis es gebraucht wird: Abstract Factory, Builder, Mediator, Singleton (nie), Service Locator (nie).

### Dependency Injection — Konstruktor only

```php
// ❌ Setter Injection — unvollständige Objekte möglich
class NotifyHandler
{
    private WebPushService $webPush;

    public function setWebPush(WebPushService $webPush): void
    {
        $this->webPush = $webPush;
    }
}

// ❌ Service Locator — versteckte Dependencies
class NotifyHandler
{
    public function handle(): void
    {
        $webPush = $this->container->get(WebPushService::class);
    }
}

// ✅ Constructor Injection — Dependencies sind explizit und erzwungen
final readonly class NotifyHandler
{
    public function __construct(
        private WebPushService $webPush,
        private NtfyClient $ntfy,
        private LoggerInterface $logger,
    ) {}
}
```

### Methoden — kurz und fokussiert

- **Maximum 20 Zeilen** pro Methode. Wenn länger → extrahiere private Methoden.
- **Maximum 3 Parameter**. Mehr → DTO oder Value Object.
- **Cognitive Complexity max 8** pro Methode — enforced via `tomasvotruba/cognitive-complexity` in PHPStan. Jede Verschachtelung, jeder `break`, jedes `continue`, jedes `&&`/`||` in Conditionals erhöht den Score. Cognitive Complexity misst die mentale Last beim Lesen, nicht die Anzahl der Pfade (das wäre Cyclomatic Complexity).
- **Ein Abstraktionslevel** pro Methode. Nicht Business-Logik und SQL in derselben Methode.
- **Methodennamen sind Verben**: `findActiveHabits()`, `markAsCompleted()`, `dispatchNotification()`. Nicht `habits()`, `completed()`, `notification()`.

### Klassen — klein und fokussiert

- **Maximum ~150 Zeilen** pro Klasse (ohne Imports/Docblocks). Wenn mehr → Klasse hat zu viele Verantwortlichkeiten.
- **Cognitive Complexity max 50** pro Klasse — enforced via PHPStan.
- **Maximum 5 Dependencies** im Konstruktor. Mehr → Klasse macht zu viel. Extrahiere einen Service.
- **`final` by default**. Jede Klasse ist `final` bis nachgewiesen wird dass Extension nötig ist. Verhindert fragile Base-Class Problem.
- **`readonly` by default**. Jede Klasse ist `final readonly` bis Mutation explizit gebraucht wird.

### Keine Magic Values

```php
// ❌ Magic Numbers und Strings
if ($retryCount > 3) { ... }
if ($status === 'sent') { ... }
$token = substr($random, 0, 32);

// ✅ Benannte Konstanten und Enums
private const int MAX_RETRY_COUNT = 3;
private const int TOKEN_LENGTH = 32;

enum NotificationStatus: string
{
    case Sent = 'sent';
    case Failed = 'failed';
    case Clicked = 'clicked';
}
```

### Error Handling — explizit, nie verschluckt

```php
// ❌ Exception verschluckt
try {
    $this->webPush->send($subscription, $payload);
} catch (\Exception) {
    // do nothing
}

// ❌ Generisches catch-all
try {
    $this->webPush->send($subscription, $payload);
} catch (\Exception $e) {
    throw new \RuntimeException('Push failed');
}

// ✅ Spezifisch fangen, loggen, Domain-Exception werfen
try {
    $this->webPush->send($subscription, $payload);
} catch (ExpiredSubscriptionException $e) {
    $this->subscriptionManager->remove($subscription);
    $this->logger->info('Removed expired subscription', ['endpoint' => $subscription->endpoint]);
} catch (RateLimitException $e) {
    throw PushDeliveryException::rateLimited($subscription, $e);
} catch (TransportException $e) {
    $this->logger->error('Push delivery failed', [
        'endpoint' => $subscription->endpoint,
        'error' => $e->getMessage(),
    ]);
    throw PushDeliveryException::transportError($subscription, $e);
}
```

Custom Exceptions mit Named Constructors sind lesbarer als `new PushDeliveryException('message', 0, $previous)`.

### Return Types — immer explizit

```php
// ❌ Impliziter Return
function findUser(Uuid $id)  // was kommt zurück? User? null? array?

// ✅ Explizit
function findUser(Uuid $id): ?User
function getUser(Uuid $id): User  // wirft Exception wenn nicht gefunden
function findUsersByHousehold(Uuid $householdId): array  // @return User[]
```

Konvention: `find*` darf `null` zurückgeben, `get*` wirft wenn nicht gefunden.

---

## Svelte/TypeScript-Konventionen

### TypeScript strict

```json
// tsconfig.json
{
  "compilerOptions": {
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitReturns": true
  }
}
```

### Keine `any` — niemals

```typescript
// ❌
function parseResponse(data: any): Habit { ... }

// ✅
interface HabitResponse {
  id: string;
  name: string;
  emoji: string;
  // ...
}
function parseResponse(data: HabitResponse): Habit { ... }
```

### Svelte 5 Runes statt legacy

```svelte
<!-- ❌ Legacy -->
<script>
  let count = 0;
  $: doubled = count * 2;
</script>

<!-- ✅ Svelte 5 Runes -->
<script>
  let count = $state(0);
  let doubled = $derived(count * 2);
</script>
```

### Komponenten — klein und Props-getrieben

- Maximal ~100 Zeilen pro Komponente (Template + Script + Style).
- Props mit Defaults und Typen. Keine `$$props` oder `$$restProps`.
- Kein Business-Logic in Komponenten — extrahiere in `$lib/` Modules.
- Kein direkter `fetch` in Komponenten — nutze den API-Wrapper aus `$lib/api/`.

---

## Allgemeine Regeln

### Git Commits

- Conventional Commits: `feat:`, `fix:`, `refactor:`, `test:`, `docs:`, `chore:`.
- Ein Commit = eine logische Änderung. Kein "fix everything" Commit.
- Commit Message beschreibt **warum**, nicht **was**. Das Diff zeigt was geändert wurde.

### Ordnerstruktur folgt Domain, nicht Framework

```
src/
├── Habit/                  — Alles rund um Habits
│   ├── Entity/
│   ├── Repository/
│   ├── Service/
│   ├── Event/
│   └── Exception/
├── Household/              — Household + Invite-Logik
├── Notification/           — Push-Dispatch, alle Transports
├── Auth/                   — Registration, Login, JWT, Password Reset
├── Stats/                  — Statistiken + Analytics
└── Shared/                 — Value Objects, Interfaces, Utils die domain-übergreifend sind
```

Nicht: `src/Entity/`, `src/Service/`, `src/Controller/` als flache Ordner mit 30 Dateien. Das skaliert nicht und verrät nichts über die Domain.

**Enforced via phpat** — Architecture Tests in `tests/Architecture/` prüfen automatisch in der CI: Domain-Services dürfen nicht von Symfony/Doctrine abhängen, Entities dürfen nicht von Services abhängen, kein Layer darf nach oben greifen (Service → Controller). Siehe `docs/testing.md` für die konkreten phpat-Regeln.

---

## Automatisierte Enforcement-Matrix

Diese Guidelines sind keine Empfehlungen — sie werden automatisch in der CI enforced:

| Regel | Tool | Grenze | CI blockiert? |
|---|---|---|---|
| Cognitive Complexity pro Methode | `tomasvotruba/cognitive-complexity` | max 8 | Ja |
| Cognitive Complexity pro Klasse | `tomasvotruba/cognitive-complexity` | max 50 | Ja |
| Type Coverage (return, param, property) | `tomasvotruba/type-coverage` | 100% | Ja |
| `declare(strict_types=1)` Coverage | `tomasvotruba/type-coverage` | 100% | Ja |
| Domain-Isolation (keine Framework-Deps) | `phpat/phpat` | Architektur-Test | Ja |
| Layer-Dependencies (keine Aufwärts-Deps) | `phpat/phpat` | Architektur-Test | Ja |
| Naming Conventions | `phpat/phpat` + `shipmonk/phpstan-rules` | Architektur-Test | Ja |
| Strikte Typ-Vergleiche (`===`, kein `empty`) | `phpstan-strict-rules` | strict | Ja |
| Deprecated-Code-Nutzung | `phpstan-deprecation-rules` | 0 Deprecations | Ja |
| Enum-Safety, vergessene Exceptions, Casts | `shipmonk/phpstan-rules` | ~40 Rules | Ja |
| Operator-Typ-Kompatibilität | `voku/phpstan-rules` | strict | Ja |
| Debug-Funktionen verboten | `shipmonk/phpstan-rules` (`forbidCustomFunctions`) | 0 | Ja |
| `DateTime` verboten (nur Immutable) | `shipmonk/phpstan-rules` (`forbidCustomFunctions`) | 0 | Ja |
| Uninitialized Properties | PHPStan (`checkUninitializedProperties`) | strict | Ja |
| Implicit Mixed | PHPStan (`checkImplicitMixed`) | strict | Ja |
| PHPStan Level | `phpstan/phpstan` | max | Ja |
| Coding Standard | `symplify/easy-coding-standard` | PSR-12 + strict | Ja |
| Code-Modernität | `rector/rector` | PHP 8.4 + Symfony 8 | Ja (dry-run) |
| Path Coverage | PHPUnit 13 + PCOV | >= 80% | Ja |
| Mutation Score (MSI) | `infection/infection` | >= 80% | Ja |
| Covered Code MSI | `infection/infection` | >= 90% | Ja |

Alles was in dieser Tabelle steht, blockt den Merge wenn es nicht erfüllt ist. Kein "wir fixen das später".

### Code Review Checkliste

Bevor Code gemergt wird — mental durchgehen:

1. **Tut es was es soll?** — Nicht "sieht der Code gut aus", sondern: löst er das Problem?
2. **Fehlt ein Test?** — Jeder neue Pfad braucht einen Test. Jede Exception braucht einen Test.
3. **Kann ich es in 6 Monaten noch verstehen?** — Clever Code ist schlechter Code.
4. **Ist die einfachste Lösung gewählt?** — Gibt es einen Weg mit weniger Code?
5. **Sind Edge Cases behandelt?** — null, leere Arrays, Timezone-Grenzen, Race Conditions.
6. **Dependency Richtung korrekt?** — Domain hängt nicht von Infrastructure ab.
7. **Ist die Fehlerbehandlung spezifisch?** — Kein catch-all, kein verschlucktes Exception.
8. **Sind alle Strings externalisiert?** — Hardcoded Strings die der User sieht → i18n.
