# Frontend & Design
## Frontend (SvelteKit PWA)

### Architektur

SvelteKit im **SPA-Modus** (`adapter-static`), deployed als statische Files hinter FrankenPHP/Caddy. Kein SSR nötig — die App ist komplett client-seitig nach dem Initial Load. Build komplett über Bun, kein Symfony AssetMapper.

```
frontend/
├── src/
│   ├── lib/
│   │   ├── api/          — Fetch-Wrapper, JWT Handling, Offline Queue
│   │   ├── stores/       — Svelte 5 Runes ($state, $derived) für globalen State
│   │   └── components/   — UI-Komponenten
│   ├── routes/
│   │   ├── +layout.svelte     — Shell: Auth-Check, Nav
│   │   ├── (app)/
│   │   │   ├── +page.svelte         — Dashboard (Hauptansicht)
│   │   │   ├── habits/[id]/+page.svelte  — History + Stats
│   │   │   └── settings/+page.svelte     — Household, Zeitfenster, Account
│   │   └── (auth)/
│   │       ├── login/+page.svelte
│   │       └── register/+page.svelte
│   ├── service-worker.ts     — Web Push Handler + Offline Cache
│   └── app.html
├── static/
│   └── manifest.json         — PWA Manifest
├── bun.lock                  — Bun Lockfile (statt package-lock.json)
├── svelte.config.js
└── vite.config.ts
```

### PWA-Features

- **Service Worker**: `@vite-pwa/sveltekit` für automatisches Caching
- **Offline-Fähigkeit**: Logs werden lokal gespeichert und gesynct wenn online
- **Install Prompt**: manifest.json mit Icons, Theme-Color, Start-URL
- **Push**: W3C Web Push API im Service Worker (kein Firebase SDK, VAPID-Auth)

### UI-Prinzip

Dashboard = eine Liste großer Tap-Targets. Jedes Habit ist eine Karte:
- Emoji + Name
- Letzter Log: "Heute 07:32 von Lisa" oder "Noch nicht erledigt"
- Ein Tap → POST /log → optimistisches UI-Update → Scale-Pulse Checkmark Animation
- Long Press → History

Kein Hamburger-Menü, kein Overhead. Öffnen → tippen → fertig.

### Design-Richtung: Neo Utility + Dark Mode

**Grundästhetik**: Funktional, klar, datengetrieben. Die App soll sich wie ein gut gebautes Tool anfühlen — nicht wie eine Wellness-App. Informationsdichte ohne Chaos, klare Hierarchie, alles auf den ersten Blick erfassbar.

**Typografie**:
- Headlines: `Sora` (Sans-Serif, geometrisch, modern) — 700 weight
- Body: `Sora` — 400/600 weight
- Metadaten + Monospace-Details: `JetBrains Mono` — Timestamps, Fenster-Zeiten, Stats
- Keine Serifs, kein verspieltes Lettering — das ist ein Utility-Tool

**Farbpalette Light Mode**:
```
--bg-primary:    #F4F5F7     (Hintergrund)
--bg-card:       #FFFFFF     (Karten)
--bg-header:     #FFFFFF     (Header)
--border:        #E8EAEE     (Trennlinien, Karten-Borders)
--text-primary:  #1A1D24     (Headlines, Habit-Namen)
--text-secondary:#888D98     (Subtitles, Metadaten)
--text-tertiary: #B0B4BC     (Timestamps, Nav inaktiv)
--accent:        #3366FF     (Primäre Aktion, Progress, aktiver Nav)
--success:       #22C55E     (Erledigt, Checkmarks, Done-Border)
--warning:       #E65100     (Überfälliges Zeitfenster)
--tag-blue-bg:   #F0F4FF     (Zeitfenster-Tag Hintergrund)
--tag-orange-bg: #FFF3E0     (Überfällig-Tag Hintergrund)
```

**Farbpalette Dark Mode** (Toggle in Einstellungen, respektiert `prefers-color-scheme`):
```
--bg-primary:    #0A0A0A     (Hintergrund)
--bg-card:       #141416     (Karten)
--bg-header:     #0A0A0A     (Header)
--border:        #1E1E22     (Trennlinien)
--text-primary:  #E8E8E8     (Headlines)
--text-secondary:#666A74     (Subtitles)
--text-tertiary: #444650     (Timestamps)
--accent:        #4D88FF     (Primäre Aktion, etwas heller als Light)
--success:       #5ACA46     (Erledigt)
--warning:       #FF8A50     (Überfällig)
--tag-blue-bg:   #1A1E2E     (Zeitfenster-Tag)
--tag-orange-bg: #2A1A0E     (Überfällig-Tag)
```

**Kernelemente des Neo Utility-Designs**:
- **Progress-Bar im Header**: Zeigt Tagesfortschritt (2 von 4 = 50%). Visuelles Feedback ohne Zahlen lesen zu müssen
- **Farbige Tags/Badges**: Zeitfenster als Chip (`18:00–20:00` auf blauem Hintergrund), überfällige auf orangem
- **Left-Border Indikator**: Erledigte Habits haben einen 3px grünen Left-Border, offene einen grauen — scannbar ohne Text lesen
- **Vier Nav-Items**: Today, History, Stats, Config — Stats als eigener Tab statt versteckt in den Einstellungen
- **Monospace für Daten**: Alle Uhrzeiten, Dates, Stats-Zahlen in JetBrains Mono — technisch, präzise, gut lesbar

**Dark Mode Umsetzung**:
- CSS Custom Properties + `prefers-color-scheme` Media Query als Default
- User kann in den Einstellungen überschreiben: Auto / Light / Dark
- Preference wird in `User.theme: enum(auto, light, dark)` gespeichert
- Svelte: `$state` Store der die CSS-Klasse auf `<body>` setzt
- Kein separates Stylesheet — gleiche Komponenten, nur Variablen-Swap

**Micro-Interactions**:
- Tap auf Check-Button: kurzer Scale-Pulse (0.9 → 1.1 → 1.0) + Farb-Transition zu Grün
- Progress-Bar animiert sanft beim Update (CSS `transition: width 0.4s ease-out`)
- Karten staggered erscheinen beim ersten Load (`animation-delay` pro Karte)
- Kein Confetti, keine Bouncing-Elemente — das Tool bleibt sachlich

## Internationalisierung (i18n)

Von Tag 1 zweisprachig: Deutsch + Englisch. Nachträglich i18n einbauen ist einer der schmerzhaftesten Refactors — deshalb direkt.

### Frontend: paraglide-sveltekit

Paraglide (von Inlang) ist der i18n-Standard für SvelteKit. Kompiliert Übersetzungen zur Build-Zeit, zero Runtime-Overhead, vollständig typesichere Message-Keys.

```
frontend/
├── messages/
│   ├── de.json      — { "dashboard.greeting": "Guten Morgen 👋", ... }
│   └── en.json      — { "dashboard.greeting": "Good morning 👋", ... }
├── src/
│   ├── lib/i18n/    — paraglide Runtime (generiert)
│   └── ...
```

Verwendung im Svelte-Code:
```svelte
<script>
  import * as m from '$lib/i18n/messages';
</script>
<h1>{m.dashboard_greeting()}</h1>
```

Vorteile gegenüber Runtime-i18n-Libraries: Tree-Shaking (unbenutzte Messages fallen raus), TypeScript-Autocomplete für alle Keys, kein JSON-Parsing zur Laufzeit.

**Spracherkennung**: `Accept-Language` Header → Browser-Sprache als Default. User kann in den Einstellungen überschreiben. Sprach-Präferenz wird im `User`-Entity gespeichert (`locale: string`, Default `de`).

### Backend: Symfony Translator

Symfony's eingebauter Translator für alles was vom Server kommt:

```
translations/
├── messages.de.yaml   — notification_texts, validation_messages, error_messages
└── messages.en.yaml
```

Relevant für: Notification-Texte ("Warst du heute schon mit dem Hund draußen?" / "Have you walked the dog today?"), Validation-Errors (API-Responses), E-Mail-Templates (falls später benötigt).

Das `Habit.notification_message`-Feld wird zu einem Translation-Key statt hartem Text. Der NotifyHandler resolvet den Key gegen die Sprache des Ziel-Users.

### User-Entity Erweiterung

Die Felder `locale`, `theme`, `consent_at`, `consent_version` und `email_verified_at` sind bereits im Hauptdatenmodell definiert (siehe Datenmodell-Sektion). API-Responses enthalten `locale` und `theme` im JWT-Payload und im `/api/v1/user/me`-Response. Das Frontend setzt Sprache und Theme basierend darauf.
