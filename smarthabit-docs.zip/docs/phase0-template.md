# Phase 0 — GitHub Repository Template

## Ziel

Ein **öffentliches** GitHub Template Repository (MIT License) für Full-Stack-Projekte mit PHP 8.4 + Symfony 8 Backend und SvelteKit Frontend. Enthält den kompletten Quality-Stack, Docker-Setup, CI/CD, Claude Code Integration und Coding Guidelines. Keine domainspezifische Logik — nur Infrastruktur und Tooling.

Das Template ist Open Source und wird als Referenz-Setup für die Community gepflegt. Private Projekte (wie SmartHabit) werden über `Use this template` → private Repo erstellt.

## Spezifikationen

Die Detailspezifikation ist in thematische Dateien aufgeteilt. Jede Datei ist eigenständig und enthält alle Informationen die Claude Code braucht um den jeweiligen Teil zu bauen.

| Datei | Inhalt | Zeilen |
|---|---|---|
| [`phase0/docker.md`](phase0/docker.md) | Dockerfile (Multi-Stage), compose.yaml, compose.override.yaml, compose.prod.yaml, init.sql | ~160 |
| [`phase0/backend.md`](phase0/backend.md) | composer.json, phpstan.neon, rector.php, ecs.php, infection.json5, phpunit.xml.dist, HealthController, Architecture Tests | ~143 |
| [`phase0/frontend.md`](phase0/frontend.md) | package.json, tsconfig.json, API Client, Landing Page, PWA Skeleton | ~66 |
| [`phase0/infrastructure.md`](phase0/infrastructure.md) | OpenTofu: versions.tf, main.tf, variables.tf, 4 Module (server, network, volume, dns), cloud-init.yml, .gitignore | ~352 |
| [`phase0/ci.md`](phase0/ci.md) | GitHub Actions: Backend CI (3 parallele Jobs + Tests), Frontend CI, Claude Update/Review/@mention, Dependabot + Auto-Merge | ~440 |
| [`phase0/dx.md`](phase0/dx.md) | Makefile, CaptainHook (Git Hooks), .editorconfig, .gitattributes, .gitignore, .env.example | ~334 |
| [`phase0/claude-spec.md`](phase0/claude-spec.md) | CLAUDE.md Template (~30 Zeilen), .claude/ Verzeichnis (4 Guidelines: coding-php, coding-frontend, testing, architecture) | ~294 |
| [`phase0/open-source.md`](phase0/open-source.md) | LICENSE (MIT), CONTRIBUTING.md, CODE_OF_CONDUCT.md, SECURITY.md, CHANGELOG.md, Issue Templates, README.md, **GitHub Settings & Discoverability** | ~410 |

## Repository-Struktur

```
template-symfony-sveltekit/
├── .claude/                          # Claude Code Guidelines (4 Dateien)
├── .github/
│   ├── workflows/                    # 6 Workflows (CI, Frontend CI, Claude ×3, Dependabot)
│   ├── ISSUE_TEMPLATE/               # Bug Report + Feature Request (YAML)
│   ├── dependabot.yml
│   ├── PULL_REQUEST_TEMPLATE.md
│   └── CODEOWNERS
├── docker/                           # FrankenPHP Dockerfile, PostgreSQL init, PgBouncer config
├── backend/                          # Symfony 8: src/, tests/, Config-Dateien, captainhook.json
├── frontend/                         # SvelteKit 2 + Svelte 5 + Bun + Tailwind 4
├── infrastructure/                   # OpenTofu Skeleton (Hetzner + Cloudflare)
├── compose.yaml + override + prod    # Docker Compose (dev + prod)
├── Makefile                          # Alle Shortcuts
├── .dockerignore                     # Schützt Docker Build-Context
├── .editorconfig                     # IDE-übergreifende Formatierung
├── .gitattributes                    # LF, diff=php, Lockfile -diff
├── .gitignore                        # Vollständig
├── .env.example                      # Alle ENV-Vars dokumentiert
├── CLAUDE.md                         # Entry Point für Claude Code
├── README.md + CONTRIBUTING.md       # Open-Source Docs
├── CODE_OF_CONDUCT.md + SECURITY.md  # Community Standards
├── CHANGELOG.md                      # Keep a Changelog Format
└── LICENSE                           # MIT
```

## Template-Nutzung für SmartHabit

Das Template ist **public** (MIT, Open Source). SmartHabit wird ein **privates Repo**.

```bash
gh repo create smarthabit-tracker --template [owner]/template-symfony-sveltekit --private
```

Nach Erstellung:

1. `.env.example` → `.env.local` mit echten Werten
2. `ANTHROPIC_API_KEY` als GitHub Repository Secret setzen
3. Domain-Ordner anlegen: `src/Habit/`, `src/Notification/`, `src/Auth/`, `src/Household/`, `src/Stats/`
4. phpat `DomainIsolationTest` hinzufügen (SmartHabit-spezifisch)
5. Frontend: Design Tokens auf Neo Utility anpassen
6. `CLAUDE.md` erweitern mit SmartHabit-Kontext
7. `.claude/architecture.md` erweitern mit Entities, API-Endpoints, Push-Architektur
8. Neue Datei `.claude/domain.md` für SmartHabit-spezifisches Domain-Wissen
9. Entfernen: `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, Issue Templates (nicht nötig für privat)
10. `claude-update.yml` erst nach Phase 1b aktivieren (vorher zu wenig Code für sinnvolle Updates)

## Hinweis: Single Source of Truth

Die Specs in `phase0/` und `docs/` überlappen sich bewusst (z.B. PHPStan-Config in `phase0/backend.md`, `docs/testing.md` und `phase0/claude-spec.md`). **Nach Phase 0 ist der Code die Wahrheit**, nicht die Doku. Die Dateien `phpstan.neon`, `rector.php`, `ecs.php` etc. im Repo sind die Source of Truth — die Markdown-Docs sind der Plan der dorthin geführt hat. Die `docs/` Dateien einmal nach Phase 0 gegen den tatsächlichen Code abgleichen, danach lebt die Config nur noch im Code.

## Definition of Done

Das Template ist fertig wenn:

- [ ] `docker compose --profile dev up -d` startet alle Services ohne Fehler
- [ ] PHP-Container Healthcheck (`/api/v1/health`) ist grün
- [ ] `make quality` läuft komplett durch (ECS, PHPStan, Rector, PHPUnit, Infection)
- [ ] HealthController Test (Integration) ist grün gegen echte PostgreSQL
- [ ] Architecture Tests (phpat) laufen in PHPStan
- [ ] GitHub Actions CI (Backend + Frontend) ist grün auf einem Push
- [ ] Backend CI: ECS, PHPStan, Rector laufen als **parallele Jobs**
- [ ] Frontend: `bun run check` + `bun run build` sind grün
- [ ] Git Hooks: CaptainHook installiert sich bei `composer install`
- [ ] Template ist als GitHub Template Repository markiert
- [ ] Repo ist **public** mit **MIT License**
- [ ] README mit Badges, Quick Start, After-Forking Checklist
- [ ] CONTRIBUTING.md, CODE_OF_CONDUCT.md, SECURITY.md vorhanden
- [ ] Issue Templates als YAML-Formulare
- [ ] `.editorconfig`, `.gitattributes`, `.gitignore` vollständig
- [ ] CLAUDE.md schlank (~30 Zeilen), `.claude/` mit 4 Guidelines
- [ ] Claude Workflows konfiguriert (update, review, @mention)
- [ ] Alle Quality-Config-Dateien enforceieren die dokumentierten Regeln
- [ ] `.env.example` enthält keine echten Secrets
- [ ] **GitHub Settings**: Topics gesetzt, Description ausgefüllt, Template-Flag aktiv, Discussions aktiviert
- [ ] **Social Preview Image** (1280×640px) hochgeladen
- [ ] **v1.0.0 Release** erstellt mit Release Notes
