# Notifications & Push
## Notification System

### Push-Architektur (kein Firebase)

Drei Push-Kanäle, alle ohne US-Dienste:

**1. Web Push (PWA)** — W3C Standard (RFC 8030), via `minishlink/web-push`:
- VAPID Key-Pair generieren: `openssl ecparam -genkey -name prime256v1 -out private.pem` (einmalig)
- Public Key im Frontend für `PushManager.subscribe()`, Private Key im Backend für `minishlink/web-push`
- Keys als Environment-Variablen: `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY` (nicht im Repo!)
- Browser fragt User um Permission → erzeugt PushSubscription (Endpoint + Keys)
- Frontend schickt Subscription an `POST /api/v1/user/push-subscription`
- Backend sendet verschlüsselte Payloads direkt an den Browser-Endpoint (VAPID-Auth)
- Funktioniert auf Chrome, Firefox, Edge, Safari 16.4+ — ohne Firebase SDK
- Die Browser routen intern über ihre eigenen Push-Dienste (Google/Mozilla/Apple), aber das ist Browser-Infrastruktur, kein Firebase

**2. ntfy (Native Android)** — self-hosted auf dem Hetzner VPS:
- Leichtgewichtiger Open-Source Push-Server (~10MB Binary, minimal RAM)
- App subscribed auf einen User-spezifischen ntfy-Topic (z.B. `smarthabit-user-{uuid}`)
- Backend published via einfachen HTTP POST: `POST https://ntfy.smarthabit.de/{topic}`
- Unterstützt UnifiedPush-Protokoll (offener Standard, kein Google)
- Docker-Container neben der App auf dem gleichen VPS

**3. APNs (Native iOS)** — Apple Push Notification service direkt:
- Einziger Weg für iOS Push, aber kein Firebase dazwischen nötig
- `symfony/notifier` hat einen nativen APNs-Transport
- Direkte HTTP/2-Verbindung zu api.push.apple.com mit JWT-Auth

### Cron-basierter Notification-Check

Ein Cron-Job dispatcht alle 15 Minuten ein `CheckHabitsMessage`:

```
Cron (alle 15min)
  → bin/console app:check-habits
    → Alle aktiven Habits mit Household + Users laden (JOIN)
    → Pro Habit, pro User im Household:
      → User-Lokalzeit berechnen: UTC now → User.timezone
      → Ist User-Lokalzeit innerhalb Habit.time_window_start/end?
      → Ist heute ein aktiver Tag? (frequency + frequency_days prüfen)
      → Wurde heute (in User-Lokalzeit!) schon erledigt? (HabitLog check)
      → Wurde heute schon eine Notification an diesen User geschickt?
      → Wenn nein: Dispatch NotifyHabitMessage an Messenger
        → Handler: Push an alle Subscriptions dieses Users
          → Web Push Subscriptions → minishlink/web-push
          → ntfy Subscriptions → HTTP POST an ntfy-Server
          → APNs Subscriptions → Symfony Notifier APNs Transport
```

Durch die Per-User-Prüfung funktioniert Multi-Timezone korrekt: Lisa in Berlin bekommt die Notification um 07:00 CET, Tom in New York um 07:00 EST — obwohl es der gleiche Habit ist.

### NotifyHandler (Multi-Transport)

```php
// Vereinfachte Logik
foreach ($user->getPushSubscriptions() as $subscription) {
    match ($subscription['type']) {
        'web_push' => $this->webPushService->send($subscription, $payload),
        'ntfy'     => $this->ntfyClient->publish($subscription['topic'], $payload),
        'apns'     => $this->apnsTransport->send($subscription['device_token'], $payload),
    };
}
```

Jeder Transport hat eigene Fehlerbehandlung. Fehlgeschlagene Subscriptions werden im NotificationLog mit `error_reason` und `push_type` geloggt.

### Auto-Zeitfenster (Lernend)

Ein Nightly-Command (`app:learn-timewindows`) analysiert die Logs der letzten 21 Tage:

```
1. Alle logged_at (UTC) Zeiten für einen Habit sammeln
2. Pro Log: UTC → User.timezone konvertieren, dann Minuten seit Mitternacht
3. Median berechnen = übliche Lokalzeit
4. MAD (Median Absolute Deviation) = robuster als Stddev gegen Ausreißer
5. Fenster = Median ± (1.5 × MAD), mindestens 30min breit
6. Weekday/Weekend Split wenn Pattern erkannt (>= 7 Datenpunkte pro Gruppe)
7. Habit.time_window_start/end updaten (als Lokalzeit), time_window_mode → auto
```

Warum MAD statt Standardabweichung: Ein einzelner Ausreißer (Hund um 23:00 rausgelassen weil Gäste da waren) verschiebt die Stddev massiv. MAD ist robust dagegen.

User kann jederzeit zurück auf manuell wechseln.

### ntfy Docker-Setup

Läuft als zusätzlicher Service auf dem Hetzner VPS, eigenes Compose oder im App-Stack:

```yaml
ntfy:
  image: binwiederhier/ntfy:latest
  command: serve
  restart: unless-stopped
  ports: ["127.0.0.1:2586:80"]  # nur intern, Caddy proxied
  volumes:
    - ntfy-cache:/var/cache/ntfy
    - ./ntfy/server.yml:/etc/ntfy/server.yml
  environment:
    TZ: UTC
```

Caddy-Route: `ntfy.smarthabit.de` → `ntfy:80` mit auto-HTTPS. Auth via Token-basiertem Access Control — nur der App-Server darf publishen, User subscriben über ihre Topics.

## Push Subscription Lifecycle

Push Subscriptions sind kurzlebig und unterschiedlich pro Plattform. Drei Mechanismen halten die Liste sauber:

**1. Registrierung** — Frontend/App schickt Subscription bei jedem Start via `POST /api/v1/user/push-subscription`. Idempotent: existierende Subscription wird aktualisiert (last_seen), neue wird hinzugefügt.

```
push_subscriptions: [
  {
    "type": "web_push",
    "endpoint": "https://updates.push.services.mozilla.com/wpush/v2/...",
    "keys": { "p256dh": "...", "auth": "..." },
    "device_name": "Chrome Desktop",
    "last_seen": "2026-03-21T10:00:00Z"
  },
  {
    "type": "ntfy",
    "topic": "smarthabit-user-abc123",
    "device_name": "Android Lisa",
    "last_seen": "2026-03-20T08:00:00Z"
  },
  {
    "type": "apns",
    "device_token": "a1b2c3...",
    "device_name": "iPhone Lisa",
    "last_seen": "2026-03-21T09:00:00Z"
  }
]
```

**2. Fehlerbehandlung im NotifyHandler**:
- Web Push: HTTP 410 (Gone) → Subscription entfernen. HTTP 429 → Retry mit Backoff.
- ntfy: HTTP 5xx → Retry. Topic existiert nicht → Subscription entfernen.
- APNs: Status 410 (Unregistered) → Subscription entfernen. Status 429 → Retry.

**3. Nightly Cleanup** — `app:cleanup-push-subscriptions` (Cron 04:00 UTC):
- Subscriptions mit `last_seen` älter als 30 Tage werden entfernt
- Schützt gegen vergessene Geräte (altes Handy, deinstallierte App)
- Loggt Cleanup-Aktionen für Debugging

**Logout** — `DELETE /api/v1/user/push-subscription` entfernt die Subscription des aktuellen Geräts explizit.
