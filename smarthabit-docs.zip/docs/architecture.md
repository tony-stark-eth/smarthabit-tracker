# Architecture
## Docker Setup

Basierend auf `dunglas/symfony-docker` — dem offiziellen Symfony Docker Template mit FrankenPHP. Vier Services (+ Messenger Worker), ein `compose.yaml`:

```
services:
  php:              # FrankenPHP (Caddy + PHP 8.4) — Web + Worker in einem
  database:         # PostgreSQL 17
  pgbouncer:        # Connection Pooling → database:5432
  bun:              # Bun 1.3.x — SvelteKit Dev-Server (nur dev Profile)
```

### Warum FrankenPHP statt PHP-FPM + nginx

FrankenPHP ersetzt PHP-FPM **und** nginx in einem einzigen Binary. Caddy ist eingebaut (auto-HTTPS via Let's Encrypt, HTTP/2, HTTP/3). Der entscheidende Vorteil ist der **Worker Mode**: Symfony bootet einmal, bleibt im Memory, und handelt Requests ohne erneutes Bootstrapping. Das eliminiert den größten Performance-Overhead bei PHP.

Konkret fällt weg: `php-fpm`-Container, `nginx`-Container, nginx-Config, FPM Pool-Tuning, FastCGI-Socket-Kommunikation. Stattdessen ein Container der alles macht.

### `dunglas/symfony-docker` als Basis

Das Projekt wird initial per Template erstellt:

```bash
docker compose build --pull --no-cache
docker compose up
```

Das Dockerfile folgt dem Multi-Stage-Pattern aus dem Template:

```
# Stage: frankenphp_base
FROM dunglas/frankenphp:latest-php8.4 AS frankenphp_base
  → ext-pdo_pgsql, ext-intl, ext-pcov (via install-php-extensions)
  → Composer install
  → Symfony Runtime: runtime/frankenphp-symfony

# Stage: frankenphp_dev
  → Xdebug optional, PCOV für Coverage
  → Hot-Reload via Caddy file_server + watch

# Stage: frankenphp_prod (rootless, Debian Slim — 290MB statt 704MB)
  → Nur Runtime-Artefakte, kein Composer, kein Dev-Tooling
  → Worker Mode: FRANKENPHP_CONFIG="worker ./public/index.php"
```

Seit März 2026 nutzt das Template rootless Debian Slim Images in Produktion — 60% kleiner als vorher.

### Service-Details

**php** — `dunglas/frankenphp:latest-php8.4`:
- Worker Mode in Produktion: PHP bleibt im Memory, Symfony bootet einmal
- Caddy handelt TLS-Termination, HTTP/2, HTTP/3, Static Files
- Routes: `/api/*` → Symfony, alles andere → SvelteKit Build Output (via `file_server`)
- Für den Messenger Worker: zweiter Container mit gleichem Image, anderer Command

**⚠️ Worker Mode Caveat**: Im Worker Mode bleibt der Symfony Kernel zwischen Requests im Memory. Das bedeutet: Doctrine's Identity Map muss nach jedem Request gecleart werden (`EntityManager::clear()`), statische Variablen in Services überleben Requests (keine Request-spezifischen Daten in statischen Properties speichern), und Memory Leaks akkumulieren sich. Das `dunglas/symfony-docker` Template handled das meiste automatisch über den `SwooleRuntime`/`FrankenPHPRuntime`, aber eigene Services müssen darauf achten keine Request-Daten als Class Properties zu cachen.

**database** — `postgres:17-alpine`, Volume für Persistence, `POSTGRES_DB=smarthabit`

**pgbouncer** — `bitnami/pgbouncer:1.23`:
- Transaction-Mode Pooling: jede Query bekommt eine Connection, gibt sie danach zurück
- Im Worker Mode besonders wichtig: FrankenPHP-Worker halten persistente Connections, PgBouncer verhindert Connection-Exhaustion
- `max_client_conn=200`, `default_pool_size=20` als Startwerte
- `DATABASE_URL=postgresql://user:pass@pgbouncer:6432/smarthabit?serverVersion=17`
- Wichtig: Doctrine's `server_version` muss trotzdem auf PG 17 stehen, nicht PgBouncer
- **⚠️ Prepared Statements**: PgBouncer Transaction Mode unterstützt keine Prepared Statements (Connection geht nach Transaction an anderen Client). Fix: `PGBOUNCER_SERVER_RESET_QUERY=DISCARD ALL` als ENV in der PgBouncer-Config. Ohne das entstehen Errors oder Performance-Overhead weil PgBouncer Statements jedes Mal neu parsen muss.

**bun** — `oven/bun:1.3-alpine`, nur im `dev` Profile aktiv:
- Mounted den `frontend/` Ordner, `bun run dev` mit HMR
- Produktions-Build: `bun run build` → statische Files, von Caddy via `file_server` served
- Kein Symfony AssetMapper — Frontend ist komplett eigenständig, Build über Bun/Vite
- `bun install` statt `npm install` (~25x schneller)

### Frontend Build-Pipeline (kein Symfony AssetMapper)

Das Frontend ist ein **eigenständiges SvelteKit-Projekt** im `frontend/`-Ordner, komplett entkoppelt von Symfony. Kein AssetMapper, kein Webpack Encore, keine Symfony-seitige Asset-Verwaltung.

```
Frontend Build: Bun + Vite (via SvelteKit)
├── Dev:  bun run dev → Vite Dev Server mit HMR auf Port 5173
├── Build: bun run build → adapter-static → /frontend/build/
└── Deploy: Caddy file_server served /frontend/build/ für alle Nicht-API-Routes
```

Warum kein AssetMapper: AssetMapper ist für Server-Rendered Symfony Apps gedacht (Twig Templates). Unsere App ist eine SPA — Symfony liefert nur eine JSON-API, das Frontend ist ein eigenständiger Build. Bun + Vite (via SvelteKit) ist der direkte Weg ohne Symfony-Overhead.

Caddy-Config im FrankenPHP Container:
```
# Caddyfile Auszug
{$SERVER_NAME} {
    # API → Symfony/FrankenPHP
    handle /api/* {
        php_server
    }
    # Alles andere → SvelteKit Static Build
    handle {
        root * /app/frontend/build
        try_files {path} /index.html
        file_server
    }
}
```

### Messenger Worker

Gleicher FrankenPHP-Container, anderer Entrypoint — als separater Service in `compose.yaml`:

```yaml
  messenger-worker:
    build:
      context: .
      target: frankenphp_dev  # oder frankenphp_prod
    command: ["php", "bin/console", "messenger:consume", "async", "--time-limit=3600"]
    restart: unless-stopped
    depends_on:
      - database
    environment:
      # WICHTIG: Messenger Worker verbindet DIREKT zur DB, nicht über PgBouncer!
      # PgBouncer Transaction-Mode unterstützt kein LISTEN/NOTIFY (Doctrine Messenger braucht das)
      DATABASE_URL: postgresql://...@database:5432/smarthabit?serverVersion=17
```

Restart-Policy: `unless-stopped` — Symfony beendet sich nach 1h (`--time-limit`), Docker startet neu. Verhindert Memory Leaks.

### Cron

Im `php`-Container via separatem Cron-Service oder Supercronic (Go-basiert, Docker-friendly):
- Alle 15min: `php bin/console app:check-habits`
- Nachts 03:00 UTC: `php bin/console app:learn-timewindows`
- Nachts 03:30 UTC: `php bin/console app:compute-stats` (Phase 5)
- Nachts 04:00 UTC: `php bin/console app:cleanup-push-subscriptions`
- Nachts 04:30 UTC: `php bin/console app:cleanup-old-logs` (DSGVO-Aufbewahrungsfristen)

Environment via `.env` + `.env.local` (Symfony-Standard), Secrets in Docker Secrets oder `.env.local` auf Server.

## Timezone-Strategie

Alles in UTC — mit einer bewussten Ausnahme für Zeitfenster. Jeder User setzt seine Timezone im Profil (Pflichtfeld bei Registration).

**Timestamps** (logged_at, sent_at, created_at): Immer UTC. PostgreSQL-Spalten als `TIMESTAMPTZ`, Doctrine-Type `datetimetz_immutable`.

**Zeitfenster** (time_window_start/end): Gespeichert als **Lokalzeit** (PostgreSQL `TIME` ohne Timezone). "07:00 Hund raus" ist ein menschliches Konzept — es wäre falsch, das in UTC umzurechnen, weil sich bei DST-Wechseln die UTC-Repräsentation ändern würde. Stattdessen bleibt 07:00 als 07:00 in der DB.

**Notification-Check** (der Kern der Timezone-Logik):
1. Cron läuft alle 15min, kennt aktuelle UTC-Zeit
2. Pro Habit → pro User im Household:
   - Aktuelle UTC-Zeit → in `User.timezone` konvertieren → ergibt User-Lokalzeit
   - User-Lokalzeit gegen `Habit.time_window_start/end` prüfen (simpler Range-Check)
   - "Heute" ist relativ zur User-Lokalzeit (für den "schon erledigt?"-Check)
3. DST-Wechsel sind kein Problem: PHP's `DateTimeZone` handled das automatisch

**Anzeige im Frontend**: API liefert UTC-Timestamps. Das Frontend konvertiert mit `Intl.DateTimeFormat` und der User-Timezone (aus JWT-Payload oder `/api/v1/user/me`).

**Multi-Timezone Household**: Lisa in Berlin und Tom in New York teilen "Hund raus" mit Fenster 07:00-09:00. Lisa bekommt die Notification wenn es in Berlin 07:00 ist, Tom wenn es in New York 07:00 ist. Der Habit hat nur ein Zeitfenster — die Per-User-Konvertierung im Check erledigt den Rest.

## Logging

Strukturiertes Logging via Monolog (Symfony-Standard). Wichtig weil FrankenPHP Worker Mode, Messenger Workers und Cron-Jobs eigene Log-Kanäle brauchen.

- **Channels**: `app` (default), `messenger` (Worker-Queue), `notification` (Push-Dispatch), `security` (Auth-Events)
- **Format**: JSON in Prod (`monolog.formatter.json`), line-based in Dev
- **Output**: `stderr` in Docker (landet im `docker compose logs`), kein File-Logging im Container
- **Worker Mode Hinweis**: `error_log()` geht ins Caddy-Log, nicht in Monolog. Immer den Logger-Service injizieren, nie `error_log()` direkt nutzen.
- **Log Levels**: `INFO` für Business-Events (Habit geloggt, Notification gesendet), `WARNING` für degraded Operations (Push fehlgeschlagen, Retry), `ERROR` für unerwartete Fehler. Kein `DEBUG` in Prod.

Config in `config/packages/monolog.yaml`:
```yaml
when@prod:
    monolog:
        handlers:
            main:
                type: stream
                path: "php://stderr"
                level: info
                formatter: monolog.formatter.json
            notification:
                type: stream
                path: "php://stderr"
                level: info
                channels: ["notification"]
                formatter: monolog.formatter.json
```

## API-Versionierung

Alle Endpoints unter `/api/v1/`. Versionierung via URL-Prefix, nicht via Header — einfacher zu debuggen, cachen und routen.

Wenn v2 nötig wird: `/api/v2/` parallel zu `/api/v1/` betreiben. Alte Version für eine Migration Period (z.B. 6 Monate) erhalten, dann deprecaten. Separate Controller-Klassen pro Version, shared Services. Das muss nicht jetzt gebaut werden — wichtig ist nur dass der URL-Prefix `v1` von Anfang an drin ist, damit die Option existiert.

## Datenmodell (Doctrine Entities)

### Household

Das Kernkonzept. Alle Habits gehören einem Household, mehrere User teilen sich ein Household.

```
Household
├── id: uuid (Symfony Uid Component)
├── name: string
├── invite_code: string (unique, 8 Zeichen)
├── created_at: DateTimeImmutable (UTC)
├── updated_at: DateTimeImmutable (UTC)
```

### User

```
User
├── id: uuid
├── household_id: uuid → Household (ManyToOne)
├── display_name: string
├── email: string (unique)
├── password: string (hashed, Symfony PasswordHasher)
├── email_verified_at: DateTimeImmutable (nullable — null = nicht verifiziert)
├── timezone: string (required, z.B. "Europe/Berlin" — IANA Timezone)
├── locale: string (default "de", erlaubt: "de", "en")
├── theme: string (default "auto", erlaubt: "auto", "light", "dark")
├── push_subscriptions: json (Array von {endpoint, keys, device_name, last_seen, type} Objekten)
├── consent_at: DateTimeImmutable (Zeitpunkt der DSGVO-Einwilligung)
├── consent_version: string (Version der DSE bei Einwilligung, z.B. "1.0")
├── created_at: DateTimeImmutable (UTC)
├── updated_at: DateTimeImmutable (UTC)
```

`timezone` ist Pflichtfeld bei Registration. Das Frontend schlägt die Browser-Timezone vor (`Intl.DateTimeFormat().resolvedOptions().timeZone`), User kann überschreiben. `locale` wird ebenfalls aus dem Browser übernommen (`navigator.language`) und bestimmt die Sprache der Notifications und API-Responses. `push_subscriptions` als strukturiertes JSON-Array: jede Subscription enthält den Web Push Endpoint + VAPID Keys (PWA) oder einen ntfy-Topic (native Android) oder ein APNs Device-Token (native iOS). Feld `type` unterscheidet: `web_push`, `ntfy`, `apns`.

### Habit

```
Habit
├── id: uuid
├── household_id: uuid → Household (ManyToOne)
├── name: string
├── emoji: string
├── sort_order: int
├── notification_message: string (Translation-Key oder Custom-Text, z.B. "habit.notification.dog_walk")
├── time_window_start: time (z.B. 07:00 — Lokalzeit, NICHT UTC)
├── time_window_end: time (z.B. 09:00 — Lokalzeit, NICHT UTC)
├── time_window_mode: enum(manual, auto)
├── frequency: enum(daily, weekdays, weekends, custom)
├── frequency_days: json (null oder [1,2,3,4,5] für custom)
├── is_active: bool
├── created_at: DateTimeImmutable (UTC)
├── updated_at: DateTimeImmutable (UTC)
├── deleted_at: DateTimeImmutable (nullable — Soft-Delete)
```

Zeitfenster bewusst als Lokalzeit gespeichert (reiner `TIME`-Typ ohne Timezone in PG). Grund: "07:00 Hund raus" ist ein menschliches Konzept, kein UTC-Wert. Der Notification-Check konvertiert die aktuelle UTC-Zeit jedes Users in dessen Lokalzeit und vergleicht gegen dieses Fenster. So funktioniert DST automatisch ohne Neuberechnung.

### HabitLog

```
HabitLog
├── id: uuid
├── habit_id: uuid → Habit (ManyToOne)
├── user_id: uuid → User (ManyToOne)
├── logged_at: DateTimeImmutable (UTC, Frontend konvertiert zur Anzeige)
├── source: enum(manual, notification) — woher kam der Log?
```

### NotificationLog

Für Debugging und um Doppel-Notifications zu verhindern:

```
NotificationLog
├── id: uuid
├── habit_id: uuid → Habit
├── user_id: uuid → User
├── sent_at: DateTimeImmutable (UTC)
├── status: enum(sent, failed, clicked)
├── push_message_id: string (nullable)
├── error_reason: string (nullable — für Push-Fehlerdetails)
├── push_type: string (web_push, ntfy, apns)
```

## API Endpoints (Symfony Controller)

Alle Routen unter `/api/v1`, JSON-Responses, JWT-Auth via `lexik/jwt-authentication-bundle`.

### Auth & User

```
POST   /api/v1/register          — Neuen User + Household anlegen (timezone, locale required)
POST   /api/v1/login             — JWT Access Token + Refresh Token
POST   /api/v1/token/refresh     — Refresh Token → neues Access Token
POST   /api/v1/household/join    — Mit invite_code einem Household beitreten
GET    /api/v1/user/me           — Profil inkl. timezone, locale, theme, household, push_subscriptions
PUT    /api/v1/user/me           — Profil bearbeiten (display_name, timezone, locale, theme)
POST   /api/v1/user/push-subscription    — Push-Subscription registrieren (Web Push, ntfy, APNs)
DELETE /api/v1/user/push-subscription    — Push-Subscription entfernen (Logout/Gerätewechsel)
POST   /api/v1/password/forgot           — Passwort-Reset anfordern (E-Mail mit Token)
POST   /api/v1/password/reset            — Passwort zurücksetzen (Token + neues Passwort)
PUT    /api/v1/user/password             — Passwort ändern (altes + neues Passwort, eingeloggt)
```

### Habits

```
GET    /api/v1/habits                — Alle Habits des Households + Tagesstatus
POST   /api/v1/habits                — Neuen Habit anlegen
PUT    /api/v1/habits/{id}           — Habit bearbeiten (Name, Zeitfenster, etc.)
DELETE /api/v1/habits/{id}           — Habit löschen (Soft-Delete)
PATCH  /api/v1/habits/reorder        — Sortierung ändern
```

### Logging

```
POST   /api/v1/habits/{id}/log       — Ein-Tap Log (Body: nur source)
DELETE /api/v1/habits/{id}/log/{logId} — Log rückgängig machen
GET    /api/v1/habits/{id}/history    — Paginated History (wer, was, wann)
```

### Dashboard

```
GET    /api/v1/dashboard             — Tagesübersicht: alle Habits mit letztem Log
```

Die Dashboard-Response ist das, was die App beim Öffnen lädt — eine einzelne Query die pro Habit den heutigen Status liefert.

### Statistiken (Phase 5)

```
GET    /api/v1/habits/{id}/stats     — Streak, Completion Rate, Trend, Durchschnittszeit, User-Verteilung
GET    /api/v1/stats/household       — Gesamte Completion, Ranking, Heatmaps, aktivster User
```

### DSGVO & Account

```
GET    /api/v1/user/export           — Datenexport (Art. 20 DSGVO): alle User-Daten als JSON
DELETE /api/v1/user/me               — Account-Löschung (Art. 17 DSGVO): Cascade
GET    /api/v1/privacy               — Aktuelle Datenschutzerklärung (Version + Text)
```

### Health (kein Auth nötig)

```
GET    /api/v1/health                — DB-Connection + Messenger-Queue Status
GET    /api/v1/health/ready          — Für Docker Healthcheck (nur "up?")
```
